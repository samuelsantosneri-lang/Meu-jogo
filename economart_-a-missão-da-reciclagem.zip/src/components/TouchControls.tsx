/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, ArrowRight, ArrowUp, Sword } from 'lucide-react';

interface TouchControlsProps {
  onPressLeft: (active: boolean) => void;
  onPressRight: (active: boolean) => void;
  onPressJump: (active: boolean) => void;
  onPressAttack: (active: boolean) => void;
  onPressDepositX: () => void;
  hasCarriedItem: boolean;
  attackCharges?: number;
  comboStep?: 1 | 2 | 3;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onPressLeft,
  onPressRight,
  onPressJump,
  onPressAttack,
  onPressDepositX,
  hasCarriedItem,
  attackCharges = 5,
  comboStep = 1,
}) => {
  const handlePointerDown = (action: (active: boolean) => void) => (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore
    }
    action(true);
  };

  const handlePointerUp = (action: (active: boolean) => void) => (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {
      // Ignore
    }
    action(false);
  };

  return (
    <div className="absolute bottom-2 left-0 right-0 px-4 py-2 pointer-events-none select-none z-20 flex items-end justify-between">
      {/* Left / Right Movement Buttons */}
      <div className="flex items-center gap-2 pointer-events-auto">
        <button
          type="button"
          onPointerDown={handlePointerDown(onPressLeft)}
          onPointerUp={handlePointerUp(onPressLeft)}
          onPointerCancel={handlePointerUp(onPressLeft)}
          onPointerLeave={handlePointerUp(onPressLeft)}
          onContextMenu={(e) => e.preventDefault()}
          className="w-14 h-14 rounded-2xl bg-slate-900/80 active:bg-emerald-600/80 backdrop-blur-md border-2 border-slate-600/80 flex items-center justify-center text-white active:scale-90 transition-transform shadow-xl cursor-pointer touch-none"
          aria-label="Andar para Esquerda"
        >
          <ArrowLeft className="w-7 h-7 pointer-events-none" />
        </button>
        <button
          type="button"
          onPointerDown={handlePointerDown(onPressRight)}
          onPointerUp={handlePointerUp(onPressRight)}
          onPointerCancel={handlePointerUp(onPressRight)}
          onPointerLeave={handlePointerUp(onPressRight)}
          onContextMenu={(e) => e.preventDefault()}
          className="w-14 h-14 rounded-2xl bg-slate-900/80 active:bg-emerald-600/80 backdrop-blur-md border-2 border-slate-600/80 flex items-center justify-center text-white active:scale-90 transition-transform shadow-xl cursor-pointer touch-none"
          aria-label="Andar para Direita"
        >
          <ArrowRight className="w-7 h-7 pointer-events-none" />
        </button>
      </div>

      {/* Action Buttons: [X] Descartar, Espada, Pular */}
      <div className="flex items-center gap-2.5 pointer-events-auto">
        <button
          type="button"
          onPointerDown={(e) => {
            e.preventDefault();
            onPressDepositX();
          }}
          onContextMenu={(e) => e.preventDefault()}
          className={`w-14 h-14 rounded-2xl backdrop-blur-md border-2 flex flex-col items-center justify-center active:scale-90 transition-transform shadow-xl font-bold cursor-pointer touch-none ${
            hasCarriedItem
              ? 'bg-amber-400 text-slate-950 border-white ring-2 ring-amber-300 animate-pulse'
              : 'bg-slate-800/80 text-slate-300 border-slate-600'
          }`}
          aria-label="Apertar X para Descartar"
        >
          <span className="text-base font-black leading-none pointer-events-none">X</span>
          <span className="text-[8px] font-black uppercase mt-0.5 pointer-events-none">Descartar</span>
        </button>

        <button
          type="button"
          onPointerDown={handlePointerDown(onPressAttack)}
          onPointerUp={handlePointerUp(onPressAttack)}
          onPointerCancel={handlePointerUp(onPressAttack)}
          onPointerLeave={handlePointerUp(onPressAttack)}
          onContextMenu={(e) => e.preventDefault()}
          className={`w-14 h-14 rounded-2xl backdrop-blur-md border-2 flex flex-col items-center justify-center active:scale-90 transition-all shadow-xl font-bold cursor-pointer touch-none ${
            attackCharges <= 0
              ? 'bg-amber-900/80 active:bg-amber-800 border-amber-400 text-amber-200'
              : comboStep === 3
              ? 'bg-gradient-to-tr from-amber-600 to-yellow-400 border-yellow-200 text-slate-950 ring-2 ring-yellow-300 animate-pulse'
              : comboStep === 2
              ? 'bg-sky-600/90 active:bg-sky-500 border-sky-300 text-white'
              : 'bg-emerald-600/90 active:bg-emerald-500 border-emerald-300 text-white'
          }`}
          aria-label="Atacar com Espada"
        >
          <Sword className={`w-5 h-5 pointer-events-none ${comboStep === 3 ? 'text-slate-950 stroke-[2.5]' : ''}`} />
          <span className="text-[8px] font-black uppercase mt-0.5 tracking-tighter pointer-events-none">
            {attackCharges <= 0
              ? 'Recarga'
              : comboStep === 3
              ? '⚡ Finisher!'
              : comboStep === 2
              ? `Combo [2/3]`
              : `${attackCharges}/5`}
          </span>
        </button>

        <button
          type="button"
          onPointerDown={handlePointerDown(onPressJump)}
          onPointerUp={handlePointerUp(onPressJump)}
          onPointerCancel={handlePointerUp(onPressJump)}
          onPointerLeave={handlePointerUp(onPressJump)}
          onContextMenu={(e) => e.preventDefault()}
          className="w-15 h-15 rounded-2xl bg-sky-500/90 active:bg-sky-400 backdrop-blur-md border-2 border-sky-300 flex flex-col items-center justify-center text-slate-950 active:scale-90 transition-transform shadow-xl font-bold cursor-pointer touch-none"
          aria-label="Pular"
        >
          <ArrowUp className="w-7 h-7 stroke-[3] pointer-events-none" />
          <span className="text-[9px] font-black uppercase pointer-events-none">Pular</span>
        </button>
      </div>
    </div>
  );
};
