/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Heart, Star, Recycle, Pause, Volume2, VolumeX, Flame, WifiOff } from 'lucide-react';
import { Enemy, GameStats, PlayerState, RecycleBin } from '../game/types';
import { TRASH_CATEGORY_INFO } from '../game/levels';
import { soundManager } from '../game/audio';
import { getSkinById } from '../game/skins';

interface GameHUDProps {
  stats: GameStats;
  player: PlayerState;
  player2?: PlayerState | null;
  activeEnemies: Enemy[];
  recycleBins: RecycleBin[];
  levelTitle: string;
  totalTrashInLevel: number;
  levelRecycledCount: number;
  isMuted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  onBinClick: (bin: RecycleBin) => void;
  isOnlineCoop?: boolean;
  connectionStatus?: 'connected' | 'reconnecting' | 'disconnected';
}

export const GameHUD: React.FC<GameHUDProps> = React.memo(({
  stats,
  player,
  player2,
  activeEnemies,
  recycleBins,
  levelTitle: _levelTitle,
  totalTrashInLevel,
  levelRecycledCount,
  isMuted,
  onToggleMute,
  onPause,
  onBinClick,
  isOnlineCoop = false,
  connectionStatus = 'connected',
}) => {
  const boss = activeEnemies.find((e) => e.isBoss && e.state !== 'defeated');
  const livingEnemy = activeEnemies.find((e) => e.state !== 'defeated');
  const displayedEnemy = boss || livingEnemy;
  const skin = getSkinById(player.skinId);
  const skin2 = player2 ? getSkinById(player2.skinId) : null;
  const [musicTheme, setMusicTheme] = React.useState<'horror' | 'retro'>(() => soundManager.getMusicTheme());

  return (
    <div className="absolute top-0 left-0 right-0 p-3 sm:p-4 pointer-events-none select-none z-20 flex flex-col gap-2">
      {/* Top Main Bar */}
      <div className="flex items-center justify-between gap-2">
        {/* Left: Player Identity, Hearts & Level */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Custom Player Name Tag & Skin Icon */}
          <div className="flex items-center gap-1.5 bg-slate-900/95 px-2.5 py-1.5 rounded-2xl border border-slate-700/60 shadow-lg text-xs font-bold text-white">
            <span className="text-sm">{skin.icon}</span>
            <span className="text-amber-300 font-black truncate max-w-[90px] sm:max-w-[130px] font-['Fredoka']">
              {player.name || 'Eco-Guardião'}
            </span>
          </div>

          {/* Hearts Container */}
          <div className="flex items-center gap-1 bg-slate-900/95 px-3 py-1.5 rounded-2xl border border-slate-700/60 shadow-lg">
            {Array.from({ length: player.maxHp }).map((_, idx) => {
              const filled = idx < player.hp;
              return (
                <Heart
                  key={idx}
                  className={`w-5 h-5 transition-transform duration-200 ${
                    filled
                      ? 'text-red-500 fill-red-500 scale-100'
                      : 'text-slate-600 fill-slate-700 scale-90'
                  }`}
                />
              );
            })}
          </div>

          {/* Player 2 in Co-op */}
          {player2 && skin2 && (
            <div className="hidden sm:flex items-center gap-1.5 bg-sky-950/90 px-2.5 py-1.5 rounded-2xl border border-sky-600/60 shadow-lg text-xs font-bold text-white">
              <span className="text-sm">{skin2.icon}</span>
              <span className="text-sky-300 font-black truncate max-w-[80px] font-['Fredoka']">
                {player2.name}
              </span>
              <div className="flex items-center gap-0.5 ml-1">
                {Array.from({ length: player2.maxHp }).map((_, idx) => {
                  const filled = idx < player2.hp;
                  return (
                    <div
                      key={idx}
                      className={`w-2.5 h-2.5 rounded-full ${
                        player2.isDisconnected
                          ? 'bg-amber-400'
                          : filled
                          ? 'bg-red-500'
                          : 'bg-slate-700'
                      }`}
                    />
                  );
                })}
              </div>
              {player2.isDisconnected && (
                <span className="text-[10px] text-amber-300 font-bold ml-1 animate-pulse">
                  Reconectando...
                </span>
              )}
            </div>
          )}

          {/* Level Badge */}
          <div className="hidden sm:flex items-center gap-1.5 bg-slate-900/95 px-3 py-1.5 rounded-2xl border border-slate-700/60 shadow-lg text-xs font-bold text-emerald-300">
            <span>Fase {stats.currentLevel}/5</span>
          </div>

          {/* 5 Attack Charges Limit & Combo Step Indicator */}
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-2xl border shadow-lg text-xs font-bold transition-all ${
              player.attackCharges > 0
                ? 'bg-slate-900/95 border-emerald-500/50 text-white'
                : 'bg-amber-950/95 border-amber-500/60 text-amber-300 animate-pulse'
            }`}
            title={`Limite de até 5 ataques: ${player.attackCharges}/5 disponíveis | Combo: Passo ${player.attackComboStep}/3`}
          >
            <span className="text-xs">⚔️</span>
            <span className="hidden md:inline text-[11px] font-black text-emerald-300 mr-0.5">
              Golpes:
            </span>
            <div className="flex items-center gap-1">
              {Array.from({ length: player.maxAttackCharges || 5 }).map((_, idx) => {
                const filled = idx < player.attackCharges;
                return (
                  <div
                    key={idx}
                    className={`w-2.5 h-3.5 rounded-sm transition-all duration-150 ${
                      filled
                        ? 'bg-emerald-400 shadow-sm shadow-emerald-400 scale-100'
                        : 'bg-slate-800 border border-slate-700 opacity-50 scale-90'
                    }`}
                  />
                );
              })}
            </div>
            <span className="font-mono text-[11px] font-black text-emerald-200 tabular-nums ml-0.5">
              {player.attackCharges}/5
            </span>

            {/* Attack Combo Sequence Indicator */}
            <div
              className={`ml-1 px-1.5 py-0.5 rounded-md text-[10px] font-black tracking-tight border flex items-center gap-1 ${
                player.attackComboStep === 3
                  ? 'bg-amber-500/30 text-amber-300 border-amber-400 animate-pulse ring-1 ring-amber-300'
                  : player.attackComboStep === 2
                  ? 'bg-sky-500/30 text-sky-300 border-sky-400'
                  : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
              }`}
            >
              <span>Combo:</span>
              <span className="font-mono">{player.attackComboStep}/3</span>
              <span className="hidden lg:inline text-[9px] font-bold">
                {player.attackComboStep === 3
                  ? 'Vórtice'
                  : player.attackComboStep === 2
                  ? 'Cruzado'
                  : 'Corte'}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Recycled Count & Score & Combo */}
        <div className="flex items-center gap-2">
          {/* Recycled counter */}
          <div className="flex items-center gap-1.5 bg-emerald-950/95 px-3 py-1.5 rounded-2xl border border-emerald-500/40 shadow-lg text-xs font-bold text-emerald-200">
            <Recycle className="w-4 h-4 text-emerald-400" />
            <span>Reciclados:</span>
            <span className="font-mono text-white tabular-nums text-sm">
              {levelRecycledCount}/{totalTrashInLevel}
            </span>
          </div>

          {/* Score */}
          <div className="flex items-center gap-1.5 bg-amber-950/95 px-3 py-1.5 rounded-2xl border border-amber-500/40 shadow-lg text-xs font-bold text-amber-200">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span className="font-mono text-white tabular-nums text-sm">
              {stats.score}
            </span>
          </div>

          {/* Active Combo Multiplier Badge */}
          {stats.comboCount >= 2 && (
            <div
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-2xl border shadow-lg text-xs font-black transition-all ${
                stats.comboMultiplier >= 5
                  ? 'bg-rose-950/95 border-rose-500 text-rose-300 ring-2 ring-rose-400 shadow-rose-950/60 animate-pulse'
                  : stats.comboMultiplier >= 3
                  ? 'bg-amber-950/95 border-amber-400 text-amber-300 ring-2 ring-amber-400 shadow-amber-950/60'
                  : 'bg-emerald-950/95 border-emerald-400 text-emerald-300 shadow-emerald-950/60'
              }`}
              title={`Multiplicador de Combo: ganhe ${stats.comboMultiplier * 100} pts por pneu reciclado em sequência sem tomar dano!`}
            >
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-bounce" />
              <span>x{stats.comboMultiplier}</span>
              <span className="hidden sm:inline font-bold text-[10px] text-amber-200/90">
                (+{(stats.comboMultiplier - 1) * 100} bonus)
              </span>
            </div>
          )}
        </div>

        {/* Right: Sound, Music Theme & Pause Controls */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          {/* Music Theme Toggle */}
          <button
            onClick={() => {
              soundManager.playPickup();
              const newTheme = soundManager.toggleMusicTheme();
              setMusicTheme(newTheme);
            }}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-2xl border shadow-lg text-xs font-bold transition-all cursor-pointer ${
              musicTheme === 'horror'
                ? 'bg-rose-950/90 border-rose-500/70 text-rose-300 hover:bg-rose-900/90'
                : 'bg-emerald-950/90 border-emerald-500/70 text-emerald-300 hover:bg-emerald-900/90'
            }`}
            title={`Música atual: ${musicTheme === 'horror' ? 'Terror Sinistro' : 'Retrô Clássica'}. Clique para alternar!`}
          >
            <span>{musicTheme === 'horror' ? '🦇' : '🕹️'}</span>
            <span className="hidden md:inline text-[11px] font-black">
              {musicTheme === 'horror' ? 'Terror' : 'Retrô'}
            </span>
          </button>

          <button
            onClick={() => {
              soundManager.playPickup();
              onToggleMute();
            }}
            className="p-2 bg-slate-900/95 hover:bg-slate-800 active:scale-95 rounded-2xl border border-slate-700/60 shadow-lg text-slate-200 transition-colors cursor-pointer"
            title={isMuted ? 'Ativar som' : 'Desativar som'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          <button
            onClick={() => {
              soundManager.playPickup();
              onPause();
            }}
            className="p-2 bg-slate-900/95 hover:bg-slate-800 active:scale-95 rounded-2xl border border-slate-700/60 shadow-lg text-slate-200 transition-colors cursor-pointer"
            title="Pausar jogo"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Online status indicator if in online co-op and connection issue */}
      {isOnlineCoop && connectionStatus !== 'connected' && (
        <div className="pointer-events-auto self-center flex items-center gap-2 bg-amber-500/90 text-slate-950 px-3.5 py-1 rounded-full text-xs font-black shadow-lg animate-pulse">
          <WifiOff className="w-4 h-4" />
          <span>
            {connectionStatus === 'reconnecting'
              ? 'Conexão instável: Tentando reconectar ao servidor...'
              : 'Desconectado do servidor multiplayer.'}
          </span>
        </div>
      )}

      {/* Secondary Bar: Active Monster / Boss Bar & Carried Item Banner */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* Carried Item hint indicator */}
        {player.carriedItem ? (
          (() => {
            const info = TRASH_CATEGORY_INFO[player.carriedItem.category];
            return (
              <div
                className="flex items-center gap-2 px-3 py-1.5 rounded-2xl shadow-lg border border-white/30 text-white text-xs font-black animate-pulse"
                style={{ backgroundColor: info.binDarkHex }}
              >
                <span className="text-base">{info.iconSymbol}</span>
                <span>Levando: {player.carriedItem.name}</span>
                <span className="text-[10px] bg-white text-slate-900 px-1.5 py-0.5 rounded-md font-bold">
                  Destino: {info.binColorName}
                </span>
              </div>
            );
          })()
        ) : (
          <div className="hidden sm:block text-[11px] text-slate-300/80 bg-slate-900/90 px-3 py-1 rounded-xl border border-slate-700/50 font-bold">
            💡 Ande sobre um pneu para pegá-lo e clique na lixeira ou aperte [X] para descartar!
          </div>
        )}

        {/* Monster HP bar if monster is on field */}
        {displayedEnemy && (
          <div className="ml-auto flex items-center gap-2 bg-slate-900/95 px-3 py-1.5 rounded-2xl border border-red-500/40 shadow-lg text-xs font-bold text-white">
            <span className="text-sm">{displayedEnemy.isBoss ? '👑' : '👾'}</span>
            <span className="text-red-300 truncate max-w-[120px] sm:max-w-none">
              {displayedEnemy.name}:
            </span>
            <div className="w-20 sm:w-28 h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
              <div
                className="h-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-200"
                style={{
                  width: `${Math.max(0, (displayedEnemy.hp / displayedEnemy.maxHp) * 100)}%`,
                }}
              />
            </div>
            <span className="font-mono text-[10px] text-slate-300 tabular-nums">
              {displayedEnemy.hp}/{displayedEnemy.maxHp}
            </span>
          </div>
        )}
      </div>

      {/* Combo Multiplier Streak & Countdown Meter */}
      {stats.comboCount >= 2 && stats.comboTimer > 0 && (
        <div className="flex items-center gap-2 sm:gap-3 px-3 py-1 bg-slate-950/90 border border-amber-500/50 rounded-2xl shadow-xl backdrop-blur-sm self-start animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-center gap-1.5 text-xs font-black">
            <span className="text-sm">🔥</span>
            <span className="text-amber-300 uppercase tracking-wide">
              Combo Pneus x{stats.comboMultiplier}
            </span>
            <span className="text-[11px] text-slate-300 font-medium">
              ({stats.comboCount} reciclados!)
            </span>
          </div>
          <div className="flex items-center gap-2 w-24 sm:w-32">
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
              <div
                className={`h-full transition-all duration-100 ${
                  stats.comboMultiplier >= 5
                    ? 'bg-gradient-to-r from-rose-500 to-amber-400'
                    : stats.comboMultiplier >= 3
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-300'
                    : 'bg-gradient-to-r from-emerald-400 to-amber-300'
                }`}
                style={{
                  width: `${Math.max(0, Math.min(100, (stats.comboTimer / (stats.maxComboTimer || 6.5)) * 100))}%`,
                }}
              />
            </div>
            <span className="font-mono text-[10px] text-amber-300 tabular-nums font-bold">
              {stats.comboTimer.toFixed(1)}s
            </span>
          </div>
        </div>
      )}

      {/* Attack Hit Combo Streak Banner */}
      {stats.attackHitStreak >= 2 && stats.attackHitStreakTimer > 0 && (
        <div className="flex items-center gap-2 sm:gap-3 px-3 py-1 bg-slate-950/90 border border-rose-500/70 rounded-2xl shadow-xl backdrop-blur-sm self-start animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-center gap-1.5 text-xs font-black">
            <span className="text-sm">⚡</span>
            <span className="text-rose-400 uppercase tracking-wide">
              {stats.attackHitStreak} HITS COMBO!
            </span>
            <span className="text-[11px] text-amber-300 font-semibold hidden sm:inline">
              (+{Math.min(60, stats.attackHitStreak * 5)}% Dano de Ataque)
            </span>
          </div>
          <div className="flex items-center gap-2 w-20 sm:w-28">
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
              <div
                className="h-full bg-gradient-to-r from-orange-500 via-rose-500 to-amber-300 transition-all duration-100"
                style={{
                  width: `${Math.max(0, Math.min(100, (stats.attackHitStreakTimer / 2.8) * 100))}%`,
                }}
              />
            </div>
            <span className="font-mono text-[10px] text-rose-300 tabular-nums font-bold">
              {stats.attackHitStreakTimer.toFixed(1)}s
            </span>
          </div>
        </div>
      )}

      {/* QUICK CLICK-TO-RECYCLE BAR */}
      {player.carriedItem && (
        <div className="pointer-events-auto flex items-center gap-1.5 p-1.5 bg-slate-950/95 rounded-2xl border border-amber-500/50 shadow-2xl overflow-x-auto max-w-full">
          <span className="text-[11px] font-black text-amber-300 px-2 shrink-0">
            👉 Clique na lixeira correta:
          </span>
          <div className="flex items-center gap-1.5">
            {recycleBins.map((bin) => {
              const isMatch = player.carriedItem?.category === bin.category;
              return (
                <button
                  key={bin.category}
                  onClick={() => onBinClick(bin)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold border transition-all cursor-pointer whitespace-nowrap active:scale-95 ${
                    isMatch
                      ? 'bg-amber-400 text-slate-950 border-white shadow-lg animate-bounce ring-2 ring-white'
                      : 'bg-slate-800/80 text-white border-slate-700 hover:bg-slate-700'
                  }`}
                  style={{
                    backgroundColor: isMatch ? bin.colorHex : undefined,
                    color: isMatch ? '#FFFFFF' : undefined,
                  }}
                  title={`Descartar em ${bin.label}`}
                >
                  <span>{bin.icon}</span>
                  <span>{bin.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
});
