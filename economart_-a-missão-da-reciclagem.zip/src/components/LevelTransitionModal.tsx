/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowRight, Lightbulb } from 'lucide-react';
import { LevelConfig } from '../game/types';
import { soundManager } from '../game/audio';

interface LevelTransitionModalProps {
  levelConfig: LevelConfig;
  score: number;
  trashRecycled: number;
  maxCombo?: number;
  maxAttackHitStreak?: number;
  playerName?: string;
  onNextLevel: () => void;
}

export const LevelTransitionModal: React.FC<LevelTransitionModalProps> = ({
  levelConfig,
  score,
  trashRecycled,
  maxCombo = 1,
  maxAttackHitStreak = 0,
  playerName,
  onNextLevel,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-emerald-500/50 rounded-3xl shadow-2xl p-6 sm:p-8 flex flex-col text-slate-100 text-center">
        <div className="mx-auto w-20 h-20 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400/40 flex items-center justify-center text-4xl mb-4 shadow-lg animate-bounce">
          🎉
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-emerald-400 font-['Fredoka'] mb-1">
          {levelConfig.title} Concluída!
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 mb-5">
          Excelente trabalho, <strong className="text-amber-300">{playerName || 'Herói'}</strong>! Você limpou o cenário e derrotou os monstros da poluição!
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 block mb-0.5">Pontos</span>
            <span className="font-mono text-base sm:text-lg font-black text-amber-400 tabular-nums">
              {score}
            </span>
          </div>
          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 block mb-0.5">Reciclados</span>
            <span className="font-mono text-base sm:text-lg font-black text-emerald-400 tabular-nums">
              {trashRecycled}
            </span>
          </div>
          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-amber-500/40">
            <span className="text-[10px] text-amber-300/80 block mb-0.5">Combo Pneus</span>
            <span className="font-mono text-base sm:text-lg font-black text-amber-300 tabular-nums">
              x{Math.max(1, maxCombo)}
            </span>
          </div>
          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-rose-500/40">
            <span className="text-[10px] text-rose-300/80 block mb-0.5">Hit Combo</span>
            <span className="font-mono text-base sm:text-lg font-black text-rose-400 tabular-nums">
              {maxAttackHitStreak} hits
            </span>
          </div>
        </div>

        <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl text-left mb-6 space-y-2">
          <div className="flex items-center gap-2 text-emerald-300 text-sm font-bold">
            <Lightbulb className="w-4 h-4 text-amber-400" />
            <span>{levelConfig.educationalFact.title}</span>
          </div>
          <p className="text-xs text-slate-200 leading-relaxed">
            {levelConfig.educationalFact.message}
          </p>
          <p className="text-[11px] text-emerald-400 font-semibold">
            {levelConfig.educationalFact.tip}
          </p>
        </div>

        <button
          onClick={() => {
            soundManager.playJump();
            onNextLevel();
          }}
          className="w-full group flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 active:scale-95 text-emerald-950 font-black text-lg py-4 px-6 rounded-2xl shadow-xl border-2 border-emerald-300 transition-all cursor-pointer"
        >
          <span>Avançar para a Próxima Fase</span>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
