/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Globe } from 'lucide-react';
import { soundManager } from '../game/audio';

interface VictoryModalProps {
  score: number;
  trashRecycled: number;
  monstersDefeated: number;
  maxCombo?: number;
  comboBonusScore?: number;
  maxAttackHitStreak?: number;
  playerName?: string;
  onPlayAgain: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  score,
  trashRecycled,
  monstersDefeated,
  maxCombo = 1,
  maxAttackHitStreak = 0,
  playerName,
  onPlayAgain,
}) => {
  useEffect(() => {
    const duration = 3.5 * 1000;
    const end = Date.now() + duration;
    const interval: number = window.setInterval(() => {
      if (Date.now() > end) {
        return clearInterval(interval);
      }
      confetti({
        startVelocity: 30,
        spread: 360,
        ticks: 60,
        origin: { x: Math.random(), y: Math.random() * 0.4 },
        colors: ['#22C55E', '#FACC15', '#38BDF8', '#F97316', '#EF4444'],
      });
    }, 350);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-amber-400/60 rounded-3xl shadow-2xl p-6 sm:p-8 flex flex-col text-slate-100 text-center overflow-hidden">
        <div className="mx-auto w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-500 to-yellow-300 border-2 border-white/60 flex items-center justify-center text-5xl mb-4 shadow-2xl animate-float">
          🏆
        </div>

        <h2 className="text-3xl sm:text-4xl font-black text-amber-400 font-['Fredoka'] mb-2 tracking-wide uppercase">
          VITÓRIA HEROICA!
        </h2>
        <p className="text-base sm:text-lg font-bold text-emerald-300 mb-6 font-['Fredoka'] leading-snug">
          Parabéns, <strong className="text-amber-300">{playerName || 'Eco-Guardião'}</strong>! Você derrotou o temível SUPER PNEU, desviou dos carros arremessados e purificou o ferro-velho de borracha!
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-2.5 mb-6 bg-slate-800/80 p-3 sm:p-4 rounded-2xl border border-slate-700/60">
          <div>
            <span className="text-[10px] sm:text-[11px] text-slate-400 block mb-0.5">Pontuação</span>
            <span className="font-mono text-base sm:text-xl font-black text-amber-400 tabular-nums">
              {score}
            </span>
          </div>
          <div>
            <span className="text-[10px] sm:text-[11px] text-slate-400 block mb-0.5">Reciclados</span>
            <span className="font-mono text-base sm:text-xl font-black text-emerald-400 tabular-nums">
              {trashRecycled}
            </span>
          </div>
          <div>
            <span className="text-[10px] sm:text-[11px] text-slate-400 block mb-0.5">Purificados</span>
            <span className="font-mono text-base sm:text-xl font-black text-sky-400 tabular-nums">
              {monstersDefeated}
            </span>
          </div>
          <div className="border border-amber-500/30 rounded-xl p-1 bg-amber-950/30">
            <span className="text-[10px] sm:text-[11px] text-amber-300/80 block mb-0.5">Combo Pneus</span>
            <span className="font-mono text-base sm:text-xl font-black text-amber-300 tabular-nums">
              x{Math.max(1, maxCombo)}
            </span>
          </div>
          <div className="border border-rose-500/30 rounded-xl p-1 bg-rose-950/30">
            <span className="text-[10px] sm:text-[11px] text-rose-300/80 block mb-0.5">Hit Combo</span>
            <span className="font-mono text-base sm:text-xl font-black text-rose-400 tabular-nums">
              {maxAttackHitStreak} hits
            </span>
          </div>
        </div>

        <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl text-left mb-6 space-y-2 text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
            <Globe className="w-4 h-4 text-sky-400" />
            <span>Título Conquistado: Guardião Supremo dos Pneus 🌟</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            Com a sua ajuda, toneladas de pneus foram salvas da queima tóxica e do acúmulo de água da dengue! Agora eles serão triturados e virarão asfalto ecológico, pistas de corrida, solas de sapato e brinquedos de parque infantil.
          </p>
        </div>

        <button
          onClick={() => {
            soundManager.playJump();
            onPlayAgain();
          }}
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-95 text-slate-950 font-black text-lg py-4 px-6 rounded-2xl shadow-xl border-2 border-amber-200 transition-all cursor-pointer"
        >
          <RotateCcw className="w-5 h-5" />
          <span>Jogar Novamente</span>
        </button>
      </div>
    </div>
  );
};
