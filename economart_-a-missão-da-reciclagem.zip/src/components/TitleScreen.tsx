/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Play, BookOpen, Award, Volume2, VolumeX, Sparkles, Dices, Check, Users } from 'lucide-react';
import { soundManager } from '../game/audio';
import {
  CHARACTER_SKINS,
  CharacterSkin,
  DEFAULT_PLAYER_NAME,
  DEFAULT_SKIN_ID,
  RANDOM_HERO_NAMES,
  getSkinById,
} from '../game/skins';
import { CharacterPreviewCanvas } from './CharacterPreviewCanvas';

interface TitleScreenProps {
  playerName: string;
  selectedSkinId: string;
  onUpdateCustomization: (name: string, skinId: string) => void;
  onStartGame: () => void;
  onOpenMultiplayer: () => void;
  onOpenHowToPlay: () => void;
  onOpenCredits: () => void;
  highScore: number;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  playerName,
  selectedSkinId,
  onUpdateCustomization,
  onStartGame,
  onOpenMultiplayer,
  onOpenHowToPlay,
  onOpenCredits,
  highScore,
  isMuted,
  onToggleMute,
}) => {
  const [name, setName] = useState<string>(playerName || DEFAULT_PLAYER_NAME);
  const [skinId, setSkinId] = useState<string>(selectedSkinId || DEFAULT_SKIN_ID);
  const [musicTheme, setMusicTheme] = useState<'horror' | 'retro'>(() => soundManager.getMusicTheme());

  const activeSkin: CharacterSkin = getSkinById(skinId);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.slice(0, 16);
    setName(val);
    onUpdateCustomization(val || DEFAULT_PLAYER_NAME, skinId);
  };

  const handleSelectSkin = (newSkinId: string) => {
    soundManager.playPickup();
    setSkinId(newSkinId);
    onUpdateCustomization(name || DEFAULT_PLAYER_NAME, newSkinId);
  };

  const handleRandomName = () => {
    soundManager.playPickup();
    const available = RANDOM_HERO_NAMES.filter((n) => n !== name);
    const chosen = available[Math.floor(Math.random() * available.length)] || DEFAULT_PLAYER_NAME;
    setName(chosen);
    onUpdateCustomization(chosen, skinId);
  };

  const handleStart = () => {
    soundManager.playJump();
    const finalName = name.trim() || DEFAULT_PLAYER_NAME;
    onUpdateCustomization(finalName, skinId);
    onStartGame();
  };

  const handleMultiplayerClick = () => {
    soundManager.playPickup();
    const finalName = name.trim() || DEFAULT_PLAYER_NAME;
    onUpdateCustomization(finalName, skinId);
    onOpenMultiplayer();
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-between p-3 sm:p-6 bg-gradient-to-b from-slate-900 via-amber-950/70 to-red-950 text-white overflow-y-auto select-none">
      {/* Background pattern */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#ffffff_2px,transparent_2px)] [background-size:24px_24px]" />

      {/* Top Bar with High Score and Sound */}
      <div className="w-full max-w-5xl flex items-center justify-between z-10 shrink-0 mb-2 gap-2">
        <div className="flex items-center gap-2 bg-slate-900/80 px-3.5 py-1.5 rounded-2xl border border-white/20 text-xs sm:text-sm font-semibold shadow-md">
          <Award className="w-4 h-4 text-amber-300" />
          <span>Recorde:</span>
          <span className="font-mono text-amber-300 tabular-nums text-sm sm:text-base font-bold">{highScore} pts</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Soundtrack Theme Toggle Button */}
          <button
            onClick={() => {
              soundManager.playPickup();
              const nextTheme = soundManager.toggleMusicTheme();
              setMusicTheme(nextTheme);
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-2xl border text-xs sm:text-sm font-bold cursor-pointer shadow-md transition-all active:scale-95 ${
              musicTheme === 'horror'
                ? 'bg-rose-950/80 border-rose-500/70 text-rose-300 hover:bg-rose-900'
                : 'bg-emerald-950/80 border-emerald-500/70 text-emerald-300 hover:bg-emerald-900'
            }`}
            title="Alternar entre Trilha de Terror e Trilha Retrô"
          >
            <span>{musicTheme === 'horror' ? '🦇' : '🕹️'}</span>
            <span>{musicTheme === 'horror' ? 'Música: Terror' : 'Música: Retrô'}</span>
          </button>

          <button
            onClick={() => {
              soundManager.playPickup();
              onToggleMute();
            }}
            className="flex items-center gap-2 bg-slate-900/80 hover:bg-slate-900 active:scale-95 transition-all px-3.5 py-1.5 rounded-2xl border border-white/20 text-xs sm:text-sm font-semibold cursor-pointer shadow-md"
            title={isMuted ? 'Ativar som' : 'Desativar som'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-300" /> : <Volume2 className="w-4 h-4 text-emerald-300" />}
            <span>{isMuted ? 'Mudo' : 'Som'}</span>
          </button>
        </div>
      </div>

      {/* Central Interactive Content: Left Hero Story / Right Customizer */}
      <div className="w-full max-w-5xl z-10 my-auto flex flex-col md:flex-row items-center justify-center gap-4 sm:gap-6 py-1">
        {/* Left Column: Branding, Story & Game Launch */}
        <div className="flex-1 flex flex-col items-center md:items-start text-center md:text-left max-w-md">
          <div className="inline-flex items-center gap-2 bg-emerald-600/90 text-white text-xs font-black px-3 py-1 rounded-full shadow-lg border border-emerald-400 mb-2 uppercase tracking-wider">
            <span>♻️</span>
            <span>A Missão da Reciclagem</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black tracking-tight drop-shadow-md text-white mb-2 uppercase font-['Fredoka'] leading-tight">
            Economart: A Missão da Reciclagem
          </h1>

          <p className="text-amber-100/90 text-xs sm:text-sm font-medium mb-4 leading-relaxed drop-shadow">
            O temível <strong className="text-red-400">Imperador dos Pneus</strong> espalhou montanhas de pneus velhos para dominar a cidade! Assuma o controle de <strong className="text-emerald-300">Economart</strong>, empunhe sua lâmina ecológica e envie cada pneu para a destinação correta para restaurar a natureza!
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2.5 w-full">
            <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full">
              <button
                onClick={handleStart}
                className="w-full sm:flex-1 group flex items-center justify-center gap-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-95 text-slate-950 font-black text-base sm:text-lg py-3 px-5 rounded-2xl shadow-xl shadow-amber-950/40 border-2 border-amber-200 transition-all cursor-pointer"
              >
                <Play className="w-5 h-5 fill-slate-950 group-hover:scale-110 transition-transform" />
                <span>JOGAR SOLO</span>
              </button>

              <button
                onClick={handleMultiplayerClick}
                className="w-full sm:flex-1 group flex items-center justify-center gap-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 active:scale-95 text-white font-black text-base sm:text-lg py-3 px-5 rounded-2xl shadow-xl border-2 border-emerald-300 transition-all cursor-pointer"
              >
                <Users className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span>CO-OP ONLINE (2P)</span>
              </button>
            </div>

            <div className="flex items-center gap-2.5 w-full">
              <button
                onClick={() => {
                  soundManager.playPickup();
                  onOpenHowToPlay();
                }}
                className="flex-1 flex items-center justify-center gap-2 bg-slate-900/80 hover:bg-slate-800 active:scale-95 text-white font-bold text-xs sm:text-sm py-2.5 px-3 rounded-2xl border border-white/20 transition-all cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-emerald-300" />
                <span>Como Jogar</span>
              </button>

              <button
                onClick={() => {
                  soundManager.playPickup();
                  onOpenCredits();
                }}
                className="flex-1 text-center bg-slate-900/80 hover:bg-slate-800 active:scale-95 text-amber-200 font-bold text-xs sm:text-sm py-2.5 px-3 rounded-2xl border border-white/20 transition-all cursor-pointer"
              >
                Créditos
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Hero Customizer (Name + Skins + Live Preview) */}
        <div className="flex-1 w-full max-w-md bg-slate-900/90 border-2 border-amber-500/40 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
            <div className="flex items-center gap-2">
              <span className="text-xl">🎨</span>
              <h2 className="text-sm sm:text-base font-black text-amber-300 font-['Fredoka'] uppercase tracking-wide">
                Personalize seu Herói
              </h2>
            </div>
            <span className="text-[11px] font-bold text-slate-400 bg-slate-800/80 px-2.5 py-0.5 rounded-full border border-slate-700">
              {CHARACTER_SKINS.length} Skins Disponíveis
            </span>
          </div>

          {/* Character Name Input Field */}
          <div>
            <label className="text-xs font-bold text-slate-300 mb-1 flex items-center justify-between">
              <span>Nome do Personagem:</span>
              <span className="text-[10px] text-slate-400">{name.length}/16</span>
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={name}
                maxLength={16}
                onChange={handleNameChange}
                placeholder="Digite o nome do herói..."
                className="flex-1 bg-slate-800/95 border border-slate-700 focus:border-amber-400 focus:ring-1 focus:ring-amber-400 rounded-xl px-3 py-2 text-sm font-bold text-white placeholder-slate-500 outline-none transition-all"
              />
              <button
                type="button"
                onClick={handleRandomName}
                title="Gerar nome aleatório"
                className="flex items-center gap-1 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs px-3 py-2 rounded-xl transition-all cursor-pointer shadow-md"
              >
                <Dices className="w-4 h-4" />
                <span className="hidden sm:inline">Aleatório</span>
              </button>
            </div>
          </div>

          {/* Live Hero Preview & Active Skin Bio */}
          <div className="flex items-center gap-3 bg-slate-800/60 p-2.5 rounded-2xl border border-slate-700/60">
            <div className="shrink-0 bg-slate-950/70 rounded-xl border border-slate-700 p-1">
              <CharacterPreviewCanvas skin={activeSkin} playerName={name.trim() || DEFAULT_PLAYER_NAME} />
            </div>
            <div className="flex-1 flex flex-col text-left">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-lg">{activeSkin.icon}</span>
                <span className="font-black text-sm text-white font-['Fredoka']">{activeSkin.name}</span>
                <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md ${activeSkin.badgeColor}`}>
                  {activeSkin.badge}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 leading-tight mb-1.5">{activeSkin.description}</p>
              <div className="flex items-center gap-1.5 text-[10px] text-amber-300 font-semibold">
                <Sparkles className="w-3 h-3 text-amber-300 shrink-0" />
                <span>Espada pronta para o combate</span>
              </div>
            </div>
          </div>

          {/* Skin Selection Grid */}
          <div>
            <span className="text-xs font-bold text-slate-300 mb-1.5 block">
              Escolha a Skin:
            </span>
            <div className="grid grid-cols-3 gap-2">
              {CHARACTER_SKINS.map((skin) => {
                const isSelected = skin.id === skinId;
                return (
                  <button
                    key={skin.id}
                    type="button"
                    onClick={() => handleSelectSkin(skin.id)}
                    className={`relative flex flex-col items-center justify-center p-2 rounded-xl border transition-all text-center cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/50 shadow-lg scale-[1.02]'
                        : 'bg-slate-800/80 border-slate-700 hover:bg-slate-800 hover:border-slate-600 active:scale-95'
                    }`}
                  >
                    {isSelected && (
                      <span className="absolute top-1 right-1 bg-amber-400 text-slate-950 rounded-full p-0.5">
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                      </span>
                    )}
                    <span className="text-xl sm:text-2xl mb-0.5">{skin.icon}</span>
                    <span className="text-[11px] font-black text-white truncate max-w-full font-['Fredoka']">
                      {skin.name}
                    </span>
                    {/* Color Swatch Dot */}
                    <div className="flex items-center gap-1 mt-1">
                      <span
                        className="w-2 h-2 rounded-full border border-black/40"
                        style={{ backgroundColor: skin.jacketColor }}
                      />
                      <span
                        className="w-2 h-2 rounded-full border border-black/40"
                        style={{ backgroundColor: skin.bladeColor }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Bins Indicator */}
      <div className="w-full max-w-5xl z-10 pt-2 border-t border-white/10 flex flex-wrap items-center justify-center gap-1.5 sm:gap-2.5 text-[11px] font-bold text-white/90 shrink-0">
        <div className="flex items-center gap-1 bg-amber-600/80 px-2.5 py-1 rounded-xl shadow-sm">
          <span>🚗</span>
          <span>Asfalto</span>
        </div>
        <div className="flex items-center gap-1 bg-red-600/80 px-2.5 py-1 rounded-xl shadow-sm">
          <span>🚛</span>
          <span>Triturador</span>
        </div>
        <div className="flex items-center gap-1 bg-sky-600/80 px-2.5 py-1 rounded-xl shadow-sm">
          <span>🦟</span>
          <span>Anti-Dengue</span>
        </div>
        <div className="flex items-center gap-1 bg-emerald-600/80 px-2.5 py-1 rounded-xl shadow-sm">
          <span>🏍️</span>
          <span>Calçados</span>
        </div>
        <div className="flex items-center gap-1 bg-purple-600/80 px-2.5 py-1 rounded-xl shadow-sm">
          <span>🚜</span>
          <span>Playground</span>
        </div>
      </div>
    </div>
  );
};
