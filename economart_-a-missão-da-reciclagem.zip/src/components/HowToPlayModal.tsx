/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Flame, Sparkles } from 'lucide-react';
import { soundManager } from '../game/audio';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-slate-900 border-2 border-amber-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <span className="text-2xl">📖</span>
            <h2 className="text-xl sm:text-2xl font-black text-amber-400 font-['Fredoka']">
              Manual do Guardião dos Pneus
            </h2>
          </div>
          <button
            onClick={() => {
              soundManager.playPickup();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm">
          <div>
            <h3 className="text-base font-bold text-amber-300 mb-3 flex items-center gap-2">
              <span>♻️</span> Descarte e Destinação dos Pneus
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/30 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-lg shrink-0">
                  🚗
                </div>
                <div>
                  <h4 className="font-bold text-amber-400 text-sm">Pneu de Carro → Asfalto</h4>
                  <p className="text-xs text-slate-300">Moídos para massa de asfalto ecológico com menor ruído.</p>
                </div>
              </div>
              <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/30 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-red-500 flex items-center justify-center text-lg shrink-0">
                  🚛
                </div>
                <div>
                  <h4 className="font-bold text-red-400 text-sm">Pneu de Caminhão → Triturador</h4>
                  <p className="text-xs text-slate-300">Pneus pesados triturados para pisos industriais e esteiras.</p>
                </div>
              </div>
              <div className="p-3 rounded-2xl bg-sky-950/40 border border-sky-500/30 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-sky-500 flex items-center justify-center text-lg shrink-0">
                  🦟
                </div>
                <div>
                  <h4 className="font-bold text-sky-400 text-sm">Pneu com Água → Anti-Dengue</h4>
                  <p className="text-xs text-slate-300">Drenagem urgente para eliminar focos do mosquito transmissor da Dengue!</p>
                </div>
              </div>
              <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-lg shrink-0">
                  🏍️
                </div>
                <div>
                  <h4 className="font-bold text-emerald-400 text-sm">Pneu de Moto → Calçados</h4>
                  <p className="text-xs text-slate-300">Borracha vulcanizada transformada em solados de calçados duráveis.</p>
                </div>
              </div>
              <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-500/30 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-600 flex items-center justify-center text-lg shrink-0">
                  🚜
                </div>
                <div>
                  <h4 className="font-bold text-purple-400 text-sm">Pneu de Trator → Playgrounds</h4>
                  <p className="text-xs text-slate-300">Pneus gigantes para parques infantis e pisos amortecedores de impacto.</p>
                </div>
              </div>
              <div className="p-3 rounded-2xl bg-orange-950/40 border border-orange-500/30 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-orange-600 flex items-center justify-center text-lg shrink-0">
                  🍂
                </div>
                <div>
                  <h4 className="font-bold text-orange-400 text-sm">Borracha Moída → Isolamento</h4>
                  <p className="text-xs text-slate-300">Isolamento acústico na construção civil e gramados sintéticos.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-950/40 border-2 border-amber-500/50 space-y-2">
            <h3 className="text-base font-black text-amber-300 flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400 fill-amber-400 animate-pulse" />
              <span>Multiplicador de Combo de Reciclagem</span>
            </h3>
            <p className="text-xs text-amber-100/90 leading-relaxed">
              Recicle múltiplos pneus em sequência rápida (em até <strong>6.5 segundos</strong>) <strong>sem sofrer dano</strong> para disparar o seu multiplicador de pontos!
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs pt-1">
              <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-700">
                <span className="font-black text-emerald-400 block text-sm">1x</span>
                <span className="text-[10px] text-slate-300">100 pts</span>
              </div>
              <div className="bg-slate-900/80 p-2 rounded-xl border border-amber-400">
                <span className="font-black text-amber-300 block text-sm">🔥 2x</span>
                <span className="text-[10px] text-slate-300">200 pts</span>
              </div>
              <div className="bg-slate-900/80 p-2 rounded-xl border border-orange-400">
                <span className="font-black text-orange-400 block text-sm">⚡ 3x</span>
                <span className="text-[10px] text-slate-300">300 pts</span>
              </div>
              <div className="bg-slate-900/80 p-2 rounded-xl border border-rose-500">
                <span className="font-black text-rose-400 block text-sm">👑 4x a 10x!</span>
                <span className="text-[10px] text-slate-300">Até 1000 pts</span>
              </div>
            </div>
            <p className="text-[11px] text-rose-300 font-bold pt-1">
              ⚠️ Se você tomar dano de um pneu inimigo ou clicar na lixeira errada, seu combo é quebrado na hora!
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-amber-950/50 border border-emerald-500/40">
            <h3 className="text-base font-bold text-emerald-300 mb-2 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <span>Combos de Ataque do Economart ⚔️</span>
            </h3>
            <p className="text-xs text-slate-200 leading-relaxed mb-3">
              Aperte o botão de ataque em rápida sucessão para desencadear o combo de 3 etapas com a <strong>Eco-Espada</strong>:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs mb-3">
              <div className="p-2.5 rounded-xl bg-slate-950/70 border border-emerald-500/40">
                <span className="font-black text-emerald-400 block text-xs mb-0.5">1/3 Corte Rápido</span>
                <span className="text-[11px] text-slate-300">Golpe frontal ágil + projétil de energia esmeralda.</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/70 border border-sky-500/40">
                <span className="font-black text-sky-400 block text-xs mb-0.5">2/3 Golpe Cruzado</span>
                <span className="text-[11px] text-slate-300">Avanço rápido + corte duplo em X com lâminas gêmeas azuis.</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/70 border border-amber-400/60 ring-1 ring-amber-400/50">
                <span className="font-black text-amber-300 block text-xs mb-0.5">3/3 Vórtice Finalizador!</span>
                <span className="text-[11px] text-slate-300">Giro 360° em área + tremor de tela + onda tripla dourada!</span>
              </div>
            </div>
            <p className="text-[11px] text-amber-200 font-semibold">
              ⚡ <strong>Hit Streak:</strong> Acertar inimigos consecutivamente acumula <em>3 HITS</em>, <em>5 HITS</em> até <em>10+ HITS</em>, garantindo bônus massivos de pontos e dano amplificado! Tomar dano quebra o streak!
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/40">
            <h3 className="text-base font-bold text-red-400 mb-2 flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400" />
              <span>O Chefe SUPER PNEU & Pneus do Mal</span>
            </h3>
            <p className="text-xs text-slate-200 leading-relaxed mb-3">
              Pneus abandonados viraram monstros! O maior perigo é o lendário <strong>SUPER PNEU</strong> (Fase 5), que possui 3 ataques mortais:
            </p>
            <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-red-300">Arremesso de Pneus:</strong> Lança pneus rolantes velozes que saltam na sua direção.
              </li>
              <li>
                <strong className="text-amber-300">Chamas de Borracha:</strong> Dispara labaredas de fogo tóxico no ar.
              </li>
              <li>
                <strong className="text-yellow-300">Arremesso de Carros (🚗):</strong> O Super Pneu arremessa carcaças inteiras de carros pesados pelo ar! Salte nas plataformas para não ser esmagado!
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-base font-bold text-emerald-300 mb-3 flex items-center gap-2">
              <span>🎮</span> Comandos
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <span className="block font-mono text-base font-black text-amber-400 mb-1">A / D ou ⬅️ ➡️</span>
                <span className="text-slate-300">Andar</span>
              </div>
              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <span className="block font-mono text-base font-black text-amber-400 mb-1">W ou ⬆️</span>
                <span className="text-slate-300">Pular</span>
              </div>
              <div className="bg-slate-800/80 p-3 rounded-xl border border-emerald-500/50 bg-emerald-950/20">
                <span className="block font-mono text-base font-black text-emerald-400 mb-1">ESPAÇO / Z</span>
                <span className="text-emerald-200">⚔️ Espada (Até 5 por vez)</span>
              </div>
              <div className="bg-slate-800/80 p-3 rounded-xl border border-amber-500/50 bg-amber-950/20">
                <span className="block font-mono text-base font-black text-amber-300 mb-1">X ou Clique</span>
                <span className="text-amber-200">🗑️ Descartar Pneu no Lixo</span>
              </div>
            </div>
            <p className="text-xs text-slate-300 mt-2">
              💡 <strong>Combate & Descarte:</strong> Você possui limite de até <strong>5 ataques por vez</strong> (recarregam rapidamente). Ande sobre um pneu para pegá-lo e aperte <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-amber-300 font-bold">X</kbd> ou clique na lixeira para enviá-lo ao destino correto!
            </p>
          </div>
        </div>

        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end">
          <button
            onClick={() => {
              soundManager.playPickup();
              onClose();
            }}
            className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-sm transition-all cursor-pointer"
          >
            Entendido, Vamos Lutar!
          </button>
        </div>
      </div>
    </div>
  );
};
