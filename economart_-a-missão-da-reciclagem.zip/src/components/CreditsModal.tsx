/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Heart, Globe, Recycle, Award } from 'lucide-react';
import { soundManager } from '../game/audio';

interface CreditsModalProps {
  onClose: () => void;
}

export const CreditsModal: React.FC<CreditsModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-amber-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🌱</span>
            <h2 className="text-xl font-black text-amber-400 font-['Fredoka']">
              Créditos & Reciclagem de Pneus
            </h2>
          </div>
          <button
            onClick={() => {
              soundManager.playPickup();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-sm">
          <div className="text-center space-y-2">
            <h3 className="text-lg font-bold text-white font-['Fredoka']">Guardiões: A Batalha dos Pneus</h3>
            <p className="text-xs text-amber-300">
              Conscientização sobre Descarte Responsável e Logística Reversa de Pneus
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/20 text-xs text-slate-300 space-y-3 leading-relaxed">
            <div className="flex items-start gap-2.5">
              <Recycle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Economia Circular da Borracha:</strong> Pneus inservíveis não devem ser descartados em terrenos baldios ou queimados. Eles podem ser 100% triturados e reaproveitados em pavimentação de rodovias, calçados e pisos esportivos.
              </span>
            </div>
            <div className="flex items-start gap-2.5">
              <Globe className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <span>
                <strong>Prevenção de Epidemias:</strong> Ao evitar pneus a céu aberto, eliminamos os reservatórios de água limpa e parada onde se reproduzem os mosquitos transmissores de Dengue, Zika e Chikungunya.
              </span>
            </div>
            <div className="flex items-start gap-2.5">
              <Award className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                <strong>Jogabilidade:</strong> Canvas 2D em 60 FPS, física de plataformas, ataques ecológicos, arremesso de projéteis (pneus, fogo e carros) e síntese sonora Web Audio API em tempo real.
              </span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400">
            <span>Desenvolvido com</span>
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 inline" />
            <span>para inspirar a proteção do nosso meio ambiente.</span>
          </div>
        </div>

        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end">
          <button
            onClick={() => {
              soundManager.playPickup();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs transition-all cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
