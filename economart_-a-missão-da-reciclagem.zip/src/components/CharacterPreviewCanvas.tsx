/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { CharacterSkin } from '../game/skins';

interface CharacterPreviewCanvasProps {
  skin: CharacterSkin;
  playerName: string;
}

export const CharacterPreviewCanvas: React.FC<CharacterPreviewCanvasProps> = ({ skin, playerName }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const render = () => {
      time += 0.03;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const cx = canvas.width / 2;
      const cy = canvas.height / 2 + 10;
      const breathe = Math.sin(time * 4) * 1.5;
      const capeWiggle = Math.sin(time * 4) * 4;

      ctx.save();
      ctx.translate(cx, cy);

      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(0, 30, 18, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = skin.capeColor;
      ctx.beginPath();
      ctx.moveTo(-10, -6);
      ctx.lineTo(-24 + capeWiggle, 16);
      ctx.lineTo(-12 + capeWiggle * 0.5, 20);
      ctx.lineTo(-6, 8);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = skin.pantsColor;
      ctx.fillRect(-8, 14, 6, 12);
      ctx.fillRect(2, 14, 6, 12);

      ctx.fillStyle = skin.bootsColor;
      ctx.fillRect(-10, 22, 9, 5);
      ctx.fillRect(0, 22, 9, 5);

      ctx.fillStyle = skin.jacketColor;
      ctx.beginPath();
      ctx.roundRect(-12, -8 + breathe, 24, 24, 6);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(0, 2 + breathe, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = skin.emblemColor;
      ctx.font = 'bold 7px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(skin.emblemSymbol || '🌱', 0, 2 + breathe);

      ctx.fillStyle = skin.handleColor || '#78350F';
      ctx.fillRect(-12, 10 + breathe, 24, 4);

      ctx.fillStyle = '#FCD34D';
      ctx.beginPath();
      ctx.arc(0, -18 + breathe, 12, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = skin.helmetColor;
      ctx.beginPath();
      ctx.arc(0, -22 + breathe, 13, Math.PI, 0, false);
      ctx.fill();
      ctx.fillRect(0, -23 + breathe, 14, 4);

      ctx.fillStyle = '#0F172A';
      ctx.beginPath();
      ctx.arc(4, -18 + breathe, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(5, -19 + breathe, 1, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#0F172A';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(4, -14 + breathe, 3, 0.1, Math.PI * 0.85);
      ctx.stroke();

      ctx.fillStyle = skin.jacketColor;
      ctx.fillRect(-2, -4 + breathe, 6, 14);
      ctx.save();
      ctx.translate(6, 6 + breathe);
      ctx.rotate(-0.4);
      ctx.fillStyle = skin.handleColor;
      ctx.fillRect(-4, -2, 6, 3);
      ctx.fillStyle = skin.guardColor;
      ctx.fillRect(2, -5, 3, 9);
      ctx.fillStyle = skin.bladeColor;
      ctx.beginPath();
      ctx.moveTo(5, -2);
      ctx.lineTo(30, 0);
      ctx.lineTo(5, 2);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = skin.bladeCoreColor || '#FFFFFF';
      ctx.fillRect(6, -0.5, 20, 1);
      ctx.restore();

      ctx.restore();

      if (playerName) {
        ctx.save();
        ctx.font = 'bold 9px "Fredoka", sans-serif';
        const metrics = ctx.measureText(playerName);
        const tagW = Math.max(metrics.width + 12, 34);
        const tagH = 14;
        const tagX = cx;
        const tagY = cy - 40 + breathe;
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.beginPath();
        ctx.roundRect(tagX - tagW / 2, tagY - tagH / 2, tagW, tagH, 5);
        ctx.fill();
        ctx.strokeStyle = skin.slashColor;
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(playerName, tagX, tagY);
        ctx.restore();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [skin, playerName]);

  return (
    <canvas
      ref={canvasRef}
      width={120}
      height={120}
      className="w-24 h-24 sm:w-28 sm:h-28 mx-auto drop-shadow-md"
    />
  );
};
