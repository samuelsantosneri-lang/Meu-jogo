/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, RotateCcw, Home, Volume2, VolumeX } from 'lucide-react';
import { soundManager } from '../game/audio';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onMainMenu: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onMainMenu,
  isMuted,
  onToggleMute,
}) => {
  const [musicTheme, setMusicTheme] = React.useState<'horror' | 'retro'>(() => soundManager.getMusicTheme());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-sm bg-slate-900 border-2 border-slate-700 rounded-3xl shadow-2xl p-6 flex flex-col text-slate-100 text-center space-y-4">
        <h2 className="text-2xl font-black text-white font-['Fredoka']">
          Jogo Pausado
        </h2>
        <p className="text-xs text-slate-400">
          Respire fundo e recicle com sabedoria!
        </p>

        <div className="flex flex-col gap-2.5 pt-2">
          <button
            onClick={() => {
              soundManager.playPickup();
              onResume();
            }}
            className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-emerald-950 font-black py-3 px-4 rounded-xl text-sm transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-emerald-950" />
            <span>Continuar</span>
          </button>
          <button
            onClick={() => {
              soundManager.playPickup();
              onRestart();
            }}
            className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold py-3 px-4 rounded-xl text-sm transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reiniciar Fase</span>
          </button>
          <button
            onClick={() => {
              soundManager.playPickup();
              onToggleMute();
            }}
            className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold py-3 px-4 rounded-xl text-sm transition-all cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            <span>{isMuted ? 'Ativar Som' : 'Silenciar Som'}</span>
          </button>
          <button
            onClick={() => {
              soundManager.playPickup();
              const newTheme = soundManager.toggleMusicTheme();
              setMusicTheme(newTheme);
            }}
            className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold py-3 px-4 rounded-xl text-sm transition-all cursor-pointer border border-amber-500/30"
          >
            <span>{musicTheme === 'horror' ? '🦇' : '🕹️'}</span>
            <span>Música: {musicTheme === 'horror' ? 'Terror Sinistro' : 'Retrô Clássica'}</span>
          </button>
          <button
            onClick={() => {
              soundManager.playPickup();
              onMainMenu();
            }}
            className="flex items-center justify-center gap-2 bg-red-950/40 hover:bg-red-900/60 active:scale-95 text-red-300 font-bold py-3 px-4 rounded-xl text-sm transition-all border border-red-500/20 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>Menu Principal</span>
          </button>
        </div>
      </div>
    </div>
  );
};
