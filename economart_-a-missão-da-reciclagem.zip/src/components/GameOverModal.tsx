/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RotateCcw, Home, HeartCrack } from 'lucide-react';
import { soundManager } from '../game/audio';

interface GameOverModalProps {
  score: number;
  trashRecycled: number;
  maxCombo?: number;
  playerName?: string;
  onRetry: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  trashRecycled,
  maxCombo = 1,
  playerName,
  onRetry,
  onMainMenu,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-md bg-slate-900 border-2 border-red-500/50 rounded-3xl shadow-2xl p-6 sm:p-8 flex flex-col text-slate-100 text-center">
        <div className="mx-auto w-20 h-20 rounded-2xl bg-red-950/60 border-2 border-red-500/40 flex items-center justify-center text-4xl mb-4 shadow-lg text-red-400">
          <HeartCrack className="w-10 h-10 text-red-500 animate-pulse" />
        </div>

        <h2 className="text-3xl sm:text-4xl font-black text-red-500 font-['Fredoka'] tracking-wider mb-1">
          GAME OVER
        </h2>
        <p className="text-base font-bold text-amber-300 mb-6 font-['Fredoka']">
          Não desista, <strong className="text-white">{playerName || 'Guardião'}</strong>! O planeta precisa de você!
        </p>

        <div className="grid grid-cols-3 gap-2 mb-6 bg-slate-800/80 p-3 sm:p-4 rounded-2xl border border-slate-700/60">
          <div>
            <span className="text-[11px] text-slate-400 block mb-0.5">Pontuação</span>
            <span className="font-mono text-lg font-black text-amber-400 tabular-nums">
              {score}
            </span>
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block mb-0.5">Reciclados</span>
            <span className="font-mono text-lg font-black text-emerald-400 tabular-nums">
              {trashRecycled}
            </span>
          </div>
          <div>
            <span className="text-[11px] text-amber-300/80 block mb-0.5">Maior Combo</span>
            <span className="font-mono text-lg font-black text-amber-300 tabular-nums">
              x{Math.max(1, maxCombo)}
            </span>
          </div>
        </div>

        <p className="text-xs text-slate-400 mb-6 leading-relaxed">
          Não desanime! A reciclagem e a proteção da natureza exigem perseverança. Tente novamente!
        </p>

        <div className="flex flex-col gap-3">
          <button
            onClick={() => {
              soundManager.playJump();
              onRetry();
            }}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 active:scale-95 text-emerald-950 font-black text-base py-3.5 px-6 rounded-2xl shadow-xl border-2 border-emerald-300 transition-all cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" />
            <span>Tentar Novamente</span>
          </button>
          <button
            onClick={() => {
              soundManager.playPickup();
              onMainMenu();
            }}
            className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 font-bold text-sm py-3 px-6 rounded-2xl border border-slate-700 transition-all cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>Menu Principal</span>
          </button>
        </div>
      </div>
    </div>
  );
};
