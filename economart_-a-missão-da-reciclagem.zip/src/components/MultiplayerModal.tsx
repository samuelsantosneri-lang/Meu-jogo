/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Users,
  Play,
  X,
  Copy,
  Check,
  RefreshCw,
  Wifi,
  WifiOff,
  AlertTriangle,
  Crown,
  Sparkles,
} from 'lucide-react';
import { networkManager, NetworkRoomState } from '../game/network';
import { soundManager } from '../game/audio';
import { getSkinById } from '../game/skins';

interface MultiplayerModalProps {
  playerName: string;
  selectedSkinId: string;
  onClose: () => void;
  onStartCoopGame: (roomState: NetworkRoomState) => void;
}

export const MultiplayerModal: React.FC<MultiplayerModalProps> = ({
  playerName,
  selectedSkinId,
  onClose,
  onStartCoopGame,
}) => {
  const [roomIdInput, setRoomIdInput] = useState<string>('PNEU-1');
  const [roomState, setRoomState] = useState<NetworkRoomState | null>(null);
  const [inLobby, setInLobby] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [availableRooms, setAvailableRooms] = useState<Array<{ id: string; playerCount: number; hostName: string }>>([]);
  const [isLoadingRooms, setIsLoadingRooms] = useState<boolean>(false);
  const [isReady, setIsReady] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<string>('connected');
  const [temporaryDisconnectAlert, setTemporaryDisconnectAlert] = useState<string | null>(null);

  // Fetch available rooms
  const fetchRooms = async () => {
    setIsLoadingRooms(true);
    try {
      const res = await fetch('/api/rooms');
      if (res.ok) {
        const data = await res.json();
        setAvailableRooms(data.rooms || []);
      }
    } catch {
      // Ignore
    } finally {
      setIsLoadingRooms(false);
    }
  };

  useEffect(() => {
    networkManager.connect().then(() => {
      fetchRooms();
    });

    const handleRoomJoined = (data: any) => {
      setRoomState(data.roomState);
      setInLobby(true);
      setErrorMessage(null);
      soundManager.playPickup();
    };

    const handleReconnectedSuccess = (data: any) => {
      setRoomState(data.roomState);
      setInLobby(true);
      setErrorMessage(null);
      setTemporaryDisconnectAlert(null);
      soundManager.playLevelComplete();
    };

    const handleRoomUpdated = (data: any) => {
      setRoomState(data.roomState);
    };

    const handlePlayerTempDisconnect = (data: any) => {
      setRoomState(data.roomState);
      setTemporaryDisconnectAlert(`⚠️ ${data.playerName} teve uma queda de conexão! Aguardando reconexão...`);
      soundManager.playRecycleError();
    };

    const handlePlayerReconnected = (data: any) => {
      setRoomState(data.roomState);
      setTemporaryDisconnectAlert(null);
      soundManager.playPickup();
    };

    const handlePlayerLeft = (data: any) => {
      setRoomState(data.roomState);
      if (data.reason === 'timeout') {
        setTemporaryDisconnectAlert(`Tempo esgotado: ${data.playerName} não reconectou.`);
      } else {
        setTemporaryDisconnectAlert(null);
      }
    };

    const handleRoomFull = (data: any) => {
      setErrorMessage(data.message || 'Sala cheia!');
      soundManager.playRecycleError();
    };

    const handleGameStarted = (data: any) => {
      soundManager.playJump();
      onStartCoopGame(data.roomState || roomState!);
    };

    const handleConnChange = (status: string) => {
      setConnectionStatus(status);
    };

    networkManager.on('joined_room', handleRoomJoined);
    networkManager.on('reconnected_success', handleReconnectedSuccess);
    networkManager.on('room_updated', handleRoomUpdated);
    networkManager.on('player_disconnected_temporary', handlePlayerTempDisconnect);
    networkManager.on('player_reconnected', handlePlayerReconnected);
    networkManager.on('player_left', handlePlayerLeft);
    networkManager.on('room_full', handleRoomFull);
    networkManager.on('game_started', handleGameStarted);
    networkManager.on('connection_state_changed', handleConnChange);

    return () => {
      networkManager.off('joined_room', handleRoomJoined);
      networkManager.off('reconnected_success', handleReconnectedSuccess);
      networkManager.off('room_updated', handleRoomUpdated);
      networkManager.off('player_disconnected_temporary', handlePlayerTempDisconnect);
      networkManager.off('player_reconnected', handlePlayerReconnected);
      networkManager.off('player_left', handlePlayerLeft);
      networkManager.off('room_full', handleRoomFull);
      networkManager.off('game_started', handleGameStarted);
      networkManager.off('connection_state_changed', handleConnChange);
    };
  }, [onStartCoopGame, roomState]);

  const handleJoinOrCreate = (targetRoomId: string) => {
    const code = (targetRoomId || roomIdInput).trim().toUpperCase();
    if (!code) return;
    setErrorMessage(null);
    networkManager.joinRoom(code, playerName, selectedSkinId);
  };

  const handleLeaveLobby = () => {
    soundManager.playPickup();
    networkManager.leaveRoom();
    setInLobby(false);
    setRoomState(null);
    setTemporaryDisconnectAlert(null);
    fetchRooms();
  };

  const handleToggleReady = () => {
    soundManager.playJump();
    const nextReady = !isReady;
    setIsReady(nextReady);
    networkManager.setReady(nextReady);
  };

  const handleStartGame = () => {
    if (!networkManager.isHost) return;
    soundManager.playJump();
    networkManager.startGame(1);
  };

  const handleCopyCode = () => {
    if (roomState) {
      navigator.clipboard.writeText(roomState.roomId);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const myPlayer = roomState?.players.find((p) => p.id === networkManager.playerId);
  const otherPlayer = roomState?.players.find((p) => p.id !== networkManager.playerId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-emerald-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <span className="text-xl">🌐</span>
            <h2 className="text-lg sm:text-xl font-black text-emerald-400 font-['Fredoka']">
              Modo Co-op Online (2 Jogadores)
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <div
              className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full border ${
                connectionStatus === 'connected'
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                  : 'bg-amber-950/80 text-amber-300 border-amber-500/50 animate-pulse'
              }`}
            >
              {connectionStatus === 'connected' ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
              <span>{connectionStatus === 'connected' ? 'Online' : 'Reconectando...'}</span>
            </div>
            <button
              onClick={() => {
                soundManager.playPickup();
                onClose();
              }}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-2xl bg-red-950/80 border border-red-500/60 text-xs font-bold text-red-200 flex items-center gap-2 animate-shake">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {temporaryDisconnectAlert && (
            <div className="p-3 rounded-2xl bg-amber-950/90 border border-amber-500 text-xs font-bold text-amber-200 flex items-center gap-2 animate-pulse">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{temporaryDisconnectAlert}</span>
            </div>
          )}

          {!inLobby ? (
            /* Room Entry / Search Screen */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <label className="text-xs font-black text-slate-300 block">
                  Código da Sala (Criar ou Entrar):
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={roomIdInput}
                    onChange={(e) => setRoomIdInput(e.target.value.toUpperCase())}
                    placeholder="Ex: PNEU-1"
                    maxLength={10}
                    className="flex-1 bg-slate-800/90 border border-slate-700 focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 rounded-xl px-3 py-2 text-sm font-black text-white uppercase tracking-wider outline-none"
                  />
                  <button
                    onClick={() => handleJoinOrCreate(roomIdInput)}
                    className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-xs px-5 py-2.5 rounded-xl transition-all cursor-pointer shadow-md flex items-center gap-1.5"
                  >
                    <Users className="w-4 h-4" />
                    <span>Entrar na Sala</span>
                  </button>
                </div>
              </div>

              {/* Open Rooms List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">Salas Abertas:</span>
                  <button
                    onClick={fetchRooms}
                    disabled={isLoadingRooms}
                    className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer font-bold"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingRooms ? 'animate-spin' : ''}`} />
                    <span>Atualizar</span>
                  </button>
                </div>

                {availableRooms.length === 0 ? (
                  <div className="text-center py-6 bg-slate-950/40 rounded-2xl border border-slate-800/80 text-xs text-slate-400">
                    Nenhuma outra sala aguardando no momento. Crie a sala acima e convide um amigo!
                  </div>
                ) : (
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {availableRooms.map((r) => (
                      <div
                        key={r.id}
                        className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-emerald-500/50 transition-colors"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm font-black text-amber-300">{r.id}</span>
                            <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full text-slate-300 font-semibold">
                              Host: {r.hostName}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400">{r.playerCount}/2 Jogadores</span>
                        </div>
                        <button
                          onClick={() => handleJoinOrCreate(r.id)}
                          className="bg-slate-800 hover:bg-emerald-600 active:scale-95 text-white text-xs font-black px-4 py-2 rounded-xl transition-colors cursor-pointer"
                        >
                          Entrar
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Information */}
              <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-slate-300 space-y-1">
                <p className="font-bold text-emerald-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Tratamento Automático de Quedas de Conexão</span>
                </p>
                <p className="text-[11px] text-slate-300/90 leading-relaxed">
                  Se a conexão cair por instabilidade de rede ou recarregamento, o servidor aguarda até <strong>25 segundos</strong> para que o jogador retorne sem perder a partida ou a pontuação!
                </p>
              </div>
            </div>
          ) : (
            /* Lobby Room Inside Screen */
            <div className="space-y-4">
              {/* Room Code Card */}
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-emerald-500/40 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                    Código da Sala
                  </span>
                  <span className="font-mono text-xl font-black text-amber-300 tracking-wider">
                    {roomState?.roomId}
                  </span>
                </div>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 active:scale-95 px-3 py-1.5 rounded-xl text-xs font-bold text-white transition-colors cursor-pointer"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>

              {/* Players in Room */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-300 block">
                  Jogadores ({roomState?.players.length}/2):
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Player 1 Slot */}
                  {myPlayer && (
                    <div className="p-3 rounded-2xl bg-slate-950/90 border-2 border-emerald-500/60 flex items-center gap-3">
                      <span className="text-2xl">{getSkinById(myPlayer.skinId).icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-black text-sm text-white truncate font-['Fredoka']">
                            {myPlayer.name}
                          </span>
                          {myPlayer.isHost && <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                        </div>
                        <span className="text-[10px] text-emerald-400 font-bold block">
                          Você {myPlayer.isHost ? '(Host)' : ''}
                        </span>
                      </div>
                      <span className="text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                        Pronto
                      </span>
                    </div>
                  )}

                  {/* Player 2 Slot */}
                  {otherPlayer ? (
                    <div
                      className={`p-3 rounded-2xl border flex items-center gap-3 ${
                        otherPlayer.isDisconnected
                          ? 'bg-amber-950/80 border-amber-500/80'
                          : 'bg-slate-950/90 border-sky-500/60'
                      }`}
                    >
                      <span className="text-2xl">{getSkinById(otherPlayer.skinId).icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-black text-sm text-white truncate font-['Fredoka']">
                            {otherPlayer.name}
                          </span>
                          {otherPlayer.isHost && <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                        </div>
                        <span className="text-[10px] text-sky-400 font-bold block">
                          {otherPlayer.isDisconnected ? 'Reconectando...' : 'Parceiro Co-op'}
                        </span>
                      </div>
                      <span
                        className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
                          otherPlayer.isDisconnected
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500 animate-pulse'
                            : otherPlayer.isReady
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-slate-800 text-slate-400 border-slate-700'
                        }`}
                      >
                        {otherPlayer.isDisconnected
                          ? 'Queda de Sinal'
                          : otherPlayer.isReady
                          ? 'Pronto'
                          : 'Aguardando'}
                      </span>
                    </div>
                  ) : (
                    <div className="p-3 rounded-2xl bg-slate-950/40 border-2 border-dashed border-slate-800 flex items-center justify-center text-center">
                      <span className="text-xs text-slate-500 font-bold">
                        Aguardando parceiro entrar...
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  onClick={handleLeaveLobby}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-bold text-xs py-3 px-4 rounded-xl transition-all cursor-pointer"
                >
                  Sair da Sala
                </button>

                {networkManager.isHost ? (
                  <button
                    onClick={handleStartGame}
                    disabled={!otherPlayer}
                    className={`flex-1 flex items-center justify-center gap-2 font-black text-xs py-3 px-4 rounded-xl transition-all shadow-lg ${
                      otherPlayer
                        ? 'bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 cursor-pointer active:scale-95'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-60'
                    }`}
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Iniciar Partida Co-op</span>
                  </button>
                ) : (
                  <button
                    onClick={handleToggleReady}
                    className={`flex-1 font-black text-xs py-3 px-4 rounded-xl transition-all cursor-pointer shadow-lg active:scale-95 ${
                      isReady
                        ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                        : 'bg-emerald-600 text-white hover:bg-emerald-500'
                    }`}
                  >
                    <span>{isReady ? 'Cancelar Pronto' : 'Estou Pronto!'}</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
