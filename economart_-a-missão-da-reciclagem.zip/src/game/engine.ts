/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Enemy,
  FloatingText,
  GameMode,
  GameStats,
  GameView,
  LevelConfig,
  Particle,
  Platform,
  PlayerState,
  Projectile,
  RecycleBin,
  TrashCategory,
  TrashItem,
} from './types';
import { soundManager } from './audio';
import { LEVELS, TRASH_CATEGORY_INFO } from './levels';
import { DEFAULT_PLAYER_NAME, DEFAULT_SKIN_ID } from './skins';

export class GameEngine {
  public canvasWidth: number = 1000;
  public canvasHeight: number = 600;
  public playerName: string = DEFAULT_PLAYER_NAME;
  public playerSkinId: string = DEFAULT_SKIN_ID;
  public gameMode: GameMode = 'single';
  public player: PlayerState;
  public player2: PlayerState | null = null;
  public player2Name: string = 'Eco-Amigo';
  public player2SkinId: string = 'eco_classic';
  public trashItems: TrashItem[] = [];
  public recycleBins: RecycleBin[] = [];
  public enemies: Enemy[] = [];
  public projectiles: Projectile[] = [];
  public particles: Particle[] = [];
  public floatingTexts: FloatingText[] = [];
  public platforms: Platform[] = [];
  public currentLevelConfig: LevelConfig;
  public stats: GameStats;
  public view: GameView = 'TITLE';
  public time: number = 0;
  public screenShake: number = 0;
  public levelRecycledCount: number = 0;
  public totalTrashInLevel: number = 0;
  public levelMonstersDefeatedCount: number = 0;

  // Player 1 input keys (WASD / Space / Z / X)
  public keys: {
    left: boolean;
    right: boolean;
    jump: boolean;
    attack: boolean;
    depositX: boolean;
    interact: boolean;
  } = {
    left: false,
    right: false,
    jump: false,
    attack: false,
    depositX: false,
    interact: false,
  };

  // Player 2 input keys for Local Co-op (Arrows / Enter / L / K)
  public keysP2: {
    left: boolean;
    right: boolean;
    jump: boolean;
    attack: boolean;
    depositX: boolean;
    interact: boolean;
  } = {
    left: false,
    right: false,
    jump: false,
    attack: false,
    depositX: false,
    interact: false,
  };

  private onStateChangeCallback: (() => void) | null = null;

  constructor() {
    try {
      const savedName = localStorage.getItem('reciclagem_player_name');
      if (savedName && savedName.trim()) {
        this.playerName = savedName.trim();
      }
      const savedSkin = localStorage.getItem('reciclagem_player_skin');
      if (savedSkin) {
        this.playerSkinId = savedSkin;
      }
    } catch {
      // storage unavailable fallback
    }

    this.currentLevelConfig = LEVELS[0];
    this.player = this.createDefaultPlayer();
    this.stats = {
      score: 0,
      trashRecycled: 0,
      trashFailed: 0,
      monstersDefeated: 0,
      currentLevel: 1,
      highScore: Number(localStorage.getItem('reciclagem_pneus_high_score') || '0'),
      comboCount: 0,
      comboMultiplier: 1,
      comboTimer: 0,
      maxComboTimer: 6.5,
      maxCombo: 0,
      comboBonusScore: 0,
      attackHitStreak: 0,
      maxAttackHitStreak: 0,
      attackHitStreakTimer: 0,
    };
  }

  public setPlayerCustomization(name: string, skinId: string) {
    const trimmed = name.trim();
    this.playerName = trimmed || DEFAULT_PLAYER_NAME;
    this.playerSkinId = skinId || DEFAULT_SKIN_ID;
    this.player.name = this.playerName;
    this.player.skinId = this.playerSkinId;
    try {
      localStorage.setItem('reciclagem_player_name', this.playerName);
      localStorage.setItem('reciclagem_player_skin', this.playerSkinId);
    } catch {
      // storage quota fallback
    }
    this.notify();
  }

  public setPlayer2Customization(name: string, skinId: string) {
    const trimmed = name.trim();
    this.player2Name = trimmed || 'Eco-Amigo';
    this.player2SkinId = skinId || 'eco_classic';
    if (this.player2) {
      this.player2.name = this.player2Name;
      this.player2.skinId = this.player2SkinId;
    }
    this.notify();
  }

  public setGameMode(mode: GameMode, p2Name?: string, p2SkinId?: string) {
    this.gameMode = mode;
    if (p2Name) this.player2Name = p2Name;
    if (p2SkinId) this.player2SkinId = p2SkinId;
    if (mode === 'local_coop' || mode === 'online_coop') {
      this.player2 = this.createDefaultPlayer(2, this.player2Name, this.player2SkinId, 150);
    } else {
      this.player2 = null;
    }
    this.notify();
  }

  public setOnStateChange(cb: () => void) {
    this.onStateChangeCallback = cb;
  }

  private notify() {
    if (this.onStateChangeCallback) {
      this.onStateChangeCallback();
    }
  }

  public createDefaultPlayer(index: 1 | 2 = 1, name?: string, skinId?: string, startX: number = 80): PlayerState {
    return {
      name: name || (index === 1 ? this.playerName || DEFAULT_PLAYER_NAME : this.player2Name || 'Eco-Amigo'),
      skinId: skinId || (index === 1 ? this.playerSkinId || DEFAULT_SKIN_ID : this.player2SkinId || 'eco_classic'),
      playerIndex: index,
      x: startX,
      y: 430,
      vx: 0,
      vy: 0,
      width: 32,
      height: 48,
      isGrounded: false,
      facing: 1,
      hp: 5,
      maxHp: 5,
      invincibleTimer: 0,
      attackCooldown: 0,
      carriedItem: null,
      walkFrame: 0,
      isAttacking: false,
      attackAnimTimer: 0,
      isSwordSlashing: false,
      swordSlashTimer: 0,
      attackCharges: 5,
      maxAttackCharges: 5,
      chargeRegenTimer: 0,
      attackComboStep: 1,
      comboWindowTimer: 0,
      isKnockedOut: false,
      reviveProgress: 0,
    };
  }

  public startLevel(levelIndex: number) {
    const config = LEVELS[levelIndex] || LEVELS[0];
    this.currentLevelConfig = config;
    this.stats.currentLevel = config.id;
    this.stats.comboCount = 0;
    this.stats.comboMultiplier = 1;
    this.stats.comboTimer = 0;
    this.stats.attackHitStreak = 0;
    this.stats.attackHitStreakTimer = 0;
    this.levelRecycledCount = 0;
    this.levelMonstersDefeatedCount = 0;
    this.totalTrashInLevel = config.trashItemsToSpawn.length;

    this.player.x = 80;
    this.player.y = 430;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.isGrounded = false;
    this.player.carriedItem = null;
    this.player.invincibleTimer = 0;
    this.player.attackCooldown = 0;
    this.player.isAttacking = false;
    this.player.attackComboStep = 1;
    this.player.comboWindowTimer = 0;
    this.player.isKnockedOut = false;
    this.player.reviveProgress = 0;

    if (this.player2) {
      this.player2.x = 150;
      this.player2.y = 430;
      this.player2.vx = 0;
      this.player2.vy = 0;
      this.player2.isGrounded = false;
      this.player2.carriedItem = null;
      this.player2.invincibleTimer = 0;
      this.player2.attackCooldown = 0;
      this.player2.isAttacking = false;
      this.player2.attackComboStep = 1;
      this.player2.comboWindowTimer = 0;
      this.player2.isKnockedOut = false;
      this.player2.reviveProgress = 0;
    }

    this.projectiles = [];
    this.particles = [];
    this.floatingTexts = [];
    this.enemies = [];
    this.platforms = [...config.platforms];

    this.trashItems = config.trashItemsToSpawn.map((item, idx) => ({
      id: `tire_${config.id}_${idx}_${Date.now()}`,
      category: item.category,
      name: item.name,
      x: item.x,
      y: item.y,
      width: 26,
      height: 26,
      vx: 0,
      vy: 0,
      isGrounded: false,
      isCarried: false,
      isRecycled: false,
      spawnTime: this.time,
    }));

    this.setupRecycleBins(config.availableBins);
    this.checkMonsterSpawns();

    this.view = 'PLAYING';
    soundManager.startBGM();

    if (config.id > 1) {
      const bonusHp = (config.id - 1) * 15;
      this.addFloatingText(500, 180, `⚡ FASE ${config.id}: INIMIGOS COM +${bonusHp} DE VIDA!`, '#F97316', 2.2);
    }
    if (config.id === 5) {
      this.addFloatingText(500, 220, '⚠️ ALERTA: SUPER PNEU COM +100 DE VIDA (136 HP TOTAL)!', '#EF4444', 2.8);
    }

    this.notify();
  }

  private setupRecycleBins(categories: TrashCategory[]) {
    this.recycleBins = [];
    const count = categories.length;
    const startX = 140;
    const spacing = Math.min(130, (800 - startX) / Math.max(1, count - 1));

    categories.forEach((cat, idx) => {
      const info = TRASH_CATEGORY_INFO[cat];
      const binX = count === 1 ? 480 : startX + idx * spacing;
      this.recycleBins.push({
        category: cat,
        label: info.name,
        colorName: info.binColorName,
        colorHex: info.binColorHex,
        darkColorHex: info.binDarkHex,
        x: binX,
        y: 440,
        width: 54,
        height: 60,
        icon: info.iconSymbol,
      });
    });
  }

  private checkMonsterSpawns() {
    const config = this.currentLevelConfig;
    for (const mConfig of config.monstersToSpawn) {
      if (this.levelRecycledCount >= mConfig.triggerRecycledCount) {
        const alreadyExists = this.enemies.some((e) => e.name === mConfig.name);
        if (!alreadyExists) {
          const isBoss = mConfig.type === 'super_pneu';
          const levelHpBonus = (config.id - 1) * 15;
          const finalHp = isBoss ? Math.max(136, mConfig.hp) : mConfig.hp + levelHpBonus;

          const enemy: Enemy = {
            id: `enemy_${mConfig.type}_${Date.now()}`,
            name: mConfig.name,
            type: mConfig.type,
            x: mConfig.x,
            y: mConfig.y,
            width: isBoss ? 84 : 40,
            height: isBoss ? 88 : 42,
            vx: -1.4,
            vy: 0,
            isGrounded: false,
            hp: finalHp,
            maxHp: finalHp,
            speed: isBoss ? 1.8 : mConfig.type === 'pneu_espinhoso' ? 3.0 : 2.0,
            facing: -1,
            attackCooldown: 1.6,
            attackTimer: 0,
            hurtTimer: 0,
            defeatTimer: 0,
            state: 'patrol',
            patrolMinX: Math.max(80, mConfig.x - 240),
            patrolMaxX: Math.min(920, mConfig.x + 180),
            isBoss,
            bossPhase: 1,
            rotation: 0,
          };
          this.enemies.push(enemy);

          if (isBoss) {
            soundManager.playBossRoar();
            this.addFloatingText(mConfig.x, mConfig.y - 45, '👑 O COLOSSAL SUPER PNEU! [136 HP (+100!)]', '#EF4444', 2.0);
            this.screenShake = 18;
          } else {
            soundManager.playEnemyHit();
            const bonusText = levelHpBonus > 0 ? ` (+${levelHpBonus} HP)` : '';
            this.addFloatingText(mConfig.x, mConfig.y - 20, `⚠️ ${mConfig.name} Surgiu! [${finalHp} HP${bonusText}]`, '#F97316', 1.3);
          }

          for (let i = 0; i < 22; i++) {
            this.particles.push({
              x: mConfig.x + (Math.random() - 0.5) * 45,
              y: mConfig.y + (Math.random() - 0.5) * 45,
              vx: (Math.random() - 0.5) * 5,
              vy: (Math.random() - 0.5) * 5,
              size: Math.random() * 8 + 4,
              color: isBoss ? '#EF4444' : '#1E293B',
              alpha: 0.9,
              life: 0,
              maxLife: 0.9,
              shape: 'smoke',
            });
          }
        }
      }
    }
  }

  // CLICK ON RECYCLING BIN (Supports both players in Co-op!)
  public handleRecycleBinClick(bin: RecycleBin, actingPlayer?: PlayerState) {
    if (this.view !== 'PLAYING') return;

    const p = actingPlayer || (this.player.carriedItem ? this.player : (this.player2?.carriedItem ? this.player2 : this.player));
    if (!p.carriedItem) {
      this.addFloatingText(
        bin.x + bin.width / 2,
        bin.y - 30,
        '💡 Colete um pneu primeiro andando sobre ele!',
        '#FACC15',
        1.0
      );
      return;
    }

    const carried = p.carriedItem;
    if (carried.category === bin.category) {
      if (this.stats.comboTimer > 0) {
        this.stats.comboCount++;
      } else {
        this.stats.comboCount = 1;
      }
      const multiplier = Math.min(10, this.stats.comboCount);
      this.stats.comboMultiplier = multiplier;
      this.stats.comboTimer = 6.5;
      this.stats.maxComboTimer = 6.5;
      this.stats.maxCombo = Math.max(this.stats.maxCombo, this.stats.comboCount);

      const baseScore = 100;
      const totalEarned = baseScore * multiplier;
      const bonusScore = totalEarned - baseScore;
      this.stats.score += totalEarned;
      this.stats.comboBonusScore += bonusScore;
      this.stats.trashRecycled++;
      this.levelRecycledCount++;

      if (p.playerIndex === 2) {
        this.stats.p2RecycledCount = (this.stats.p2RecycledCount || 0) + 1;
      } else {
        this.stats.p1RecycledCount = (this.stats.p1RecycledCount || 0) + 1;
      }

      const partner = p === this.player ? this.player2 : this.player;
      if (partner && partner.isKnockedOut) {
        partner.reviveProgress = Math.min(1, partner.reviveProgress + 0.55);
        if (partner.reviveProgress >= 1) {
          partner.isKnockedOut = false;
          partner.hp = 2;
          partner.invincibleTimer = 2.0;
          partner.reviveProgress = 0;
          soundManager.playLevelComplete();
          this.addFloatingText(partner.x + partner.width / 2, partner.y - 45, `✨ ${partner.name} REVIVIDO PELA RECICLAGEM!`, '#22C55E', 1.5);
        } else {
          this.addFloatingText(partner.x + partner.width / 2, partner.y - 40, '💚 Energia de Reanimação! (+50%)', '#4ADE80', 1.3);
        }

        for (let h = 0; h < 10; h++) {
          this.particles.push({
            x: bin.x + bin.width / 2,
            y: bin.y,
            vx: ((partner.x - bin.x) / 30) + (Math.random() - 0.5) * 3,
            vy: ((partner.y - bin.y) / 30) - 2,
            size: Math.random() * 5 + 3,
            color: '#22C55E',
            alpha: 1.0,
            life: 0,
            maxLife: 0.8,
            shape: 'leaf',
          });
        }
      }

      const startX = p.x + p.width / 2;
      const startY = p.y;
      const targetX = bin.x + bin.width / 2;
      const targetY = bin.y + 20;

      for (let i = 0; i < 15; i++) {
        const t = i / 15;
        this.particles.push({
          x: startX + (targetX - startX) * t,
          y: startY + (targetY - startY) * t - Math.sin(t * Math.PI) * 50,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          size: Math.random() * 5 + 3,
          color: multiplier >= 3 ? '#FACC15' : bin.colorHex,
          alpha: 1.0,
          life: 0,
          maxLife: 0.7,
          shape: 'spark',
        });
      }

      if (multiplier >= 5) {
        soundManager.playComboUp(multiplier);
        this.screenShake = 6;
        this.addFloatingText(
          bin.x + bin.width / 2,
          bin.y - 35,
          `🔥 COMBO LENDÁRIO x${multiplier}! +${totalEarned} PTS (+${bonusScore})`,
          '#F43F5E',
          1.55
        );
      } else if (multiplier === 4) {
        soundManager.playComboUp(multiplier);
        this.addFloatingText(
          bin.x + bin.width / 2,
          bin.y - 32,
          `⚡ MEGA COMBO x4! +${totalEarned} PTS (+${bonusScore})`,
          '#EC4899',
          1.45
        );
      } else if (multiplier === 3) {
        soundManager.playComboUp(multiplier);
        this.addFloatingText(
          bin.x + bin.width / 2,
          bin.y - 28,
          `✨ TRIPLO COMBO x3! +${totalEarned} PTS (+${bonusScore})`,
          '#F59E0B',
          1.38
        );
      } else if (multiplier === 2) {
        soundManager.playComboUp(multiplier);
        this.addFloatingText(
          bin.x + bin.width / 2,
          bin.y - 26,
          `🌟 DUPLO COMBO x2! +${totalEarned} PTS (+${bonusScore})`,
          '#EAB308',
          1.32
        );
      } else {
        soundManager.playRecycleSuccess();
        this.addFloatingText(
          bin.x + bin.width / 2,
          bin.y - 25,
          '♻️ Descarte Preciso! +100',
          '#22C55E',
          1.2
        );
      }

      const burstCount = Math.min(40, 20 + multiplier * 4);
      for (let i = 0; i < burstCount; i++) {
        const comboColor =
          multiplier >= 4
            ? ['#F43F5E', '#FACC15', '#38BDF8', '#22C55E'][i % 4]
            : multiplier >= 2
            ? ['#FACC15', bin.colorHex, '#38BDF8'][i % 3]
            : bin.colorHex;

        this.particles.push({
          x: bin.x + bin.width / 2,
          y: bin.y + 10,
          vx: (Math.random() - 0.5) * (7 + multiplier),
          vy: -Math.random() * (6 + multiplier) - 2,
          size: Math.random() * 6 + 3,
          color: comboColor,
          alpha: 1.0,
          life: 0,
          maxLife: 1.0,
          shape: Math.random() > 0.5 ? 'leaf' : 'star',
        });
      }

      carried.isRecycled = true;
      carried.isCarried = false;
      p.carriedItem = null;

      this.checkMonsterSpawns();
      this.notify();
    } else {
      soundManager.playRecycleError();
      this.stats.trashFailed++;
      this.stats.score = Math.max(0, this.stats.score - 25);
      if (this.stats.comboCount >= 2) {
        soundManager.playComboBreak();
        this.addFloatingText(
          bin.x + bin.width / 2,
          bin.y - 50,
          '💔 COMBO ZERADO! (Lixeira errada)',
          '#EF4444',
          1.25
        );
      }
      this.stats.comboCount = 0;
      this.stats.comboMultiplier = 1;
      this.stats.comboTimer = 0;

      const correctInfo = TRASH_CATEGORY_INFO[carried.category];
      this.addFloatingText(
        bin.x + bin.width / 2,
        bin.y - 35,
        `❌ Lixeira errada! Envie ${correctInfo.name} para ${correctInfo.binColorName}!`,
        '#EF4444',
        1.1
      );

      carried.isCarried = false;
      carried.x = p.facing === 1 ? p.x - 30 : p.x + p.width + 10;
      carried.y = p.y;
      carried.vx = p.facing * -2;
      carried.vy = -3;
      p.carriedItem = null;
      this.notify();
    }
  }

  public handleCanvasClick(cx: number, cy: number) {
    if (this.view !== 'PLAYING') return;
    for (const bin of this.recycleBins) {
      if (
        cx >= bin.x - 12 &&
        cx <= bin.x + bin.width + 12 &&
        cy >= bin.y - 15 &&
        cy <= bin.y + bin.height + 15
      ) {
        this.handleRecycleBinClick(bin);
        return;
      }
    }
  }

  public update(dt: number) {
    if (this.view !== 'PLAYING') return;

    const safeDt = Math.min(Math.max(dt, 0.008), 0.05);
    const timeScale = safeDt * 60;
    this.time += safeDt;

    if (this.screenShake > 0) {
      this.screenShake = Math.max(0, this.screenShake - safeDt * 35);
    }

    if (this.stats.comboTimer > 0) {
      this.stats.comboTimer = Math.max(0, this.stats.comboTimer - safeDt);
      if (this.stats.comboTimer === 0) {
        if (this.stats.comboCount >= 2) {
          this.addFloatingText(
            this.player.x + this.player.width / 2,
            this.player.y - 25,
            '⏳ Combo de Pneus Expirou!',
            '#94A3B8',
            1.0
          );
        }
        this.stats.comboCount = 0;
        this.stats.comboMultiplier = 1;
        this.notify();
      }
    }

    if (this.stats.attackHitStreakTimer > 0) {
      this.stats.attackHitStreakTimer = Math.max(0, this.stats.attackHitStreakTimer - safeDt);
      if (this.stats.attackHitStreakTimer === 0) {
        if (this.stats.attackHitStreak >= 3) {
          this.addFloatingText(
            this.player.x + this.player.width / 2,
            this.player.y - 35,
            '⏳ Hit Combo Finalizado!',
            '#94A3B8',
            0.95
          );
        }
        this.stats.attackHitStreak = 0;
        this.notify();
      }
    }

    this.updatePlayers(safeDt, timeScale);
    this.updateTrashItems(safeDt, timeScale);
    this.updateEnemies(safeDt, timeScale);
    this.updateProjectiles(safeDt, timeScale);
    this.updateParticles(safeDt, timeScale);
    this.updateFloatingTexts(safeDt);
    this.checkLevelCompletion();
  }

  private updatePlayers(dt: number, timeScale: number) {
    this.updatePlayerEntity(this.player, this.keys, dt, timeScale);
    if (this.gameMode === 'local_coop' && this.player2) {
      this.updatePlayerEntity(this.player2, this.keysP2, dt, timeScale);
    }

    if (this.gameMode !== 'single' && this.player2) {
      if (this.player.isKnockedOut && !this.player2.isKnockedOut) {
        const dist = Math.hypot(
          (this.player.x + this.player.width / 2) - (this.player2.x + this.player2.width / 2),
          (this.player.y + this.player.height / 2) - (this.player2.y + this.player2.height / 2)
        );
        if (dist < 60) {
          this.player.reviveProgress = Math.min(1, this.player.reviveProgress + dt / 1.6);
          if (this.player.reviveProgress >= 1) {
            this.player.isKnockedOut = false;
            this.player.hp = 2;
            this.player.invincibleTimer = 2.0;
            this.player.reviveProgress = 0;
            soundManager.playLevelComplete();
            this.addFloatingText(this.player.x + this.player.width / 2, this.player.y - 40, `✨ ${this.player.name} REVIVIDO!`, '#22C55E', 1.5);
          }
        } else {
          this.player.reviveProgress = Math.max(0, this.player.reviveProgress - dt * 0.4);
        }
      } else if (this.player2.isKnockedOut && !this.player.isKnockedOut) {
        const dist = Math.hypot(
          (this.player.x + this.player.width / 2) - (this.player2.x + this.player2.width / 2),
          (this.player.y + this.player.height / 2) - (this.player2.y + this.player2.height / 2)
        );
        if (dist < 60) {
          this.player2.reviveProgress = Math.min(1, this.player2.reviveProgress + dt / 1.6);
          if (this.player2.reviveProgress >= 1) {
            this.player2.isKnockedOut = false;
            this.player2.hp = 2;
            this.player2.invincibleTimer = 2.0;
            this.player2.reviveProgress = 0;
            soundManager.playLevelComplete();
            this.addFloatingText(this.player2.x + this.player2.width / 2, this.player2.y - 40, `✨ ${this.player2.name} REVIVIDO!`, '#22C55E', 1.5);
          }
        } else {
          this.player2.reviveProgress = Math.max(0, this.player2.reviveProgress - dt * 0.4);
        }
      }
    }
  }

  private updatePlayerEntity(
    p: PlayerState,
    keys: { left: boolean; right: boolean; jump: boolean; attack: boolean; depositX: boolean; interact: boolean },
    dt: number,
    timeScale: number
  ) {
    const maxGroundY = 500 - p.height;

    if (p.isKnockedOut) {
      p.vx = 0;
      p.vy += 0.58 * timeScale;
      if (p.vy > 14) p.vy = 14;
      const prevY = p.y;
      p.y += p.vy * timeScale;

      p.isGrounded = false;
      for (const plat of this.platforms) {
        if (p.x + p.width > plat.x && p.x < plat.x + plat.width) {
          if (p.vy >= 0 && prevY + p.height <= plat.y + 12 && p.y + p.height >= plat.y) {
            p.y = plat.y - p.height;
            p.vy = 0;
            p.isGrounded = true;
            break;
          }
        }
      }
      if (p.y >= maxGroundY) {
        p.y = maxGroundY;
        p.vy = 0;
        p.isGrounded = true;
      }
      return;
    }

    const speed = 5.8;
    if (keys.left) {
      p.vx = -speed;
      p.facing = -1;
      p.walkFrame += dt * 12;
    } else if (keys.right) {
      p.vx = speed;
      p.facing = 1;
      p.walkFrame += dt * 12;
    } else {
      p.vx *= Math.pow(0.72, timeScale);
      if (Math.abs(p.vx) < 0.1) p.vx = 0;
    }

    const jumpStrength = -12.5;
    if (keys.jump && p.isGrounded) {
      p.vy = jumpStrength;
      p.isGrounded = false;
      soundManager.playJump();
      for (let i = 0; i < 4; i++) {
        this.particles.push({
          x: p.x + p.width / 2 + (Math.random() - 0.5) * 16,
          y: p.y + p.height,
          vx: (Math.random() - 0.5) * 3,
          vy: -Math.random() * 2,
          size: Math.random() * 4 + 2,
          color: p.playerIndex === 2 ? '#38BDF8' : '#CBD5E1',
          alpha: 0.7,
          life: 0,
          maxLife: 0.35,
          shape: 'circle',
        });
      }
    }

    const gravity = 0.58;
    p.vy += gravity * timeScale;
    if (p.vy > 14) p.vy = 14;
    p.x += p.vx * timeScale;
    const prevY = p.y;
    p.y += p.vy * timeScale;

    // Horizontal boundaries
    if (p.x < 10) p.x = 10;
    if (p.x + p.width > this.canvasWidth - 10) p.x = this.canvasWidth - 10 - p.width;

    // Platform landing collision
    p.isGrounded = false;
    for (const plat of this.platforms) {
      if (p.x + p.width > plat.x + 2 && p.x < plat.x + plat.width - 2) {
        if (p.vy >= 0) {
          const platTop = plat.y;
          if (
            (prevY + p.height <= platTop + 14 && p.y + p.height >= platTop) ||
            (p.y + p.height >= platTop && p.y + p.height <= platTop + Math.max(20, p.vy * timeScale + 6))
          ) {
            p.y = platTop - p.height;
            p.vy = 0;
            p.isGrounded = true;
            break;
          }
        }
      }
    }

    // Absolute vertical boundaries: Cannot fall below ground level (500) or fly above ceiling
    if (p.y >= maxGroundY) {
      p.y = maxGroundY;
      p.vy = 0;
      p.isGrounded = true;
    }
    if (p.y < 10) {
      p.y = 10;
      if (p.vy < 0) p.vy = 0;
    }

    if (p.invincibleTimer > 0) {
      p.invincibleTimer = Math.max(0, p.invincibleTimer - dt);
    }
    if (p.attackCooldown > 0) {
      p.attackCooldown = Math.max(0, p.attackCooldown - dt);
    }

    if (p.isAttacking) {
      p.attackAnimTimer -= dt;
      if (p.attackAnimTimer <= 0) {
        p.isAttacking = false;
      }
    }
    if (p.isSwordSlashing) {
      p.swordSlashTimer -= dt;
      if (p.swordSlashTimer <= 0) {
        p.isSwordSlashing = false;
      }
    }

    if (p.comboWindowTimer > 0) {
      p.comboWindowTimer = Math.max(0, p.comboWindowTimer - dt);
      if (p.comboWindowTimer === 0 && p.attackComboStep !== 1) {
        p.attackComboStep = 1;
        this.notify();
      }
    }

    if (p.attackCharges < p.maxAttackCharges) {
      p.chargeRegenTimer += dt;
      if (p.chargeRegenTimer >= 0.22) {
        p.attackCharges = Math.min(p.maxAttackCharges, p.attackCharges + 1);
        p.chargeRegenTimer = 0;
        this.notify();
      }
    }

    if (keys.attack && p.attackCooldown <= 0) {
      this.executePlayerAttack(p);
    }

    if (keys.depositX) {
      this.triggerDepositWithX(p);
      keys.depositX = false;
    }

    this.handlePlayerPickups(p);
  }

  public triggerDepositWithX(actingPlayer: PlayerState = this.player) {
    const p = actingPlayer;
    if (!p.carriedItem) {
      this.addFloatingText(
        p.x + p.width / 2,
        p.y - 30,
        `💡 ${p.name}: Pegue um pneu primeiro!`,
        '#FACC15',
        1.1
      );
      return;
    }

    const targetBin = this.recycleBins.find((b) => b.category === p.carriedItem?.category);
    if (targetBin) {
      this.handleRecycleBinClick(targetBin, p);
    } else if (this.recycleBins.length > 0) {
      this.handleRecycleBinClick(this.recycleBins[0], p);
    }
  }

  private registerEnemyHitCombo(enemy: Enemy, hitDamage: number, source: 'melee' | 'projectile', comboStep: number = 1) {
    this.stats.attackHitStreak++;
    if (this.stats.attackHitStreak > this.stats.maxAttackHitStreak) {
      this.stats.maxAttackHitStreak = this.stats.attackHitStreak;
    }
    this.stats.attackHitStreakTimer = 2.8;
    const streak = this.stats.attackHitStreak;
    let bonusScore = 15 * Math.min(streak, 10);

    if (streak === 3) {
      bonusScore += 80;
      soundManager.playHitStreakBonus(streak);
      this.addFloatingText(enemy.x + enemy.width / 2, enemy.y - 38, '🔥 3 HITS! COMBO! +80', '#F97316', 1.25);
    } else if (streak === 5) {
      bonusScore += 200;
      soundManager.playHitStreakBonus(streak);
      this.addFloatingText(enemy.x + enemy.width / 2, enemy.y - 42, '⚡ 5 HITS! SUPER COMBO! +200', '#FACC15', 1.35);
    } else if (streak === 8) {
      bonusScore += 450;
      soundManager.playHitStreakBonus(streak);
      this.addFloatingText(enemy.x + enemy.width / 2, enemy.y - 45, '💥 8 HITS! MEGA COMBO! +450', '#EC4899', 1.45);
    } else if (streak === 10 || (streak > 10 && streak % 5 === 0)) {
      bonusScore += 800;
      soundManager.playHitStreakBonus(streak);
      this.addFloatingText(enemy.x + enemy.width / 2, enemy.y - 48, `👑 ${streak} HITS! COMBO LENDÁRIO! +800`, '#A855F7', 1.55);
    }
    this.stats.score += bonusScore;
    this.notify();
  }

  private checkEnemyDefeat(enemy: Enemy) {
    if (enemy.hp <= 0 && enemy.state !== 'defeated') {
      enemy.state = 'defeated';
      enemy.defeatTimer = 0.4;
      soundManager.playEnemyDefeated();
      const pts = enemy.isBoss ? 1500 : 300;
      this.stats.score += pts;
      this.stats.monstersDefeated++;
      this.levelMonstersDefeatedCount++;
      this.addFloatingText(
        enemy.x + enemy.width / 2,
        enemy.y - 25,
        `✨ ${enemy.name} Purificado! +${pts}`,
        '#FACC15',
        1.3
      );
      for (let k = 0; k < 8; k++) {
        this.particles.push({
          x: enemy.x + enemy.width / 2,
          y: enemy.y + enemy.height / 2,
          vx: (Math.random() - 0.5) * 6,
          vy: -Math.random() * 5 - 2,
          size: Math.random() * 4 + 2,
          color: ['#4ADE80', '#FACC15', '#38BDF8', '#F97316'][k % 4],
          alpha: 1.0,
          life: 0,
          maxLife: 0.6,
          shape: 'leaf',
        });
      }
    }
  }

  public executePlayerAttack(p: PlayerState = this.player) {
    if (p.isKnockedOut) return;

    if (p.attackCharges <= 0) {
      if (p.attackCooldown <= 0) {
        soundManager.playRecycleError();
        if (!this.floatingTexts.some((ft) => ft.text.includes('Recarregando'))) {
          this.addFloatingText(
            p.x + p.width / 2,
            p.y - 25,
            `⚠️ ${p.name}: Espada Recarregando! (0/5)`,
            '#F59E0B',
            1.0
          );
        }
        p.attackCooldown = 0.22;
      }
      return;
    }

    const friendlyCount = this.projectiles.filter((pr) => pr.isFriendly).length;
    if (friendlyCount >= 10) {
      p.attackCooldown = 0.12;
      return;
    }

    const currentStep = p.attackComboStep;
    p.attackCharges--;

    p.attackComboStep = (currentStep === 1 ? 2 : currentStep === 2 ? 3 : 1) as 1 | 2 | 3;
    p.comboWindowTimer = 0.55;
    p.isAttacking = true;
    p.isSwordSlashing = true;
    p.swordSlashTimer = currentStep === 3 ? 0.28 : currentStep === 2 ? 0.18 : 0.15;
    p.attackAnimTimer = currentStep === 3 ? 0.26 : currentStep === 2 ? 0.17 : 0.14;
    p.attackCooldown = currentStep === 3 ? 0.18 : 0.11;

    soundManager.playSwordSlashCombo(currentStep);
    this.notify();

    const streakBonus = Math.min(2.2, 1 + this.stats.attackHitStreak * 0.05);

    if (currentStep === 1) {
      const swordReach = 65;
      const baseDamage = Math.max(3, Math.round(3 * streakBonus));
      for (const enemy of this.enemies) {
        if (enemy.state === 'defeated') continue;
        const dx = (enemy.x + enemy.width / 2) - (p.x + p.width / 2);
        const dy = Math.abs((enemy.y + enemy.height / 2) - (p.y + p.height / 2));
        if (Math.sign(dx) === p.facing && Math.abs(dx) < swordReach && dy < 50) {
          enemy.hp -= baseDamage;
          enemy.hurtTimer = 0.2;
          enemy.x += p.facing * 14;
          soundManager.playEnemyHit();
          this.registerEnemyHitCombo(enemy, baseDamage, 'melee', 1);
          this.addFloatingText(
            enemy.x + enemy.width / 2,
            enemy.y - 15,
            `⚔️ CORTE RÁPIDO! [1/3] -${baseDamage}`,
            '#4ADE80',
            1.1
          );
          for (let k = 0; k < 4; k++) {
            this.particles.push({
              x: enemy.x + enemy.width / 2,
              y: enemy.y + enemy.height / 2,
              vx: p.facing * Math.random() * 5,
              vy: (Math.random() - 0.5) * 5,
              size: Math.random() * 3 + 2,
              color: '#4ADE80',
              alpha: 1.0,
              life: 0,
              maxLife: 0.3,
              shape: 'spark',
            });
          }
          this.checkEnemyDefeat(enemy);
          break;
        }
      }

      const projX = p.facing === 1 ? p.x + p.width + 10 : p.x - 10;
      const projY = p.y + p.height * 0.45;
      this.projectiles.push({
        id: `proj_${Date.now()}_${Math.random()}`,
        x: projX,
        y: projY,
        vx: p.facing * 12,
        vy: 0,
        radius: 9,
        isFriendly: true,
        color: '#22C55E',
        damage: 2,
        lifetime: 1.6,
        projectileType: 'eco_blast',
      });
    } else if (currentStep === 2) {
      p.vx += p.facing * 3.6;
      const swordReach = 72;
      const baseDamage = Math.max(4, Math.round(4.5 * streakBonus));
      for (const enemy of this.enemies) {
        if (enemy.state === 'defeated') continue;
        const dx = (enemy.x + enemy.width / 2) - (p.x + p.width / 2);
        const dy = Math.abs((enemy.y + enemy.height / 2) - (p.y + p.height / 2));
        if (Math.sign(dx) === p.facing && Math.abs(dx) < swordReach && dy < 55) {
          enemy.hp -= baseDamage;
          enemy.hurtTimer = 0.22;
          enemy.x += p.facing * 20;
          soundManager.playEnemyHit();
          this.registerEnemyHitCombo(enemy, baseDamage, 'melee', 2);
          this.addFloatingText(
            enemy.x + enemy.width / 2,
            enemy.y - 18,
            `⚡ GOLPE CRUZADO! [2/3] -${baseDamage}`,
            '#38BDF8',
            1.2
          );
          for (let k = 0; k < 6; k++) {
            this.particles.push({
              x: enemy.x + enemy.width / 2,
              y: enemy.y + enemy.height / 2,
              vx: p.facing * Math.random() * 6,
              vy: (Math.random() - 0.5) * 6,
              size: Math.random() * 4 + 2,
              color: '#38BDF8',
              alpha: 1.0,
              life: 0,
              maxLife: 0.35,
              shape: 'spark',
            });
          }
          this.checkEnemyDefeat(enemy);
          break;
        }
      }

      const projX = p.facing === 1 ? p.x + p.width + 10 : p.x - 10;
      const projY = p.y + p.height * 0.45;
      this.projectiles.push(
        {
          id: `proj_${Date.now()}_a`,
          x: projX,
          y: projY - 6,
          vx: p.facing * 12.5,
          vy: -1.2,
          radius: 10,
          isFriendly: true,
          color: '#38BDF8',
          damage: 3,
          lifetime: 1.6,
          projectileType: 'eco_blast_cross',
        },
        {
          id: `proj_${Date.now()}_b`,
          x: projX,
          y: projY + 6,
          vx: p.facing * 12.5,
          vy: 1.2,
          radius: 10,
          isFriendly: true,
          color: '#38BDF8',
          damage: 3,
          lifetime: 1.6,
          projectileType: 'eco_blast_cross',
        }
      );
    } else {
      this.screenShake = 8;
      const whirlwindRadius = 88;
      const baseDamage = Math.max(6, Math.round(7 * streakBonus));
      for (const enemy of this.enemies) {
        if (enemy.state === 'defeated') continue;
        const dx = (enemy.x + enemy.width / 2) - (p.x + p.width / 2);
        const dy = (enemy.y + enemy.height / 2) - (p.y + p.height / 2);
        const dist = Math.hypot(dx, dy);
        if (dist < whirlwindRadius) {
          enemy.hp -= baseDamage;
          enemy.hurtTimer = 0.28;
          enemy.x += (dx >= 0 ? 1 : -1) * 32;
          soundManager.playEnemyHit();
          this.registerEnemyHitCombo(enemy, baseDamage, 'melee', 3);
          this.addFloatingText(
            enemy.x + enemy.width / 2,
            enemy.y - 25,
            `🌪️ VÓRTICE FINALIZADOR! [3/3] -${baseDamage}`,
            '#FACC15',
            1.35
          );
          for (let k = 0; k < 8; k++) {
            this.particles.push({
              x: enemy.x + enemy.width / 2,
              y: enemy.y + enemy.height / 2,
              vx: (Math.random() - 0.5) * 8,
              vy: (Math.random() - 0.5) * 8,
              size: Math.random() * 4 + 3,
              color: k % 2 === 0 ? '#FACC15' : '#4ADE80',
              alpha: 1.0,
              life: 0,
              maxLife: 0.45,
              shape: 'star',
            });
          }
          this.checkEnemyDefeat(enemy);
        }
      }

      for (let k = 0; k < 12; k++) {
        const ang = (k * Math.PI * 2) / 12;
        this.particles.push({
          x: p.x + p.width / 2 + Math.cos(ang) * 20,
          y: p.y + p.height / 2 + Math.sin(ang) * 20,
          vx: Math.cos(ang) * 6,
          vy: Math.sin(ang) * 6,
          size: Math.random() * 4 + 2,
          color: k % 2 === 0 ? '#FACC15' : '#22C55E',
          alpha: 1.0,
          life: 0,
          maxLife: 0.4,
          shape: 'leaf',
        });
      }

      const projX = p.facing === 1 ? p.x + p.width + 12 : p.x - 12;
      const projY = p.y + p.height * 0.45;
      this.projectiles.push(
        {
          id: `proj_${Date.now()}_f1`,
          x: projX,
          y: projY,
          vx: p.facing * 14,
          vy: 0,
          radius: 14,
          isFriendly: true,
          color: '#FACC15',
          damage: 4,
          lifetime: 1.8,
          projectileType: 'eco_blast_finisher',
        },
        {
          id: `proj_${Date.now()}_f2`,
          x: projX,
          y: projY - 10,
          vx: p.facing * 13,
          vy: -2.2,
          radius: 12,
          isFriendly: true,
          color: '#22C55E',
          damage: 3,
          lifetime: 1.8,
          projectileType: 'eco_blast_finisher',
        },
        {
          id: `proj_${Date.now()}_f3`,
          x: projX,
          y: projY + 10,
          vx: p.facing * 13,
          vy: 2.2,
          radius: 12,
          isFriendly: true,
          color: '#22C55E',
          damage: 3,
          lifetime: 1.8,
          projectileType: 'eco_blast_finisher',
        }
      );
    }
  }

  private handlePlayerPickups(p: PlayerState) {
    if (p.isKnockedOut) return;
    if (!p.carriedItem) {
      for (const item of this.trashItems) {
        if (item.isRecycled || item.isCarried) continue;
        const playerCenterX = p.x + p.width / 2;
        const playerCenterY = p.y + p.height / 2;
        const itemCenterX = item.x + item.width / 2;
        const itemCenterY = item.y + item.height / 2;
        const dist = Math.hypot(itemCenterX - playerCenterX, itemCenterY - playerCenterY);
        if (dist < 36) {
          soundManager.playPickup();
          item.isCarried = true;
          p.carriedItem = item;
          const info = TRASH_CATEGORY_INFO[item.category];
          this.addFloatingText(
            p.x + p.width / 2,
            p.y - 25,
            `${p.name} Recolheu: ${item.name}!`,
            info.binColorHex,
            1.0
          );
          this.notify();
          break;
        }
      }
    }
  }

  private updateTrashItems(dt: number, timeScale: number) {
    for (const item of this.trashItems) {
      if (item.isRecycled || item.isCarried) continue;
      item.vy += 0.45 * timeScale;
      if (item.vy > 10) item.vy = 10;
      item.x += item.vx * timeScale;
      item.y += item.vy * timeScale;
      item.vx *= Math.pow(0.85, timeScale);

      for (const plat of this.platforms) {
        if (
          item.x + item.width > plat.x &&
          item.x < plat.x + plat.width &&
          item.y + item.height >= plat.y &&
          item.y + item.height <= plat.y + 16 &&
          item.vy >= 0
        ) {
          item.y = plat.y - item.height;
          item.vy = 0;
          item.isGrounded = true;
        }
      }
    }
  }

  private updateEnemies(dt: number, timeScale: number) {
    const p = this.player;
    for (const enemy of this.enemies) {
      if (enemy.state === 'defeated') {
        enemy.defeatTimer -= dt;
        continue;
      }
      if (enemy.hurtTimer > 0) {
        enemy.hurtTimer = Math.max(0, enemy.hurtTimer - dt);
      }

      enemy.vy += 0.45 * timeScale;
      if (enemy.vy > 12) enemy.vy = 12;

      for (const plat of this.platforms) {
        if (
          enemy.x + enemy.width > plat.x &&
          enemy.x < plat.x + plat.width &&
          enemy.y + enemy.height >= plat.y &&
          enemy.y + enemy.height <= plat.y + 18 &&
          enemy.vy >= 0
        ) {
          enemy.y = plat.y - enemy.height;
          enemy.vy = 0;
          enemy.isGrounded = true;
        }
      }

      const distToPlayer = Math.abs(p.x - enemy.x);
      if (distToPlayer < 450) {
        enemy.facing = p.x > enemy.x ? 1 : -1;
      }

      switch (enemy.type) {
        case 'pneu_saltitante': {
          if (enemy.isGrounded) {
            enemy.vy = distToPlayer < 300 ? -7.2 : -5.2;
            enemy.isGrounded = false;
          }
          if (distToPlayer < 320) {
            enemy.vx = enemy.facing * enemy.speed;
          } else {
            if (enemy.x <= enemy.patrolMinX) {
              enemy.vx = Math.abs(enemy.speed);
              enemy.facing = 1;
            } else if (enemy.x >= enemy.patrolMaxX) {
              enemy.vx = -Math.abs(enemy.speed);
              enemy.facing = -1;
            }
          }
          enemy.rotation = (enemy.rotation || 0) + enemy.vx * 0.12;
          break;
        }
        case 'pneu_espinhoso': {
          if (distToPlayer < 360) {
            enemy.vx = enemy.facing * enemy.speed;
            if (Math.random() < 0.02 && enemy.isGrounded) {
              enemy.vy = -5.0;
            }
          } else {
            if (enemy.x <= enemy.patrolMinX) {
              enemy.vx = Math.abs(enemy.speed);
              enemy.facing = 1;
            } else if (enemy.x >= enemy.patrolMaxX) {
              enemy.vx = -Math.abs(enemy.speed);
              enemy.facing = -1;
            }
          }
          break;
        }
        case 'pneu_chamas': {
          enemy.attackTimer += dt;
          if (enemy.attackTimer >= 2.2 && distToPlayer < 400) {
            enemy.attackTimer = 0;
            const enemyProjCount = this.projectiles.filter((pr) => !pr.isFriendly).length;
            if (enemyProjCount < 7) {
              this.projectiles.push(
                {
                  id: `fire_1_${Date.now()}_${Math.random()}`,
                  x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                  y: enemy.y + enemy.height * 0.4,
                  vx: enemy.facing * 5.5,
                  vy: -1.0,
                  radius: 8,
                  isFriendly: false,
                  color: '#EF4444',
                  damage: 1,
                  lifetime: 2.2,
                  projectileType: 'fire_blast',
                },
                {
                  id: `fire_2_${Date.now()}_${Math.random()}`,
                  x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                  y: enemy.y + enemy.height * 0.3,
                  vx: enemy.facing * 4.8,
                  vy: -2.8,
                  radius: 7,
                  isFriendly: false,
                  color: '#F97316',
                  damage: 1,
                  lifetime: 2.2,
                  projectileType: 'fire_blast',
                }
              );
            }
          }
          if (enemy.x <= enemy.patrolMinX) {
            enemy.vx = Math.abs(enemy.speed) * 0.8;
            enemy.facing = 1;
          } else if (enemy.x >= enemy.patrolMaxX) {
            enemy.vx = -Math.abs(enemy.speed) * 0.8;
            enemy.facing = -1;
          }
          break;
        }
        case 'pneu_trator_monstro': {
          enemy.attackTimer += dt;
          if (distToPlayer < 340) {
            enemy.vx = enemy.facing * 2.4;
            if (enemy.attackTimer >= 2.5 && enemy.isGrounded) {
              enemy.attackTimer = 0;
              enemy.vy = -7.5;
              this.screenShake = 3;
            }
          } else {
            if (enemy.x <= enemy.patrolMinX) {
              enemy.vx = 2.0;
              enemy.facing = 1;
            } else if (enemy.x >= enemy.patrolMaxX) {
              enemy.vx = -2.0;
              enemy.facing = -1;
            }
          }
          break;
        }
        case 'super_pneu': {
          if (enemy.x <= enemy.patrolMinX) {
            enemy.vx = Math.abs(enemy.speed);
            enemy.facing = 1;
          } else if (enemy.x >= enemy.patrolMaxX) {
            enemy.vx = -Math.abs(enemy.speed);
            enemy.facing = -1;
          }
          enemy.attackTimer += dt;
          if (enemy.attackTimer >= 1.8) {
            enemy.attackTimer = 0;
            const roll = Math.random();
            if (roll < 0.35) {
              soundManager.playEnemyHit();
              this.addFloatingText(enemy.x, enemy.y - 30, '🛞 ARREMESSO DUPLO DE PNEUS!', '#EF4444', 1.2);
              this.projectiles.push(
                {
                  id: `boss_tire_1_${Date.now()}`,
                  x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                  y: enemy.y + enemy.height * 0.5,
                  vx: enemy.facing * 7.5,
                  vy: -1.5,
                  radius: 12,
                  isFriendly: false,
                  color: '#0F172A',
                  damage: 1,
                  lifetime: 2.8,
                  projectileType: 'rolling_tire',
                },
                {
                  id: `boss_tire_2_${Date.now()}`,
                  x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                  y: enemy.y + enemy.height * 0.3,
                  vx: enemy.facing * 6.0,
                  vy: -4.0,
                  radius: 11,
                  isFriendly: false,
                  color: '#0F172A',
                  damage: 1,
                  lifetime: 2.8,
                  projectileType: 'rolling_tire',
                }
              );
            } else if (roll < 0.65) {
              soundManager.playBossRoar();
              this.screenShake = 8;
              this.addFloatingText(enemy.x, enemy.y - 30, '🔥 TEMPESTADE DE CHAMA!', '#F97316', 1.3);
              this.projectiles.push(
                {
                  id: `boss_fire_1_${Date.now()}`,
                  x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                  y: enemy.y + enemy.height * 0.4,
                  vx: enemy.facing * 7.0,
                  vy: -1.0,
                  radius: 10,
                  isFriendly: false,
                  color: '#EF4444',
                  damage: 1,
                  lifetime: 2.6,
                  projectileType: 'fire_blast',
                },
                {
                  id: `boss_fire_2_${Date.now()}`,
                  x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                  y: enemy.y + enemy.height * 0.3,
                  vx: enemy.facing * 6.0,
                  vy: -3.5,
                  radius: 10,
                  isFriendly: false,
                  color: '#F59E0B',
                  damage: 1,
                  lifetime: 2.6,
                  projectileType: 'fire_blast',
                },
                {
                  id: `boss_fire_3_${Date.now()}`,
                  x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                  y: enemy.y + enemy.height * 0.5,
                  vx: enemy.facing * 8.0,
                  vy: 0.5,
                  radius: 9,
                  isFriendly: false,
                  color: '#DC2626',
                  damage: 1,
                  lifetime: 2.6,
                  projectileType: 'fire_blast',
                }
              );
            } else {
              soundManager.playBossRoar();
              this.screenShake = 16;
              this.addFloatingText(enemy.x, enemy.y - 45, '🚗 CARRO ARREMESSADO PELO AR!', '#DC2626', 1.5);
              this.projectiles.push({
                id: `boss_car_${Date.now()}`,
                x: enemy.x + (enemy.facing === 1 ? enemy.width : 0),
                y: enemy.y + enemy.height * 0.2,
                vx: enemy.facing * 6.5,
                vy: -4.5,
                radius: 22,
                isFriendly: false,
                color: '#DC2626',
                damage: 2,
                lifetime: 3.5,
                projectileType: 'flying_car',
                rotation: 0,
                vRot: enemy.facing * 9,
              });
            }
          }
          break;
        }
      }

      enemy.x += enemy.vx * timeScale;
      enemy.y += enemy.vy * timeScale;

      if (enemy.x < 30) enemy.x = 30;
      if (enemy.x + enemy.width > this.canvasWidth - 30) enemy.x = this.canvasWidth - 30 - enemy.width;

      if (
        !this.player.isKnockedOut &&
        this.player.invincibleTimer <= 0 &&
        this.player.x + this.player.width > enemy.x + 4 &&
        this.player.x < enemy.x + enemy.width - 4 &&
        this.player.y + this.player.height > enemy.y + 6 &&
        this.player.y < enemy.y + enemy.height - 6
      ) {
        this.damagePlayer(1, this.player);
      }

      if (
        this.player2 &&
        !this.player2.isKnockedOut &&
        this.player2.invincibleTimer <= 0 &&
        this.player2.x + this.player2.width > enemy.x + 4 &&
        this.player2.x < enemy.x + enemy.width - 4 &&
        this.player2.y + this.player2.height > enemy.y + 6 &&
        this.player2.y < enemy.y + enemy.height - 6
      ) {
        this.damagePlayer(1, this.player2);
      }
    }

    this.enemies = this.enemies.filter((e) => e.state !== 'defeated' || e.defeatTimer > 0);
  }

  private updateProjectiles(dt: number, timeScale: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const proj = this.projectiles[i];
      proj.x += proj.vx * timeScale;
      proj.y += proj.vy * timeScale;
      proj.lifetime -= dt;

      if (proj.vRot) {
        proj.rotation = (proj.rotation || 0) + proj.vRot * dt;
      }
      if (proj.projectileType === 'flying_car' || proj.projectileType === 'rolling_tire') {
        proj.vy += 0.28 * timeScale;
      }

      if (proj.lifetime <= 0 || proj.x < 0 || proj.x > this.canvasWidth || proj.y > this.canvasHeight) {
        this.projectiles.splice(i, 1);
        continue;
      }

      if (proj.isFriendly) {
        let hit = false;
        for (const enemy of this.enemies) {
          if (enemy.state === 'defeated') continue;
          if (
            proj.x + proj.radius > enemy.x &&
            proj.x - proj.radius < enemy.x + enemy.width &&
            proj.y + proj.radius > enemy.y &&
            proj.y - proj.radius < enemy.y + enemy.height
          ) {
            hit = true;
            enemy.hp -= proj.damage;
            enemy.hurtTimer = 0.2;
            soundManager.playEnemyHit();
            enemy.x += (proj.vx > 0 ? 1 : -1) * 8;
            this.registerEnemyHitCombo(enemy, proj.damage, 'projectile');
            this.addFloatingText(
              enemy.x + enemy.width / 2,
              enemy.y - 10,
              proj.damage > 2 ? `💥 CRÍTICO! -${proj.damage}` : `✨ -${proj.damage}`,
              proj.damage > 2 ? '#FACC15' : '#4ADE80',
              proj.damage > 2 ? 1.3 : 1.1
            );
            for (let k = 0; k < 4; k++) {
              this.particles.push({
                x: proj.x,
                y: proj.y,
                vx: (Math.random() - 0.5) * 5,
                vy: (Math.random() - 0.5) * 5,
                size: Math.random() * 3 + 2,
                color: proj.damage > 2 ? '#FACC15' : '#4ADE80',
                alpha: 1.0,
                life: 0,
                maxLife: 0.3,
                shape: 'spark',
              });
            }
            this.checkEnemyDefeat(enemy);
            break;
          }
        }
        if (hit) {
          this.projectiles.splice(i, 1);
        }
      } else {
        if (
          !this.player.isKnockedOut &&
          this.player.invincibleTimer <= 0 &&
          proj.x + proj.radius > this.player.x &&
          proj.x - proj.radius < this.player.x + this.player.width &&
          proj.y + proj.radius > this.player.y &&
          proj.y - proj.radius < this.player.y + this.player.height
        ) {
          this.damagePlayer(proj.damage, this.player);
          this.projectiles.splice(i, 1);
          continue;
        }

        if (
          this.player2 &&
          !this.player2.isKnockedOut &&
          this.player2.invincibleTimer <= 0 &&
          proj.x + proj.radius > this.player2.x &&
          proj.x - proj.radius < this.player2.x + this.player2.width &&
          proj.y + proj.radius > this.player2.y &&
          proj.y - proj.radius < this.player2.y + this.player2.height
        ) {
          this.damagePlayer(proj.damage, this.player2);
          this.projectiles.splice(i, 1);
          continue;
        }
      }
    }
  }

  private damagePlayer(damage: number, p: PlayerState = this.player) {
    p.hp = Math.max(0, p.hp - damage);
    p.invincibleTimer = 1.6;
    p.vy = -4.5;
    p.vx = p.facing * -3.5;

    const maxGroundY = 500 - p.height;
    if (p.y > maxGroundY) {
      p.y = maxGroundY;
    }

    if (this.stats.comboCount >= 2 || this.stats.comboTimer > 0) {
      if (this.stats.comboCount >= 2) {
        soundManager.playComboBreak();
        this.addFloatingText(
          p.x + p.width / 2,
          p.y - 45,
          `💔 COMBO DE PNEUS QUEBRADO! (Era x${this.stats.comboMultiplier})`,
          '#EF4444',
          1.35
        );
      }
      this.stats.comboCount = 0;
      this.stats.comboMultiplier = 1;
      this.stats.comboTimer = 0;
    }

    if (this.stats.attackHitStreak >= 2) {
      soundManager.playComboBreak();
      this.addFloatingText(
        p.x + p.width / 2,
        p.y - 65,
        `💔 COMBO DE ATAQUE QUEBRADO! (${this.stats.attackHitStreak} HITS)`,
        '#F43F5E',
        1.3
      );
    }
    this.stats.attackHitStreak = 0;
    this.stats.attackHitStreakTimer = 0;
    p.attackComboStep = 1;
    p.comboWindowTimer = 0;

    soundManager.playPlayerHurt();
    this.screenShake = 9;
    this.addFloatingText(p.x + p.width / 2, p.y - 20, `💥 -${damage} Dano em ${p.name}!`, '#EF4444', 1.2);

    if (p.hp <= 0) {
      if (this.gameMode === 'single') {
        this.view = 'GAME_OVER';
        soundManager.stopBGM();
        soundManager.playGameOver();
        this.updateHighScore();
      } else {
        p.hp = 0;
        p.isKnockedOut = true;
        p.reviveProgress = 0;
        this.addFloatingText(p.x + p.width / 2, p.y - 40, `💀 ${p.name} FOI NOCAUTEADO!`, '#EF4444', 1.45);
        const p1Down = this.player.isKnockedOut || this.player.hp <= 0;
        const p2Down = !this.player2 || this.player2.isKnockedOut || this.player2.hp <= 0;
        if (p1Down && p2Down) {
          this.view = 'GAME_OVER';
          soundManager.stopBGM();
          soundManager.playGameOver();
          this.updateHighScore();
        }
      }
    }
    this.notify();
  }

  private updateParticles(dt: number, timeScale: number) {
    if (this.particles.length > 25) {
      this.particles.splice(0, this.particles.length - 25);
    }
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.x += pt.vx * timeScale;
      pt.y += pt.vy * timeScale;
      pt.vy += 0.1 * timeScale;
      pt.life += dt;
      pt.alpha = Math.max(0, 1 - pt.life / pt.maxLife);
      if (pt.life >= pt.maxLife) {
        this.particles.splice(i, 1);
      }
    }
  }

  private updateFloatingTexts(dt: number) {
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.y += ft.vy;
      ft.lifetime -= dt;
      ft.alpha = Math.max(0, ft.lifetime / 1.0);
      if (ft.lifetime <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }
  }

  public addFloatingText(x: number, y: number, text: string, color: string, scale: number = 1.0) {
    if (this.floatingTexts.length >= 4) {
      this.floatingTexts.shift();
    }
    this.floatingTexts.push({
      id: `ft_${Date.now()}_${Math.random()}`,
      x,
      y,
      text,
      color,
      alpha: 1.0,
      scale,
      vy: -1.2,
      lifetime: 1.0,
    });
  }

  private checkLevelCompletion() {
    const allTrashRecycled = this.trashItems.every((item) => item.isRecycled);
    const requiredMonstersCount = this.currentLevelConfig.monstersToSpawn.length;
    const allEnemiesDefeated =
      this.levelMonstersDefeatedCount >= requiredMonstersCount ||
      (this.enemies.length > 0 && this.enemies.every((enemy) => enemy.state === 'defeated'));

    if (allTrashRecycled && allEnemiesDefeated) {
      if (this.currentLevelConfig.id >= 5) {
        this.view = 'VICTORY';
        soundManager.stopBGM();
        soundManager.playLevelComplete();
        this.updateHighScore();
      } else {
        this.view = 'LEVEL_CLEARED';
        soundManager.stopBGM();
        soundManager.playLevelComplete();
      }
      this.notify();
    }
  }

  private updateHighScore() {
    if (this.stats.score > this.stats.highScore) {
      this.stats.highScore = this.stats.score;
      try {
        localStorage.setItem('reciclagem_pneus_high_score', String(this.stats.highScore));
      } catch {
        // Storage failover
      }
    }
  }

  public retryCurrentLevel() {
    this.player.hp = this.player.maxHp;
    this.startLevel(this.currentLevelConfig.id - 1);
  }

  public nextLevel() {
    const nextIdx = this.currentLevelConfig.id;
    if (nextIdx < LEVELS.length) {
      this.startLevel(nextIdx);
    } else {
      this.view = 'VICTORY';
      this.notify();
    }
  }

  public resetGame() {
    this.stats.score = 0;
    this.stats.trashRecycled = 0;
    this.stats.trashFailed = 0;
    this.stats.monstersDefeated = 0;
    this.stats.currentLevel = 1;
    this.stats.comboCount = 0;
    this.stats.comboMultiplier = 1;
    this.stats.comboTimer = 0;
    this.stats.maxCombo = 0;
    this.stats.comboBonusScore = 0;
    this.stats.attackHitStreak = 0;
    this.stats.maxAttackHitStreak = 0;
    this.stats.attackHitStreakTimer = 0;
    this.player = this.createDefaultPlayer();
    this.startLevel(0);
  }

  public getCleanlinessRatio(): number {
    if (this.totalTrashInLevel === 0) return 1;
    return this.levelRecycledCount / this.totalTrashInLevel;
  }
}
