/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CharacterSkin {
  id: string;
  name: string;
  badge: string;
  badgeColor: string;
  description: string;
  icon: string;
  jacketColor: string;
  capeColor: string;
  capeWiggleColor?: string;
  pantsColor: string;
  bootsColor: string;
  helmetColor: string;
  bladeColor: string;
  bladeCoreColor: string;
  slashColor: string;
  slashGlowColor: string;
  guardColor: string;
  handleColor: string;
  emblemSymbol: string;
  emblemColor: string;
}

export const CHARACTER_SKINS: CharacterSkin[] = [
  {
    id: 'economart',
    name: 'Economart',
    badge: 'Protagonista',
    badgeColor: 'bg-emerald-400 text-slate-950 font-black',
    description: 'Uniforme moderno inspirado em reciclagem e sustentabilidade, com blindagem esmeralda e detalhes azuis brilhantes.',
    icon: '⚡',
    jacketColor: '#10B981',
    capeColor: '#0284C7',
    capeWiggleColor: '#38BDF8',
    pantsColor: '#0F172A',
    bootsColor: '#0369A1',
    helmetColor: '#047857',
    bladeColor: '#06B6D4',
    bladeCoreColor: '#E0F2FE',
    slashColor: '#10B981',
    slashGlowColor: 'rgba(6, 182, 212, 0.65)',
    guardColor: '#38BDF8',
    handleColor: '#065F46',
    emblemSymbol: '♻️',
    emblemColor: '#34D399',
  },
  {
    id: 'eco_classic',
    name: 'Eco-Guardião',
    badge: 'Original',
    badgeColor: 'bg-emerald-500 text-emerald-950',
    description: 'O herói clássico da reciclagem com capa esmeralda e espada ecológica.',
    icon: '🛡️',
    jacketColor: '#22C55E',
    capeColor: '#15803D',
    pantsColor: '#1E293B',
    bootsColor: '#0F172A',
    helmetColor: '#166534',
    bladeColor: '#4ADE80',
    bladeCoreColor: '#FFFFFF',
    slashColor: '#4ADE80',
    slashGlowColor: 'rgba(74, 222, 128, 0.45)',
    guardColor: '#F59E0B',
    handleColor: '#78350F',
    emblemSymbol: '🌱',
    emblemColor: '#16A34A',
  },
  {
    id: 'asphalt_knight',
    name: 'Cavaleiro de Asfalto',
    badge: 'Resistente',
    badgeColor: 'bg-amber-500 text-amber-950',
    description: 'Armadura pesada de borracha vulcanizada e espada dourada anti-impacto.',
    icon: '⚔️',
    jacketColor: '#334155',
    capeColor: '#D97706',
    pantsColor: '#1E293B',
    bootsColor: '#B45309',
    helmetColor: '#0F172A',
    bladeColor: '#FBBF24',
    bladeCoreColor: '#FFFBEB',
    slashColor: '#F59E0B',
    slashGlowColor: 'rgba(245, 158, 11, 0.5)',
    guardColor: '#E2E8F0',
    handleColor: '#334155',
    emblemSymbol: '🛞',
    emblemColor: '#F59E0B',
  },
  {
    id: 'phoenix_fire',
    name: 'Fênix da Borracha',
    badge: 'Incandescente',
    badgeColor: 'bg-red-500 text-white',
    description: 'Forjado no calor do triturador, corta pneus com chamas purificadoras.',
    icon: '🔥',
    jacketColor: '#EA580C',
    capeColor: '#DC2626',
    pantsColor: '#7F1D1D',
    bootsColor: '#451A03',
    helmetColor: '#991B1B',
    bladeColor: '#F97316',
    bladeCoreColor: '#FEF08A',
    slashColor: '#EF4444',
    slashGlowColor: 'rgba(239, 68, 68, 0.55)',
    guardColor: '#F59E0B',
    handleColor: '#451A03',
    emblemSymbol: '🔥',
    emblemColor: '#EF4444',
  },
  {
    id: 'cyber_pneu_2099',
    name: 'Cyber Pneu 2099',
    badge: 'Cibernético',
    badgeColor: 'bg-cyan-500 text-cyan-950',
    description: 'Androide do futuro equipado com sabre de plasma e propulsores a vácuo.',
    icon: '🤖',
    jacketColor: '#0284C7',
    capeColor: '#7C3AED',
    pantsColor: '#0F172A',
    bootsColor: '#0369A1',
    helmetColor: '#0369A1',
    bladeColor: '#38BDF8',
    bladeCoreColor: '#E0F2FE',
    slashColor: '#06B6D4',
    slashGlowColor: 'rgba(6, 182, 212, 0.55)',
    guardColor: '#C084FC',
    handleColor: '#1E1B4B',
    emblemSymbol: '⚡',
    emblemColor: '#06B6D4',
  },
  {
    id: 'shadow_ninja',
    name: 'Ninja das Sombras',
    badge: 'Furtivo',
    badgeColor: 'bg-purple-500 text-purple-950',
    description: 'Especialista em invasão de sucatas e desmanche de monstros de pneus.',
    icon: '🥷',
    jacketColor: '#18181B',
    capeColor: '#475569',
    pantsColor: '#09090B',
    bootsColor: '#27272A',
    helmetColor: '#18181B',
    bladeColor: '#A855F7',
    bladeCoreColor: '#F3E8FF',
    slashColor: '#C084FC',
    slashGlowColor: 'rgba(192, 132, 252, 0.5)',
    guardColor: '#71717A',
    handleColor: '#18181B',
    emblemSymbol: '🌑',
    emblemColor: '#A855F7',
  },
  {
    id: 'golden_master',
    name: 'Mestre Dourado',
    badge: 'Lendário',
    badgeColor: 'bg-yellow-400 text-yellow-950 font-black',
    description: 'O guardião supremo consagrado pelo comitê mundial de sustentabilidade.',
    icon: '👑',
    jacketColor: '#D97706',
    capeColor: '#F59E0B',
    pantsColor: '#78350F',
    bootsColor: '#92400E',
    helmetColor: '#B45309',
    bladeColor: '#FDE047',
    bladeCoreColor: '#FFFFFF',
    slashColor: '#FACC15',
    slashGlowColor: 'rgba(250, 204, 21, 0.6)',
    guardColor: '#FFFFFF',
    handleColor: '#78350F',
    emblemSymbol: '🌟',
    emblemColor: '#D97706',
  },
];

export const DEFAULT_SKIN_ID = 'economart';
export const DEFAULT_PLAYER_NAME = 'Economart';

export function getSkinById(skinId?: string): CharacterSkin {
  return CHARACTER_SKINS.find((s) => s.id === skinId) || CHARACTER_SKINS[0];
}

export const RANDOM_HERO_NAMES = [
  'Economart',
  'Eco-Guardião',
  'Eco-Guerreiro',
  'Capitão Pneu',
  'Guardião Verde',
  'Mestre Borracha',
  'Reciclador Ninja',
  'Fênix Ecológica',
  'Borracha Veloz',
  'Trovão Verde',
  'Defensor da Terra',
  'Comandante Limpo',
  'Titã da Natureza',
  'Guerreiro Solar',
  'Eco-Campeão',
];
