/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundController {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private musicInterval: number | null = null;
  private bgmPlaying: boolean = false;
  private step: number = 0;
  private musicTheme: 'horror' | 'retro' = 'horror';

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && this.bgmPlaying) {
      this.stopBGM();
    } else if (!muted && !this.bgmPlaying) {
      this.startBGM();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  public playJump() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.exponentialRampToValueAtTime(620, now + 0.15);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);
    } catch {
      // Audio error safety
    }
  }

  public playPickup() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.setValueAtTime(880, now + 0.05);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.12);
    } catch {
      // Audio error safety
    }
  }

  public playRecycleSuccess() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      const now = this.ctx.currentTime;
      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const noteTime = now + idx * 0.07;
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, noteTime);
        gain.gain.setValueAtTime(0.25, noteTime);
        gain.gain.exponentialRampToValueAtTime(0.005, noteTime + 0.25);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(noteTime);
        osc.stop(noteTime + 0.25);
      });
    } catch {
      // Audio error safety
    }
  }

  public playComboUp(multiplier: number) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const pitchScale = 1 + Math.min(0.6, (multiplier - 1) * 0.12);
      const baseNotes = [440, 554.37, 659.25, 880, 1108.7];
      const count = Math.min(5, 2 + multiplier);
      for (let i = 0; i < count; i++) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const noteTime = now + i * 0.055;
        osc.type = multiplier >= 4 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(baseNotes[i % baseNotes.length] * pitchScale, noteTime);
        gain.gain.setValueAtTime(0.22, noteTime);
        gain.gain.exponentialRampToValueAtTime(0.005, noteTime + 0.22);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(noteTime);
        osc.stop(noteTime + 0.22);
      }
      if (multiplier >= 3) {
        const bell = this.ctx.createOscillator();
        const bellGain = this.ctx.createGain();
        bell.type = 'sine';
        bell.frequency.setValueAtTime(1760 * pitchScale, now);
        bellGain.gain.setValueAtTime(0.18, now);
        bellGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        bell.connect(bellGain);
        bellGain.connect(this.ctx.destination);
        bell.start(now);
        bell.stop(now + 0.35);
      }
    } catch {
      // Audio error safety
    }
  }

  public playComboBreak() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(85, now + 0.25);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.005, now + 0.25);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    } catch {
      // Audio error safety
    }
  }

  public playRecycleError() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.linearRampToValueAtTime(120, now + 0.2);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    } catch {
      // Audio error safety
    }
  }

  public playSwordSlash() {
    this.playSwordSlashCombo(1);
  }

  public playSwordSlashCombo(step: 1 | 2 | 3 = 1) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      if (step === 1) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(650, now);
        osc.frequency.exponentialRampToValueAtTime(140, now + 0.13);
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(2000, now);
        filter.Q.setValueAtTime(3, now);
        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.13);
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.13);
      } else if (step === 2) {
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();
        osc1.type = 'sawtooth';
        osc1.frequency.setValueAtTime(820, now);
        osc1.frequency.exponentialRampToValueAtTime(220, now + 0.16);
        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(1240, now);
        osc2.frequency.exponentialRampToValueAtTime(330, now + 0.16);
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(2600, now);
        filter.Q.setValueAtTime(4, now);
        gain.gain.setValueAtTime(0.4, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.16);
        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 0.16);
        osc2.stop(now + 0.16);
      } else {
        const bassOsc = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();
        bassOsc.type = 'sine';
        bassOsc.frequency.setValueAtTime(240, now);
        bassOsc.frequency.exponentialRampToValueAtTime(45, now + 0.28);
        bassGain.gain.setValueAtTime(0.45, now);
        bassGain.gain.exponentialRampToValueAtTime(0.005, now + 0.28);
        bassOsc.connect(bassGain);
        bassGain.connect(this.ctx.destination);
        bassOsc.start(now);
        bassOsc.stop(now + 0.28);

        const sweepOsc = this.ctx.createOscillator();
        const sweepGain = this.ctx.createGain();
        const sweepFilter = this.ctx.createBiquadFilter();
        sweepOsc.type = 'sawtooth';
        sweepOsc.frequency.setValueAtTime(400, now);
        sweepOsc.frequency.linearRampToValueAtTime(1200, now + 0.12);
        sweepOsc.frequency.exponentialRampToValueAtTime(150, now + 0.26);
        sweepFilter.type = 'bandpass';
        sweepFilter.frequency.setValueAtTime(1800, now);
        sweepFilter.Q.setValueAtTime(3.5, now);
        sweepGain.gain.setValueAtTime(0.4, now);
        sweepGain.gain.exponentialRampToValueAtTime(0.01, now + 0.26);
        sweepOsc.connect(sweepFilter);
        sweepFilter.connect(sweepGain);
        sweepGain.connect(this.ctx.destination);
        sweepOsc.start(now);
        sweepOsc.stop(now + 0.26);

        const chimeNotes = [784, 1046, 1318];
        chimeNotes.forEach((f, idx) => {
          if (!this.ctx) return;
          const chimeOsc = this.ctx.createOscillator();
          const chimeGain = this.ctx.createGain();
          const t = now + 0.05 + idx * 0.04;
          chimeOsc.type = 'sine';
          chimeOsc.frequency.setValueAtTime(f, t);
          chimeGain.gain.setValueAtTime(0.2, t);
          chimeGain.gain.exponentialRampToValueAtTime(0.005, t + 0.2);
          chimeOsc.connect(chimeGain);
          chimeGain.connect(this.ctx.destination);
          chimeOsc.start(t);
          chimeOsc.stop(t + 0.2);
        });
      }
    } catch {
      // Audio safety
    }
  }

  public playHitStreakBonus(streak: number) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const baseNote = 587.33; // D5
      const notes = [
        baseNote,
        baseNote * 1.25,
        baseNote * 1.5,
        baseNote * 2,
      ];
      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const t = now + idx * 0.06;
        osc.type = streak >= 8 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(0.25, t);
        gain.gain.exponentialRampToValueAtTime(0.005, t + 0.22);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(t);
        osc.stop(t + 0.22);
      });
    } catch {
      // Audio safety
    }
  }

  public playShoot() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();
      const now = this.ctx.currentTime;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(200, now + 0.15);
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1500, now);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);
    } catch {
      // Audio error safety
    }
  }

  public playEnemyHit() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      osc.type = 'square';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(90, now + 0.1);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.1);
    } catch {
      // Audio error safety
    }
  }

  public playEnemyDefeated() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const notes = [392, 523.25, 659.25, 783.99]; // G4, C5, E5, G5
      const now = this.ctx.currentTime;
      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const noteTime = now + idx * 0.06;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteTime);
        gain.gain.setValueAtTime(0.25, noteTime);
        gain.gain.exponentialRampToValueAtTime(0.01, noteTime + 0.2);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(noteTime);
        osc.stop(noteTime + 0.2);
      });
    } catch {
      // Audio error safety
    }
  }

  public playPlayerHurt() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(240, now);
      osc.frequency.linearRampToValueAtTime(100, now + 0.2);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    } catch {
      // Audio error safety
    }
  }

  public playLevelComplete() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const melody = [
        { freq: 523.25, dur: 0.12 },
        { freq: 659.25, dur: 0.12 },
        { freq: 783.99, dur: 0.12 },
        { freq: 1046.5, dur: 0.35 },
      ];
      let currentTime = this.ctx.currentTime;
      melody.forEach((item) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(item.freq, currentTime);
        gain.gain.setValueAtTime(0.3, currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, currentTime + item.dur);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(currentTime);
        osc.stop(currentTime + item.dur);
        currentTime += item.dur;
      });
    } catch {
      // Audio error safety
    }
  }

  public playGameOver() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const notes = [440, 415.3, 392, 349.23];
      let currentTime = this.ctx.currentTime;
      notes.forEach((freq) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, currentTime);
        gain.gain.setValueAtTime(0.25, currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, currentTime + 0.35);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(currentTime);
        osc.stop(currentTime + 0.35);
        currentTime += 0.28;
      });
    } catch {
      // Audio error safety
    }
  }

  public playBossRoar() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(90, now);
      osc.frequency.linearRampToValueAtTime(140, now + 0.2);
      osc.frequency.exponentialRampToValueAtTime(50, now + 0.5);
      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.5);
    } catch {
      // Audio error safety
    }
  }

  public getMusicTheme(): 'horror' | 'retro' {
    return this.musicTheme;
  }

  public setMusicTheme(theme: 'horror' | 'retro') {
    if (this.musicTheme === theme) return;
    this.musicTheme = theme;
    if (this.bgmPlaying) {
      this.stopBGM();
      this.startBGM();
    }
  }

  public toggleMusicTheme(): 'horror' | 'retro' {
    const nextTheme: 'horror' | 'retro' = this.musicTheme === 'horror' ? 'retro' : 'horror';
    this.setMusicTheme(nextTheme);
    return nextTheme;
  }

  public startBGM(preferredTheme?: 'horror' | 'retro') {
    if (preferredTheme) {
      this.musicTheme = preferredTheme;
    }
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    if (this.bgmPlaying) {
      this.stopBGM();
    }
    this.bgmPlaying = true;
    this.step = 0;
    if (this.musicTheme === 'horror') {
      this.startHorrorMusicLoop();
    } else {
      this.startRetroMusicLoop();
    }
  }

  private startHorrorMusicLoop() {
    if (!this.ctx) return;
    const horrorMelodyScale = [
      293.66, 311.13, 349.23, 392.00, 415.30, 440.00,
      466.16, 554.37, 587.33, 622.25, 698.46, 830.61,
    ];
    const horrorBassDrones = [73.42, 69.30, 77.78, 73.42];
    const melodyPattern = [
      0, 1, 4, 1, 7, 6, 4, 1,
      8, 7, 4, 0, 9, 8, 4, 1,
      0, 4, 7, 4, 6, 4, 1, 0,
      7, 8, 9, 8, 7, 4, 1, 0,
    ];
    const bpm = 94;
    const stepDuration = (60 / bpm) / 2;

    this.musicInterval = window.setInterval(() => {
      if (this.isMuted || !this.ctx) return;
      try {
        const now = this.ctx.currentTime;
        const currentStep = this.step;

        if (currentStep % 4 === 0 || currentStep % 8 === 3) {
          const heartOsc = this.ctx.createOscillator();
          const heartGain = this.ctx.createGain();
          heartOsc.type = 'sine';
          heartOsc.frequency.setValueAtTime(currentStep % 4 === 0 ? 82 : 72, now);
          heartOsc.frequency.exponentialRampToValueAtTime(32, now + 0.12);
          heartGain.gain.setValueAtTime(currentStep % 4 === 0 ? 0.22 : 0.14, now);
          heartGain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
          heartOsc.connect(heartGain);
          heartGain.connect(this.ctx.destination);
          heartOsc.start(now);
          heartOsc.stop(now + 0.14);
        }

        if (currentStep % 8 === 0) {
          const droneRoot = horrorBassDrones[Math.floor(currentStep / 8) % horrorBassDrones.length];
          const bassOsc = this.ctx.createOscillator();
          const bassGain = this.ctx.createGain();
          bassOsc.type = 'sawtooth';
          bassOsc.frequency.setValueAtTime(droneRoot, now);

          const detuneOsc = this.ctx.createOscillator();
          detuneOsc.type = 'triangle';
          detuneOsc.frequency.setValueAtTime(droneRoot + 1.2, now);

          const filter = this.ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(140, now);
          filter.frequency.linearRampToValueAtTime(80, now + stepDuration * 3.5);
          bassGain.gain.setValueAtTime(0.12, now);
          bassGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 3.6);
          bassOsc.connect(filter);
          detuneOsc.connect(filter);
          filter.connect(bassGain);
          bassGain.connect(this.ctx.destination);
          bassOsc.start(now);
          detuneOsc.start(now);
          bassOsc.stop(now + stepDuration * 3.6);
          detuneOsc.stop(now + stepDuration * 3.6);
        }

        if (currentStep % 2 === 0 || (currentStep % 4 === 3 && Math.random() > 0.35)) {
          const noteIdx = melodyPattern[currentStep % melodyPattern.length];
          const noteFreq = horrorMelodyScale[noteIdx % horrorMelodyScale.length];
          const bellOsc = this.ctx.createOscillator();
          const bellGain = this.ctx.createGain();
          bellOsc.type = currentStep % 8 === 4 ? 'triangle' : 'sine';
          bellOsc.frequency.setValueAtTime(noteFreq, now);
          bellOsc.frequency.linearRampToValueAtTime(noteFreq * (Math.random() > 0.5 ? 1.008 : 0.992), now + 0.3);
          bellGain.gain.setValueAtTime(0.065, now);
          bellGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 1.6);
          bellOsc.connect(bellGain);
          bellGain.connect(this.ctx.destination);
          bellOsc.start(now);
          bellOsc.stop(now + stepDuration * 1.6);
        }

        if (currentStep % 16 === 8) {
          const ghostOsc = this.ctx.createOscillator();
          const ghostGain = this.ctx.createGain();
          ghostOsc.type = 'sine';
          ghostOsc.frequency.setValueAtTime(740, now);
          ghostOsc.frequency.exponentialRampToValueAtTime(622, now + stepDuration * 2.5);
          ghostGain.gain.setValueAtTime(0.001, now);
          ghostGain.gain.linearRampToValueAtTime(0.045, now + 0.4);
          ghostGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 3.0);
          ghostOsc.connect(ghostGain);
          ghostGain.connect(this.ctx.destination);
          ghostOsc.start(now);
          ghostOsc.stop(now + stepDuration * 3.0);
        }

        if (currentStep % 32 === 0 && currentStep > 0) {
          const chordFreqs = [415.30, 587.33, 830.61];
          chordFreqs.forEach((freq) => {
            if (!this.ctx) return;
            const stabOsc = this.ctx.createOscillator();
            const stabGain = this.ctx.createGain();
            stabOsc.type = 'triangle';
            stabOsc.frequency.setValueAtTime(freq, now);
            stabGain.gain.setValueAtTime(0.04, now);
            stabGain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
            stabOsc.connect(stabGain);
            stabGain.connect(this.ctx.destination);
            stabOsc.start(now);
            stabOsc.stop(now + 0.7);
          });
        }

        this.step++;
      } catch {
        // Safe fail
      }
    }, stepDuration * 1000);
  }

  private startRetroMusicLoop() {
    if (!this.ctx) return;
    const melodyScale = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25];
    const bassScale = [130.81, 146.83, 164.81, 196.00, 220.00];
    const melodyPattern = [
      0, 2, 4, 2, 3, 4, 5, 4,
      2, 4, 3, 1, 0, 2, 4, 3,
      5, 4, 3, 2, 4, 3, 2, 0,
      1, 2, 3, 4, 2, 0, 2, 4,
    ];
    const bassPattern = [
      0, 0, 3, 3, 2, 2, 4, 4,
      0, 0, 3, 3, 1, 1, 3, 3,
    ];
    const bpm = 125;
    const stepDuration = (60 / bpm) / 2;
    this.musicInterval = window.setInterval(() => {
      if (this.isMuted || !this.ctx) return;
      try {
        const now = this.ctx.currentTime;
        const melodyIdx = melodyPattern[this.step % melodyPattern.length];
        const bassIdx = bassPattern[Math.floor(this.step / 2) % bassPattern.length];
        if (this.step % 2 === 0 || Math.random() > 0.4) {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(melodyScale[melodyIdx % melodyScale.length], now);
          gain.gain.setValueAtTime(0.04, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 0.9);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + stepDuration * 0.9);
        }
        if (this.step % 4 === 0) {
          const bassOsc = this.ctx.createOscillator();
          const bassGain = this.ctx.createGain();
          bassOsc.type = 'sine';
          bassOsc.frequency.setValueAtTime(bassScale[bassIdx % bassScale.length], now);
          bassGain.gain.setValueAtTime(0.08, now);
          bassGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 1.8);
          bassOsc.connect(bassGain);
          bassGain.connect(this.ctx.destination);
          bassOsc.start(now);
          bassOsc.stop(now + stepDuration * 1.8);
        }
        this.step++;
      } catch {
        // Safe fail
      }
    }, stepDuration * 1000);
  }

  public stopBGM() {
    if (this.musicInterval !== null) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    this.bgmPlaying = false;
  }
}

export const soundManager = new SoundController();
