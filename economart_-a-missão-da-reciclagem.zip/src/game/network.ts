/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface NetworkRoomPlayer {
  id: string;
  name: string;
  skinId: string;
  isHost: boolean;
  isReady: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: number;
  hp: number;
  maxHp: number;
  carriedCategory: string | null;
  isAttacking: boolean;
  comboStep: number;
  isKnockedOut: boolean;
  isDisconnected?: boolean;
}

export interface NetworkRoomState {
  roomId: string;
  hostId: string;
  gameState: 'lobby' | 'playing';
  levelIndex: number;
  players: NetworkRoomPlayer[];
}

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'reconnecting';

type EventListener = (data: any) => void;

class NetworkManager {
  private ws: WebSocket | null = null;
  private connectionState: ConnectionState = 'disconnected';
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 8;
  private reconnectTimer: number | null = null;
  private pingInterval: number | null = null;
  private listeners = new Map<string, Set<EventListener>>();

  // Active session details for automatic recovery
  public currentRoomId: string | null = null;
  public playerId: string | null = null;
  public sessionToken: string | null = null;
  public isHost: boolean = false;
  public lastRoomState: NetworkRoomState | null = null;
  private isIntentionalDisconnect = false;

  constructor() {
    try {
      this.currentRoomId = sessionStorage.getItem('eco_room_id');
      this.playerId = sessionStorage.getItem('eco_player_id');
      this.sessionToken = sessionStorage.getItem('eco_session_token');
    } catch {
      // Storage unavailable fallback
    }
  }

  public getConnectionState(): ConnectionState {
    return this.connectionState;
  }

  public on(event: string, cb: EventListener) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(cb);
  }

  public off(event: string, cb: EventListener) {
    this.listeners.get(event)?.delete(cb);
  }

  private emit(event: string, data?: any) {
    const handlers = this.listeners.get(event);
    if (handlers) {
      handlers.forEach((h) => {
        try {
          h(data);
        } catch (err) {
          console.error(`Error in event listener for ${event}:`, err);
        }
      });
    }
  }

  public connect(): Promise<boolean> {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return Promise.resolve(true);
    }

    return new Promise((resolve) => {
      this.isIntentionalDisconnect = false;
      this.connectionState = this.reconnectAttempts > 0 ? 'reconnecting' : 'connecting';
      this.emit('connection_state_changed', this.connectionState);

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;

      try {
        this.ws = new WebSocket(wsUrl);
      } catch (err) {
        console.error('[Network] Could not instantiate WebSocket:', err);
        this.scheduleReconnect();
        resolve(false);
        return;
      }

      this.ws.onopen = () => {
        console.log('[Network] WebSocket connected successfully');
        this.connectionState = 'connected';
        this.reconnectAttempts = 0;
        this.emit('connection_state_changed', this.connectionState);

        // Start ping interval
        if (this.pingInterval) clearInterval(this.pingInterval);
        this.pingInterval = window.setInterval(() => {
          this.send({ type: 'ping' });
        }, 15000);

        // If we have saved session data, attempt immediate reconnection!
        if (this.currentRoomId && this.playerId && this.sessionToken) {
          console.log('[Network] Attempting session recovery with token...');
          this.send({
            type: 'reconnect_room',
            roomId: this.currentRoomId,
            playerId: this.playerId,
            sessionToken: this.sessionToken,
          });
        }

        resolve(true);
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleIncomingMessage(msg);
        } catch (err) {
          console.error('[Network] Failed to parse message:', err);
        }
      };

      this.ws.onerror = (err) => {
        console.warn('[Network] WebSocket error occurred:', err);
      };

      this.ws.onclose = (event) => {
        console.log(`[Network] WebSocket closed (code: ${event.code}, reason: ${event.reason})`);
        if (this.pingInterval) {
          clearInterval(this.pingInterval);
          this.pingInterval = null;
        }

        if (!this.isIntentionalDisconnect) {
          this.connectionState = 'reconnecting';
          this.emit('connection_state_changed', this.connectionState);
          this.emit('unexpected_disconnect', { code: event.code, reason: event.reason });
          this.scheduleReconnect();
        } else {
          this.connectionState = 'disconnected';
          this.emit('connection_state_changed', this.connectionState);
        }
        resolve(false);
      };
    });
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.warn('[Network] Maximum reconnect attempts reached.');
      this.connectionState = 'disconnected';
      this.emit('connection_state_changed', this.connectionState);
      this.emit('reconnect_failed', { reason: 'max_attempts' });
      return;
    }

    const delay = Math.min(1000 * Math.pow(1.5, this.reconnectAttempts), 8000);
    this.reconnectAttempts++;
    console.log(`[Network] Scheduling reconnect attempt #${this.reconnectAttempts} in ${delay}ms`);

    this.reconnectTimer = window.setTimeout(() => {
      this.connect();
    }, delay);
  }

  private handleIncomingMessage(msg: any) {
    switch (msg.type) {
      case 'pong':
        break;

      case 'joined_room':
        this.playerId = msg.playerId;
        this.sessionToken = msg.sessionToken;
        this.currentRoomId = msg.roomId;
        this.isHost = !!msg.isHost;
        this.lastRoomState = msg.roomState;
        this.saveSession();
        this.emit('joined_room', msg);
        break;

      case 'reconnected_success':
        this.playerId = msg.playerId;
        this.sessionToken = msg.sessionToken;
        this.currentRoomId = msg.roomId;
        this.isHost = !!msg.isHost;
        this.lastRoomState = msg.roomState;
        this.saveSession();
        this.emit('reconnected_success', msg);
        break;

      case 'reconnect_failed':
        this.clearSession();
        this.emit('reconnect_failed', msg);
        break;

      case 'room_updated':
        this.lastRoomState = msg.roomState;
        this.emit('room_updated', msg);
        break;

      case 'player_disconnected_temporary':
        this.lastRoomState = msg.roomState;
        this.emit('player_disconnected_temporary', msg);
        break;

      case 'player_reconnected':
        this.lastRoomState = msg.roomState;
        this.emit('player_reconnected', msg);
        break;

      case 'player_left':
        this.lastRoomState = msg.roomState;
        if (msg.roomState && msg.roomState.hostId === this.playerId) {
          this.isHost = true;
        }
        this.emit('player_left', msg);
        break;

      case 'room_full':
        this.emit('room_full', msg);
        break;

      case 'game_started':
        if (msg.roomState) this.lastRoomState = msg.roomState;
        this.emit('game_started', msg);
        break;

      case 'level_changed':
        this.emit('level_changed', msg);
        break;

      case 'remote_player_sync':
        this.emit('remote_player_sync', msg);
        break;

      case 'remote_player_attack':
        this.emit('remote_player_attack', msg);
        break;

      case 'remote_recycle_event':
        this.emit('remote_recycle_event', msg);
        break;

      case 'partner_revived':
        this.emit('partner_revived', msg);
        break;

      case 'chat_broadcast':
        this.emit('chat_broadcast', msg);
        break;

      default:
        this.emit(msg.type, msg);
    }
  }

  public send(data: Record<string, unknown>): boolean {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(data));
        return true;
      } catch (err) {
        console.error('[Network] Error sending payload:', err);
        return false;
      }
    }
    return false;
  }

  public joinRoom(roomId: string, name: string, skinId: string) {
    this.send({
      type: 'join_room',
      roomId: roomId.toUpperCase(),
      name,
      skinId,
    });
  }

  public leaveRoom() {
    this.isIntentionalDisconnect = true;
    this.send({ type: 'leave_room' });
    this.clearSession();
    this.lastRoomState = null;
    this.emit('left_room');
  }

  public setReady(ready: boolean) {
    this.send({ type: 'set_ready', ready });
  }

  public updateProfile(name: string, skinId: string) {
    this.send({ type: 'update_profile', name, skinId });
  }

  public startGame(levelIndex: number = 1) {
    this.send({ type: 'start_game', levelIndex });
  }

  public syncPlayer(playerData: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    facing: number;
    hp: number;
    carriedCategory: string | null;
    isAttacking: boolean;
    comboStep: number;
    isKnockedOut: boolean;
  }) {
    this.send({
      type: 'player_sync',
      ...playerData,
    });
  }

  public sendAttack(attackData: { x: number; y: number; facing: number; comboStep: number }) {
    this.send({
      type: 'player_attack',
      ...attackData,
    });
  }

  public sendRecycle(category: string, comboMultiplier: number) {
    this.send({
      type: 'recycle_event',
      category,
      comboMultiplier,
    });
  }

  public sendRevivePartner() {
    this.send({ type: 'revive_partner' });
  }

  public sendNextLevel(levelIndex: number) {
    this.send({ type: 'next_level', levelIndex });
  }

  public sendChatMessage(text: string) {
    this.send({ type: 'chat_message', text });
  }

  private saveSession() {
    try {
      if (this.currentRoomId) sessionStorage.setItem('eco_room_id', this.currentRoomId);
      if (this.playerId) sessionStorage.setItem('eco_player_id', this.playerId);
      if (this.sessionToken) sessionStorage.setItem('eco_session_token', this.sessionToken);
    } catch {
      // Ignore
    }
  }

  private clearSession() {
    this.currentRoomId = null;
    this.playerId = null;
    this.sessionToken = null;
    this.isHost = false;
    try {
      sessionStorage.removeItem('eco_room_id');
      sessionStorage.removeItem('eco_player_id');
      sessionStorage.removeItem('eco_session_token');
    } catch {
      // Ignore
    }
  }
}

export const networkManager = new NetworkManager();
