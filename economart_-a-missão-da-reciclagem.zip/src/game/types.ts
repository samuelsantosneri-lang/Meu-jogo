/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TrashCategory =
  | 'car_tire'
  | 'truck_tire'
  | 'water_tire'
  | 'bike_tire'
  | 'tractor_tire'
  | 'shredded_rubber';

export interface TrashItemDefinition {
  type: TrashCategory;
  name: string;
  binColor: string;
  binLabel: string;
  scoreValue: number;
}

export interface TrashItem {
  id: string;
  category: TrashCategory;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  vx: number;
  vy: number;
  isGrounded: boolean;
  isCarried: boolean;
  isRecycled: boolean;
  spawnTime: number;
}

export interface RecycleBin {
  category: TrashCategory;
  label: string;
  colorName: string;
  colorHex: string;
  darkColorHex: string;
  x: number;
  y: number;
  width: number;
  height: number;
  icon: string;
}

export type EnemyType =
  | 'pneu_saltitante'
  | 'pneu_espinhoso'
  | 'pneu_chamas'
  | 'pneu_trator_monstro'
  | 'super_pneu';

export interface Enemy {
  id: string;
  name: string;
  type: EnemyType;
  x: number;
  y: number;
  width: number;
  height: number;
  vx: number;
  vy: number;
  isGrounded: boolean;
  hp: number;
  maxHp: number;
  speed: number;
  facing: 1 | -1;
  attackCooldown: number;
  attackTimer: number;
  hurtTimer: number;
  defeatTimer: number;
  state: 'idle' | 'patrol' | 'chase' | 'attack' | 'hurt' | 'defeated';
  patrolMinX: number;
  patrolMaxX: number;
  isBoss?: boolean;
  bossPhase?: number;
  rotation?: number;
}

export interface Projectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  isFriendly: boolean;
  color: string;
  damage: number;
  lifetime: number;
  projectileType?: 'eco_blast' | 'eco_blast_cross' | 'eco_blast_finisher' | 'rolling_tire' | 'fire_blast' | 'flying_car';
  rotation?: number;
  vRot?: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  shape: 'circle' | 'leaf' | 'star' | 'spark' | 'smoke' | 'fire';
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
  vy: number;
  lifetime: number;
}

export interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
  type?: 'ground' | 'wood' | 'metal' | 'stone' | 'tire_stack';
}

export interface LevelConfig {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  backgroundTheme: 'tires_day' | 'tires_dusk' | 'tires_fire' | 'tires_scrapyard' | 'super_pneu_arena';
  availableBins: TrashCategory[];
  trashItemsToSpawn: {
    category: TrashCategory;
    name: string;
    x: number;
    y: number;
  }[];
  monstersToSpawn: {
    type: EnemyType;
    name: string;
    x: number;
    y: number;
    hp: number;
    triggerRecycledCount: number;
  }[];
  platforms: Platform[];
  educationalFact: {
    title: string;
    message: string;
    tip: string;
  };
}

export type GameMode = 'single' | 'local_coop' | 'online_coop';

export interface PlayerState {
  name: string;
  skinId: string;
  playerIndex: 1 | 2;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  isGrounded: boolean;
  facing: 1 | -1;
  hp: number;
  maxHp: number;
  invincibleTimer: number;
  attackCooldown: number;
  carriedItem: TrashItem | null;
  walkFrame: number;
  isAttacking: boolean;
  attackAnimTimer: number;
  isSwordSlashing: boolean;
  swordSlashTimer: number;
  attackCharges: number;
  maxAttackCharges: number;
  chargeRegenTimer: number;
  attackComboStep: 1 | 2 | 3;
  comboWindowTimer: number;
  isKnockedOut: boolean;
  reviveProgress: number;
  isDisconnected?: boolean;
}

export interface GameStats {
  score: number;
  trashRecycled: number;
  trashFailed: number;
  monstersDefeated: number;
  currentLevel: number;
  highScore: number;
  comboCount: number;
  comboMultiplier: number;
  comboTimer: number;
  maxComboTimer: number;
  maxCombo: number;
  comboBonusScore: number;
  attackHitStreak: number;
  maxAttackHitStreak: number;
  attackHitStreakTimer: number;
  p1RecycledCount?: number;
  p2RecycledCount?: number;
}

export type GameView =
  | 'TITLE'
  | 'PLAYING'
  | 'PAUSED'
  | 'LEVEL_CLEARED'
  | 'GAME_OVER'
  | 'VICTORY'
  | 'HOW_TO_PLAY'
  | 'CREDITS';
