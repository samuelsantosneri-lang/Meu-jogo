/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LevelConfig, TrashCategory } from './types';

export const TRASH_CATEGORY_INFO: Record<
  TrashCategory,
  {
    name: string;
    binColorName: string;
    binColorHex: string;
    binDarkHex: string;
    iconSymbol: string;
    examples: string[];
    destination: string;
  }
> = {
  car_tire: {
    name: 'Pneu de Carro',
    binColorName: 'Amarelo (Asfalto)',
    binColorHex: '#FBBF24',
    binDarkHex: '#B45309',
    iconSymbol: '🚗',
    examples: ['Pneu Aro 14', 'Pneu Aro 15', 'Pneu de Passeio'],
    destination: 'Asfalto Ecológico (Pavimentação durável e segura)',
  },
  truck_tire: {
    name: 'Pneu de Caminhão',
    binColorName: 'Vermelho (Triturador)',
    binColorHex: '#EF4444',
    binDarkHex: '#B91C1C',
    iconSymbol: '🚛',
    examples: ['Pneu de Carga', 'Pneu de Ônibus', 'Pneu Radial Pesado'],
    destination: 'Triturador de Borracha (Matéria-prima industrial)',
  },
  water_tire: {
    name: 'Pneu com Água Parada',
    binColorName: 'Azul (Anti-Dengue)',
    binColorHex: '#38BDF8',
    binDarkHex: '#0284C7',
    iconSymbol: '🦟',
    examples: ['Pneu com Larvas', 'Pneu na Chuva', 'Foco de Mosquito'],
    destination: 'Drenagem & Sanitização (Eliminação do foco do mosquito da dengue!)',
  },
  bike_tire: {
    name: 'Pneu de Moto/Bicicleta',
    binColorName: 'Verde (Calçados)',
    binColorHex: '#10B981',
    binDarkHex: '#047857',
    iconSymbol: '🏍️',
    examples: ['Pneu de Moto', 'Pneu de Bicicleta', 'Câmara de Ar'],
    destination: 'Solas de Sapatos e Calçados Ecológicos',
  },
  tractor_tire: {
    name: 'Pneu Gigante de Trator',
    binColorName: 'Roxo (Playground)',
    binColorHex: '#A855F7',
    binDarkHex: '#7E22CE',
    iconSymbol: '🚜',
    examples: ['Pneu Agrícola', 'Pneu de Retroescavadeira'],
    destination: 'Parques Infantis e Pisos de Borracha Amortecedores',
  },
  shredded_rubber: {
    name: 'Borracha Moída',
    binColorName: 'Laranja (Isolamento)',
    binColorHex: '#F97316',
    binDarkHex: '#C2410C',
    iconSymbol: '🍂',
    examples: ['Cavacos de Borracha', 'Pó de Pneu Moído'],
    destination: 'Isolamento Térmico, Acústico e Gramados Sintéticos',
  },
};

export const LEVELS: LevelConfig[] = [
  {
    id: 1,
    title: 'Fase 1: O Pátio dos Pneus Descartados',
    subtitle: 'Primeiros passos no descarte de pneus',
    description:
      'Recolha os pneus de carro e clique na lixeira correspondente para enviá-los à reciclagem! Cuidado com o Pneu Saltitante reforçado!',
    backgroundTheme: 'tires_day',
    availableBins: ['car_tire', 'bike_tire'],
    trashItemsToSpawn: [
      { category: 'car_tire', name: 'Pneu de Carro Velho', x: 260, y: 460 },
      { category: 'bike_tire', name: 'Pneu de Moto Gasto', x: 420, y: 460 },
      { category: 'car_tire', name: 'Pneu Careca', x: 620, y: 340 },
      { category: 'bike_tire', name: 'Pneu de Bicicleta', x: 820, y: 460 },
    ],
    monstersToSpawn: [
      {
        type: 'pneu_saltitante',
        name: 'Pneu Saltitante Voraz',
        x: 750,
        y: 440,
        hp: 7,
        triggerRecycledCount: 2,
      },
    ],
    platforms: [
      { x: 0, y: 500, width: 1000, height: 100, type: 'ground' },
      { x: 220, y: 380, width: 140, height: 22, type: 'tire_stack' },
      { x: 560, y: 360, width: 160, height: 22, type: 'tire_stack' },
    ],
    educationalFact: {
      title: 'Por que reciclar pneus?',
      message:
        'Pneus descartados na natureza demoram cerca de 600 anos para se decompor! Quando reciclados, viram asfalto ecológico com menor ruído e maior aderência.',
      tip: 'Clique na Estação de Asfalto (Amarela) para pneus de carro e Calçados (Verde) para motos!',
    },
  },
  {
    id: 2,
    title: 'Fase 2: Montanhas de Pneus & Alerta da Dengue',
    subtitle: 'Cuidado com a água acumulada nos pneus!',
    description:
      'Inimigos mais velozes surgiram! Drene a água parada dos pneus e derrote os Pneus Espinhosos de alta resistência.',
    backgroundTheme: 'tires_dusk',
    availableBins: ['water_tire', 'car_tire', 'bike_tire'],
    trashItemsToSpawn: [
      { category: 'water_tire', name: 'Pneu com Água Parada', x: 280, y: 460 },
      { category: 'car_tire', name: 'Pneu com Arames', x: 460, y: 340 },
      { category: 'water_tire', name: 'Pneu com Foco de Larvas', x: 640, y: 460 },
      { category: 'bike_tire', name: 'Pneu de Moto Furado', x: 780, y: 300 },
      { category: 'water_tire', name: 'Pneu Encharcado', x: 880, y: 460 },
    ],
    monstersToSpawn: [
      {
        type: 'pneu_saltitante',
        name: 'Pneu Batedor Veloz',
        x: 600,
        y: 440,
        hp: 8,
        triggerRecycledCount: 1,
      },
      {
        type: 'pneu_espinhoso',
        name: 'Pneu com Espinhos de Aço Blindado',
        x: 820,
        y: 440,
        hp: 11,
        triggerRecycledCount: 2,
      },
    ],
    platforms: [
      { x: 0, y: 500, width: 1000, height: 100, type: 'ground' },
      { x: 180, y: 390, width: 130, height: 22, type: 'tire_stack' },
      { x: 420, y: 360, width: 150, height: 22, type: 'tire_stack' },
      { x: 740, y: 320, width: 160, height: 22, type: 'tire_stack' },
    ],
    educationalFact: {
      title: 'Combate à Dengue e Zika',
      message:
        'Pneus ao ar livre são um dos maiores focos de proliferação do mosquito transmissor da dengue. Nunca guarde pneus descobertos na chuva!',
      tip: 'Clique na Estação de Drenagem (Azul) para neutralizar os focos de dengue!',
    },
  },
  {
    id: 3,
    title: 'Fase 3: A Pista da Queima Clandestina',
    subtitle: 'Pare a queima tóxica de borracha!',
    description:
      'O Pneu em Chamas agora dispara tempestades de fogo! Mantenha a distância, ataque com o raio verde e recicle os pneus pesados.',
    backgroundTheme: 'tires_fire',
    availableBins: ['truck_tire', 'car_tire', 'water_tire', 'shredded_rubber'],
    trashItemsToSpawn: [
      { category: 'truck_tire', name: 'Pneu de Caminhão Pesado', x: 240, y: 460 },
      { category: 'shredded_rubber', name: 'Cavacos de Borracha', x: 430, y: 350 },
      { category: 'car_tire', name: 'Pneu de Caminhonete', x: 600, y: 460 },
      { category: 'truck_tire', name: 'Pneu de Ônibus Descartado', x: 740, y: 280 },
      { category: 'water_tire', name: 'Pneu D’água Aquecido', x: 860, y: 460 },
      { category: 'shredded_rubber', name: 'Restos de Banda de Rodagem', x: 920, y: 460 },
    ],
    monstersToSpawn: [
      {
        type: 'pneu_saltitante',
        name: 'Pneu Batedor Tóxico',
        x: 280,
        y: 440,
        hp: 9,
        triggerRecycledCount: 0,
      },
      {
        type: 'pneu_saltitante',
        name: 'Pneu Saltitante Tóxico',
        x: 380,
        y: 440,
        hp: 8,
        triggerRecycledCount: 1,
      },
      {
        type: 'pneu_espinhoso',
        name: 'Pneu Espinhoso Flamejante',
        x: 450,
        y: 440,
        hp: 11,
        triggerRecycledCount: 1,
      },
      {
        type: 'pneu_saltitante',
        name: 'Pneu Mutante de Choque',
        x: 520,
        y: 440,
        hp: 9,
        triggerRecycledCount: 2,
      },
      {
        type: 'pneu_espinhoso',
        name: 'Pneu Espinhoso de Aço',
        x: 680,
        y: 440,
        hp: 10,
        triggerRecycledCount: 2,
      },
      {
        type: 'pneu_chamas',
        name: 'Fúria de Chamas Vulcânicas',
        x: 760,
        y: 440,
        hp: 13,
        triggerRecycledCount: 3,
      },
      {
        type: 'pneu_chamas',
        name: 'Pneu Vulcânico em Chamas',
        x: 840,
        y: 440,
        hp: 14,
        triggerRecycledCount: 3,
      },
      {
        type: 'pneu_chamas',
        name: 'Segundo Pneu em Chamas',
        x: 890,
        y: 440,
        hp: 12,
        triggerRecycledCount: 4,
      },
    ],
    platforms: [
      { x: 0, y: 500, width: 1000, height: 100, type: 'ground' },
      { x: 200, y: 390, width: 130, height: 22, type: 'tire_stack' },
      { x: 390, y: 370, width: 140, height: 22, type: 'metal' },
      { x: 690, y: 300, width: 160, height: 22, type: 'tire_stack' },
    ],
    educationalFact: {
      title: 'Perigo da Fumaça de Pneus',
      message:
        'A queima de pneus polui o ar com monóxido de carbono, enxofre e metais pesados. A reciclagem mecânica e trituração é a única via limpa e sustentável.',
      tip: 'Pneus pesados vão para o Triturador (Vermelho) e borracha picada para Isolamento (Laranja)!',
    },
  },
  {
    id: 4,
    title: 'Fase 4: O Ferro-Velho dos Pneus Gigantes',
    subtitle: 'Pneus de tratores agrícolas e sucatas de ferro',
    description:
      'Inimigos com couraça de aço e pisões destruidores! Use os cliques rápidos nas lixeiras para reciclar com agilidade.',
    backgroundTheme: 'tires_scrapyard',
    availableBins: ['tractor_tire', 'truck_tire', 'car_tire', 'shredded_rubber'],
    trashItemsToSpawn: [
      { category: 'tractor_tire', name: 'Pneu Gigante de Trator', x: 260, y: 460 },
      { category: 'truck_tire', name: 'Pneu de Carreta', x: 420, y: 330 },
      { category: 'tractor_tire', name: 'Pneu de Colheitadeira', x: 580, y: 230 },
      { category: 'shredded_rubber', name: 'Borracha Moída', x: 720, y: 350 },
      { category: 'car_tire', name: 'Pneu de SUV', x: 850, y: 460 },
      { category: 'tractor_tire', name: 'Pneu de Retroescavadeira', x: 920, y: 240 },
    ],
    monstersToSpawn: [
      {
        type: 'pneu_saltitante',
        name: 'Pneu Batedor de Sucata Blindado',
        x: 260,
        y: 440,
        hp: 10,
        triggerRecycledCount: 0,
      },
      {
        type: 'pneu_saltitante',
        name: 'Pneu Saltitante de Sucata',
        x: 360,
        y: 440,
        hp: 9,
        triggerRecycledCount: 1,
      },
      {
        type: 'pneu_espinhoso',
        name: 'Pneu Espinhoso Titânico',
        x: 480,
        y: 440,
        hp: 12,
        triggerRecycledCount: 2,
      },
      {
        type: 'pneu_trator_monstro',
        name: 'Pneu Trator Esmagador de Metal',
        x: 550,
        y: 440,
        hp: 16,
        triggerRecycledCount: 2,
      },
      {
        type: 'pneu_espinhoso',
        name: 'Pneu Espinhoso Fatiador',
        x: 640,
        y: 440,
        hp: 11,
        triggerRecycledCount: 3,
      },
      {
        type: 'pneu_trator_monstro',
        name: 'Pneu Trator Demolidor Blindado',
        x: 800,
        y: 440,
        hp: 18,
        triggerRecycledCount: 3,
      },
      {
        type: 'pneu_espinhoso',
        name: 'Pneu Espinhoso de Aço Puro',
        x: 720,
        y: 440,
        hp: 12,
        triggerRecycledCount: 4,
      },
      {
        type: 'pneu_trator_monstro',
        name: 'Pneu Trator Titã Pesado',
        x: 870,
        y: 440,
        hp: 16,
        triggerRecycledCount: 4,
      },
    ],
    platforms: [
      { x: 0, y: 500, width: 1000, height: 100, type: 'ground' },
      { x: 180, y: 400, width: 130, height: 22, type: 'tire_stack' },
      { x: 380, y: 350, width: 140, height: 22, type: 'tire_stack' },
      { x: 550, y: 250, width: 140, height: 22, type: 'tire_stack' },
      { x: 700, y: 370, width: 140, height: 22, type: 'tire_stack' },
      { x: 870, y: 260, width: 120, height: 22, type: 'metal' },
    ],
    educationalFact: {
      title: 'Pneus em Parques e Playgrounds',
      message:
        'Pneus gigantes de trator são higienizados e transformados em brinquedos, balanços e pistas de obstáculos em praças públicas e creches!',
      tip: 'Clique na Estação Roxa para mandar pneus de trator para os playgrounds!',
    },
  },
  {
    id: 5,
    title: 'Fase 5: A Batalha Contra o SUPER PNEU!',
    subtitle: 'O Chefe Supremo Reforçado que Lança Fogo, Pneus e Carros!',
    description:
      'O SUPER PNEU agora possui +100 de vida (136 HP)! Use seus combos de espada, esquive dos projéteis e purifique a arena final!',
    backgroundTheme: 'super_pneu_arena',
    availableBins: ['car_tire', 'truck_tire', 'water_tire', 'bike_tire', 'tractor_tire', 'shredded_rubber'],
    trashItemsToSpawn: [
      { category: 'car_tire', name: 'Pneu Descartado', x: 260, y: 460 },
      { category: 'water_tire', name: 'Pneu com Água da Chuva', x: 380, y: 350 },
      { category: 'truck_tire', name: 'Pneu de Caminhão', x: 520, y: 260 },
      { category: 'bike_tire', name: 'Pneu de Motocicleta', x: 670, y: 350 },
      { category: 'tractor_tire', name: 'Pneu Gigante', x: 800, y: 460 },
      { category: 'shredded_rubber', name: 'Cavacos de Pneu', x: 920, y: 360 },
    ],
    monstersToSpawn: [
      {
        type: 'super_pneu',
        name: 'O COLOSSAL SUPER PNEU',
        x: 750,
        y: 350,
        hp: 136,
        triggerRecycledCount: 1,
      },
      {
        type: 'pneu_chamas',
        name: 'Pneu de Chamas Infernal',
        x: 300,
        y: 440,
        hp: 13,
        triggerRecycledCount: 0,
      },
      {
        type: 'pneu_chamas',
        name: 'Guardião Flamejante',
        x: 420,
        y: 440,
        hp: 12,
        triggerRecycledCount: 1,
      },
      {
        type: 'pneu_espinhoso',
        name: 'Escudeiro de Espinhos',
        x: 580,
        y: 440,
        hp: 12,
        triggerRecycledCount: 2,
      },
      {
        type: 'pneu_trator_monstro',
        name: 'Pneu Trator Blindagem Negra',
        x: 490,
        y: 440,
        hp: 17,
        triggerRecycledCount: 2,
      },
      {
        type: 'pneu_saltitante',
        name: 'Pneu Saltitante Pesadelo',
        x: 680,
        y: 440,
        hp: 10,
        triggerRecycledCount: 3,
      },
      {
        type: 'pneu_trator_monstro',
        name: 'Sub-Chefe Demolidor',
        x: 860,
        y: 440,
        hp: 16,
        triggerRecycledCount: 3,
      },
    ],
    platforms: [
      { x: 0, y: 500, width: 1000, height: 100, type: 'ground' },
      { x: 190, y: 400, width: 130, height: 22, type: 'tire_stack' },
      { x: 350, y: 370, width: 140, height: 22, type: 'tire_stack' },
      { x: 490, y: 280, width: 150, height: 22, type: 'tire_stack' },
      { x: 640, y: 370, width: 140, height: 22, type: 'tire_stack' },
      { x: 860, y: 380, width: 130, height: 22, type: 'tire_stack' },
    ],
    educationalFact: {
      title: 'Você Derrotou o Super Pneu!',
      message:
        'A reciclagem de pneus reduz montanhas de poluição, combate a dengue e economiza matérias-primas fósseis para a indústria!',
      tip: 'Você é o maior Guardião da Reciclagem de Pneus do Planeta!',
    },
  },
];
