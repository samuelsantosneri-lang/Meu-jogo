/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Enemy,
  FloatingText,
  Particle,
  Platform,
  PlayerState,
  Projectile,
  RecycleBin,
  TrashCategory,
  TrashItem,
} from './types';
import { TRASH_CATEGORY_INFO } from './levels';
import { getSkinById } from './skins';

export class CanvasRenderer {
  private ctx: CanvasRenderingContext2D;
  private width: number;
  private height: number;

  constructor(ctx: CanvasRenderingContext2D, width: number, height: number) {
    this.ctx = ctx;
    this.width = width;
    this.height = height;
  }

  public setDimensions(width: number, height: number) {
    this.width = width;
    this.height = height;
  }

  public clear() {
    this.ctx.clearRect(0, 0, this.width, this.height);
  }

  public drawBackground(
    theme: string,
    cleanlinessRatio: number,
    time: number
  ) {
    const ctx = this.ctx;
    const w = this.width;
    const h = this.height;

    const skyGrad = ctx.createLinearGradient(0, 0, 0, h * 0.75);
    if (theme === 'super_pneu_arena') {
      if (cleanlinessRatio > 0.6) {
        skyGrad.addColorStop(0, '#38BDF8');
        skyGrad.addColorStop(0.7, '#FED7AA');
        skyGrad.addColorStop(1, '#FEF08A');
      } else {
        skyGrad.addColorStop(0, '#450A0A');
        skyGrad.addColorStop(0.5, '#7F1D1D');
        skyGrad.addColorStop(1, '#9A3412');
      }
    } else if (theme === 'tires_fire') {
      skyGrad.addColorStop(0, '#1E293B');
      skyGrad.addColorStop(0.5, '#7C2D12');
      skyGrad.addColorStop(1, '#EA580C');
    } else if (theme === 'tires_dusk') {
      skyGrad.addColorStop(0, '#312E81');
      skyGrad.addColorStop(0.6, '#C026D3');
      skyGrad.addColorStop(1, '#F59E0B');
    } else {
      if (cleanlinessRatio > 0.5) {
        skyGrad.addColorStop(0, '#38BDF8');
        skyGrad.addColorStop(0.6, '#BAE6FD');
        skyGrad.addColorStop(1, '#E0F2FE');
      } else {
        skyGrad.addColorStop(0, '#64748B');
        skyGrad.addColorStop(0.6, '#94A3B8');
        skyGrad.addColorStop(1, '#CBD5E1');
      }
    }

    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, h);

    const celestialX = w - 120;
    const celestialY = 90;
    const isBossTheme = theme === 'super_pneu_arena' || theme === 'tires_fire';
    if (isBossTheme && cleanlinessRatio <= 0.6) {
      ctx.fillStyle = 'rgba(239, 68, 68, 0.25)';
      ctx.beginPath();
      ctx.arc(celestialX, celestialY, 65, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(249, 115, 22, 0.45)';
      ctx.beginPath();
      ctx.arc(celestialX, celestialY, 45, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(celestialX, celestialY, 26, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = 'rgba(253, 224, 71, 0.25)';
      ctx.beginPath();
      ctx.arc(celestialX, celestialY, 55, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(254, 240, 138, 0.5)';
      ctx.beginPath();
      ctx.arc(celestialX, celestialY, 38, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#FDE047';
      ctx.beginPath();
      ctx.arc(celestialX, celestialY, 24, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = cleanlinessRatio > 0.6 ? '#65A30D' : '#1E293B';
    ctx.beginPath();
    ctx.moveTo(0, 480);
    ctx.quadraticCurveTo(w * 0.2, 380, w * 0.4, 430);
    ctx.quadraticCurveTo(w * 0.7, 360, w, 440);
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.fill();

    this.drawBackgroundTirePiles(cleanlinessRatio);

    if (theme === 'super_pneu_arena' || theme === 'tires_scrapyard') {
      this.drawScrapCarSilhouette(120, 450, '#0F172A');
      this.drawScrapCarSilhouette(480, 440, '#0F172A');
      this.drawScrapCarSilhouette(860, 455, '#0F172A');
    }
  }

  private drawBackgroundTirePiles(cleanlinessRatio: number) {
    const ctx = this.ctx;
    const tireColor = cleanlinessRatio > 0.6 ? '#15803D' : '#0F172A';
    ctx.fillStyle = tireColor;
    const piles = [
      { x: 80, y: 460, r: 24 },
      { x: 120, y: 450, r: 28 },
      { x: 160, y: 465, r: 22 },
      { x: 340, y: 460, r: 26 },
      { x: 380, y: 445, r: 30 },
      { x: 420, y: 465, r: 24 },
      { x: 620, y: 455, r: 28 },
      { x: 660, y: 440, r: 32 },
      { x: 700, y: 460, r: 26 },
      { x: 880, y: 450, r: 30 },
      { x: 920, y: 465, r: 24 },
    ];
    for (const p of piles) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * 0.45, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = tireColor;
    }
  }

  private drawScrapCarSilhouette(x: number, y: number, color: string) {
    const ctx = this.ctx;
    ctx.save();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(x, y - 24, 70, 24, [8, 8, 2, 2]);
    ctx.fill();
    ctx.beginPath();
    ctx.roundRect(x + 14, y - 42, 40, 20, [6, 6, 0, 0]);
    ctx.fill();
    ctx.fillStyle = '#020617';
    ctx.beginPath();
    ctx.arc(x + 16, y, 10, 0, Math.PI * 2);
    ctx.arc(x + 54, y, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  public drawPlatforms(platforms: Platform[], cleanlinessRatio: number) {
    const ctx = this.ctx;
    for (const p of platforms) {
      if (p.type === 'ground') {
        ctx.fillStyle = '#0F172A';
        ctx.fillRect(p.x, p.y + 16, p.width, p.height - 16);
        ctx.fillStyle = cleanlinessRatio > 0.4 ? '#22C55E' : '#334155';
        ctx.fillRect(p.x, p.y, p.width, 18);
        ctx.fillStyle = '#1E293B';
        for (let gx = p.x; gx < p.x + p.width; gx += 20) {
          ctx.fillRect(gx, p.y + 6, 10, 6);
        }
        if (cleanlinessRatio > 0.3) {
          const flowerCols = ['#F59E0B', '#38BDF8', '#EC4899', '#A855F7'];
          for (let fx = 50; fx < p.width - 50; fx += 90) {
            ctx.fillStyle = flowerCols[(fx / 90) % flowerCols.length];
            ctx.beginPath();
            ctx.arc(fx, p.y - 4, 5, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#FEF08A';
            ctx.beginPath();
            ctx.arc(fx, p.y - 4, 2, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      } else if (p.type === 'tire_stack') {
        ctx.save();
        ctx.fillStyle = '#1E293B';
        ctx.beginPath();
        ctx.roundRect(p.x, p.y, p.width, p.height, 8);
        ctx.fill();
        ctx.fillStyle = '#0F172A';
        for (let tx = p.x + 4; tx < p.x + p.width - 12; tx += 14) {
          ctx.fillRect(tx, p.y + 3, 6, p.height - 6);
        }
        ctx.fillStyle = '#FBBF24';
        ctx.fillRect(p.x + 4, p.y + 1, p.width - 8, 3);
        ctx.restore();
      } else {
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.roundRect(p.x, p.y, p.width, p.height, 4);
        ctx.fill();
        ctx.fillStyle = '#10B981';
        ctx.fillRect(p.x + 4, p.y + 2, p.width - 8, 3);
      }
    }
  }

  public drawRecycleBins(
    bins: RecycleBin[],
    carriedCategory: TrashCategory | null,
    time: number
  ) {
    const ctx = this.ctx;
    for (const bin of bins) {
      const isTarget = carriedCategory === bin.category;
      const bobY = isTarget ? Math.sin(time * 8) * 4 : 0;
      if (isTarget) {
        ctx.save();
        ctx.fillStyle = bin.colorHex;
        ctx.globalAlpha = 0.28 + Math.sin(time * 10) * 0.15;
        ctx.beginPath();
        ctx.arc(bin.x + bin.width / 2, bin.y + bin.height / 2 + bobY, 48, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      ctx.save();
      ctx.translate(0, bobY);
      ctx.fillStyle = bin.colorHex;
      ctx.beginPath();
      ctx.roundRect(bin.x, bin.y + 12, bin.width, bin.height - 12, [0, 0, 8, 8]);
      ctx.fill();
      ctx.strokeStyle = bin.darkColorHex;
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = bin.darkColorHex;
      ctx.beginPath();
      ctx.roundRect(bin.x - 4, bin.y, bin.width + 8, 14, [6, 6, 2, 2]);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      const cx = bin.x + bin.width / 2;
      const cy = bin.y + 36;
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(bin.icon || '♻️', cx, cy);

      ctx.font = 'bold 8px "Fredoka", sans-serif';
      ctx.fillStyle = '#FFFFFF';
      ctx.fillText(bin.label.toUpperCase().slice(0, 10), cx, cy + 18);

      if (isTarget) {
        ctx.fillStyle = '#FEF08A';
        ctx.beginPath();
        ctx.moveTo(cx, bin.y - 18);
        ctx.lineTo(cx - 9, bin.y - 30);
        ctx.lineTo(cx + 9, bin.y - 30);
        ctx.closePath();
        ctx.fill();
        ctx.font = 'bold 11px "Fredoka", sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText('CLIQUE AQUI!', cx, bin.y - 35);
      }
      ctx.restore();
    }
  }

  public drawTrashItems(items: TrashItem[], time: number) {
    const ctx = this.ctx;
    for (const item of items) {
      if (item.isCarried || item.isRecycled) continue;
      const bob = Math.sin(time * 4 + item.x) * 2;
      const x = item.x;
      const y = item.y + bob;
      const info = TRASH_CATEGORY_INFO[item.category];

      ctx.save();
      ctx.fillStyle = info.binColorHex;
      ctx.globalAlpha = 0.22;
      ctx.beginPath();
      ctx.arc(x + item.width / 2, y + item.height / 2, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.translate(x + 12, y + 12);
      switch (item.category) {
        case 'car_tire': {
          ctx.fillStyle = '#1E293B';
          ctx.beginPath();
          ctx.arc(0, 0, 12, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#94A3B8';
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#0F172A';
          ctx.beginPath();
          ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case 'truck_tire': {
          ctx.fillStyle = '#0F172A';
          ctx.beginPath();
          ctx.arc(0, 0, 14, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#475569';
          ctx.lineWidth = 2;
          ctx.stroke();
          ctx.fillStyle = '#64748B';
          ctx.beginPath();
          ctx.arc(0, 0, 7, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case 'water_tire': {
          ctx.fillStyle = '#1E293B';
          ctx.beginPath();
          ctx.arc(0, 0, 12, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#38BDF8';
          ctx.beginPath();
          ctx.arc(0, 0, 6.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(0, 0, 3, 0, Math.PI * 2);
          ctx.stroke();
          break;
        }
        case 'bike_tire': {
          ctx.fillStyle = '#1E293B';
          ctx.beginPath();
          ctx.arc(0, 0, 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#CBD5E1';
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#475569';
          ctx.beginPath();
          ctx.arc(0, 0, 2, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case 'tractor_tire': {
          ctx.fillStyle = '#0F172A';
          ctx.beginPath();
          ctx.arc(0, 0, 15, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#F59E0B';
          for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
            const lx = Math.cos(a) * 12;
            const ly = Math.sin(a) * 12;
            ctx.fillRect(lx - 2, ly - 2, 4, 4);
          }
          ctx.fillStyle = '#F59E0B';
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case 'shredded_rubber': {
          ctx.fillStyle = '#1E293B';
          ctx.fillRect(-8, -4, 16, 10);
          ctx.fillStyle = '#475569';
          ctx.fillRect(-6, -7, 12, 6);
          ctx.fillStyle = '#F97316';
          ctx.fillRect(-2, -9, 5, 4);
          break;
        }
      }
      ctx.restore();
    }
  }

  public drawPlayer(
    player: PlayerState,
    time: number,
    comboMultiplier: number = 1,
    attackHitStreak: number = 0,
    isMultiplayer: boolean = false
  ) {
    const ctx = this.ctx;
    const skin = getSkinById(player.skinId);

    if (player.isKnockedOut) {
      ctx.save();
      const pCenterX = player.x + player.width / 2;
      const pCenterY = player.y + player.height / 2;
      const pulse = Math.sin(time * 8) * 0.2 + 0.5;
      ctx.fillStyle = `rgba(239, 68, 68, ${pulse * 0.4})`;
      ctx.beginPath();
      ctx.arc(pCenterX, pCenterY, 26, 0, Math.PI * 2);
      ctx.fill();
      if (player.reviveProgress > 0) {
        ctx.strokeStyle = '#22C55E';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(pCenterX, pCenterY, 28, -Math.PI / 2, -Math.PI / 2 + player.reviveProgress * Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    if (player.isDisconnected) {
      ctx.save();
      const pCenterX = player.x + player.width / 2;
      const pCenterY = player.y + player.height / 2;
      ctx.fillStyle = 'rgba(239, 68, 68, 0.2)';
      ctx.beginPath();
      ctx.arc(pCenterX, pCenterY, 30, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    if (player.invincibleTimer > 0 && Math.floor(player.invincibleTimer * 15) % 2 === 0) {
      return;
    }

    const isRunning = Math.abs(player.vx) > 0.5 && player.isGrounded && !player.isKnockedOut;
    const legOffset = isRunning ? Math.sin(time * 18) * 8 : 0;
    const breathe = player.isGrounded && !player.isKnockedOut ? Math.sin(time * 5) * 1.5 : 0;

    if (comboMultiplier >= 2) {
      ctx.save();
      const auraX = player.x + player.width / 2;
      const auraY = player.y + player.height / 2;
      const auraColor =
        comboMultiplier >= 5
          ? 'rgba(244, 63, 94, 0.45)'
          : comboMultiplier >= 4
          ? 'rgba(236, 72, 153, 0.4)'
          : comboMultiplier >= 3
          ? 'rgba(245, 158, 11, 0.4)'
          : 'rgba(234, 179, 8, 0.35)';
      const auraRadius = 24 + Math.sin(time * 12) * 3;
      ctx.fillStyle = auraColor;
      ctx.beginPath();
      ctx.arc(auraX, auraY, auraRadius, 0, Math.PI * 2);
      ctx.fill();

      for (let s = 0; s < 3; s++) {
        const sparkAngle = time * 8 + (s * Math.PI * 2) / 3;
        const sparkDist = auraRadius + 4;
        const sx = auraX + Math.cos(sparkAngle) * sparkDist;
        const sy = auraY + Math.sin(sparkAngle) * sparkDist;
        ctx.fillStyle = comboMultiplier >= 4 ? '#F43F5E' : '#FACC15';
        ctx.beginPath();
        ctx.arc(sx, sy, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    ctx.save();
    ctx.translate(player.x + player.width / 2, player.y + player.height / 2);
    ctx.scale(player.facing, 1);

    ctx.fillStyle = skin.capeColor;
    ctx.beginPath();
    const capeWiggle = isRunning ? Math.sin(time * 20) * 8 : Math.sin(time * 4) * 3;
    ctx.moveTo(-10, -6);
    ctx.lineTo(-24 + capeWiggle, 16);
    ctx.lineTo(-12 + capeWiggle * 0.5, 20);
    ctx.lineTo(-6, 8);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = skin.pantsColor;
    ctx.fillRect(-8 + legOffset, 14, 6, 12);
    ctx.fillRect(2 - legOffset, 14, 6, 12);

    ctx.fillStyle = skin.bootsColor;
    ctx.fillRect(-10 + legOffset, 22, 9, 5);
    ctx.fillRect(0 - legOffset, 22, 9, 5);

    ctx.fillStyle = skin.jacketColor;
    ctx.beginPath();
    ctx.roundRect(-12, -8 + breathe, 24, 24, 6);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(0, 2 + breathe, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = skin.emblemColor || '#16A34A';
    ctx.font = 'bold 7px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(skin.emblemSymbol || '🌱', 0, 2 + breathe);

    ctx.fillStyle = skin.handleColor || '#78350F';
    ctx.fillRect(-12, 10 + breathe, 24, 4);

    ctx.fillStyle = '#FCD34D';
    ctx.beginPath();
    ctx.arc(0, -18 + breathe, 12, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = skin.helmetColor;
    ctx.beginPath();
    ctx.arc(0, -22 + breathe, 13, Math.PI, 0, false);
    ctx.fill();
    ctx.fillRect(0, -23 + breathe, 14, 4);

    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    ctx.arc(4, -18 + breathe, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(5, -19 + breathe, 1, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#0F172A';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(4, -14 + breathe, 3, 0.1, Math.PI * 0.85);
    ctx.stroke();

    if (player.isAttacking || player.isSwordSlashing) {
      const animStep = player.attackComboStep === 2 ? 1 : player.attackComboStep === 3 ? 2 : 3;
      if (animStep === 1) {
        ctx.save();
        ctx.rotate(0.3);
        ctx.fillStyle = skin.jacketColor;
        ctx.fillRect(4, -4, 16, 6);
        ctx.fillStyle = skin.guardColor;
        ctx.fillRect(18, -10, 5, 18);
        ctx.fillStyle = skin.handleColor;
        ctx.fillRect(14, -3, 6, 4);
        ctx.fillStyle = skin.bladeColor;
        ctx.beginPath();
        ctx.moveTo(23, -4);
        ctx.lineTo(52, -1);
        ctx.lineTo(23, 2);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = skin.bladeCoreColor || '#FFFFFF';
        ctx.fillRect(24, -1, 24, 2);
        ctx.restore();

        ctx.save();
        ctx.strokeStyle = skin.slashColor;
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(10, 0, 36, -Math.PI * 0.45, Math.PI * 0.35, false);
        ctx.stroke();
        ctx.strokeStyle = skin.slashGlowColor || 'rgba(74, 222, 128, 0.35)';
        ctx.lineWidth = 12;
        ctx.stroke();
        ctx.restore();
      } else if (animStep === 2) {
        ctx.save();
        ctx.rotate(-0.45);
        ctx.fillStyle = skin.jacketColor;
        ctx.fillRect(4, -4, 16, 6);
        ctx.fillStyle = '#38BDF8';
        ctx.fillRect(18, -10, 5, 18);
        ctx.fillStyle = skin.handleColor;
        ctx.fillRect(14, -3, 6, 4);
        ctx.fillStyle = '#0284C7';
        ctx.beginPath();
        ctx.moveTo(23, -4);
        ctx.lineTo(56, -1);
        ctx.lineTo(23, 2);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#E0F2FE';
        ctx.fillRect(24, -1.5, 28, 3);
        ctx.restore();

        ctx.save();
        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 7;
        ctx.beginPath();
        ctx.arc(12, -2, 40, -Math.PI * 0.55, Math.PI * 0.25, false);
        ctx.stroke();
        ctx.strokeStyle = '#BAE6FD';
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(12, 4, 38, Math.PI * 0.5, -Math.PI * 0.3, true);
        ctx.stroke();
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.lineWidth = 14;
        ctx.beginPath();
        ctx.arc(12, 0, 39, -Math.PI * 0.5, Math.PI * 0.3, false);
        ctx.stroke();
        ctx.restore();
      } else {
        const spinAngle = (time * 28) % (Math.PI * 2);
        ctx.save();
        ctx.rotate(spinAngle);
        ctx.fillStyle = skin.jacketColor;
        ctx.fillRect(4, -4, 16, 6);
        ctx.fillStyle = '#FACC15';
        ctx.fillRect(18, -11, 6, 20);
        ctx.fillStyle = skin.handleColor;
        ctx.fillRect(14, -3, 6, 4);
        ctx.fillStyle = '#16A34A';
        ctx.beginPath();
        ctx.moveTo(23, -5);
        ctx.lineTo(60, -1);
        ctx.lineTo(23, 3);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#FEF08A';
        ctx.fillRect(24, -1.5, 32, 3);
        ctx.restore();

        ctx.save();
        ctx.strokeStyle = 'rgba(250, 204, 21, 0.45)';
        ctx.lineWidth = 16;
        ctx.beginPath();
        ctx.arc(0, 0, 48, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = '#4ADE80';
        ctx.lineWidth = 8;
        ctx.beginPath();
        ctx.arc(0, 0, 48, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = '#FEF08A';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, 48, 0, Math.PI * 2);
        ctx.stroke();
        for (let sp = 0; sp < 4; sp++) {
          const spAngle = spinAngle + (sp * Math.PI) / 2;
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(0, 0, 48, spAngle, spAngle + 0.35);
          ctx.stroke();
        }
        ctx.restore();
      }
    } else if (player.carriedItem) {
      ctx.fillStyle = skin.jacketColor;
      ctx.fillRect(-10, -20, 6, 16);
      ctx.fillRect(4, -20, 6, 16);
    } else {
      ctx.fillStyle = skin.jacketColor;
      ctx.fillRect(-2, -4 + breathe, 6, 14);
      ctx.save();
      ctx.translate(6, 6 + breathe);
      ctx.rotate(-0.4);
      ctx.fillStyle = skin.handleColor;
      ctx.fillRect(-4, -2, 6, 3);
      ctx.fillStyle = skin.guardColor;
      ctx.fillRect(2, -5, 3, 9);
      ctx.fillStyle = skin.bladeColor;
      ctx.beginPath();
      ctx.moveTo(5, -2);
      ctx.lineTo(30, 0);
      ctx.lineTo(5, 2);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = skin.bladeCoreColor || '#FFFFFF';
      ctx.fillRect(6, -0.5, 20, 1);
      ctx.restore();
    }
    ctx.restore();

    if (player.name) {
      ctx.save();
      const headX = player.x + player.width / 2;
      const headY = player.carriedItem ? player.y - 44 : player.y - 12 + breathe;
      ctx.font = 'bold 9px "Fredoka", sans-serif';
      const playerTag = isMultiplayer ? (player.playerIndex === 2 ? '[P2] ' : '[P1] ') : '';
      const nameText = `${playerTag}${player.name}`;
      const textMetrics = ctx.measureText(nameText);
      const tagW = Math.max(textMetrics.width + 12, 34);
      const tagH = 14;
      ctx.fillStyle = player.isKnockedOut ? 'rgba(185, 28, 28, 0.9)' : 'rgba(15, 23, 42, 0.85)';
      ctx.beginPath();
      ctx.roundRect(headX - tagW / 2, headY - tagH / 2, tagW, tagH, 5);
      ctx.fill();
      ctx.strokeStyle = player.playerIndex === 2 ? '#38BDF8' : skin.slashColor;
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = '#FFFFFF';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(nameText, headX, headY);

      if (player.isDisconnected) {
        ctx.fillStyle = '#F59E0B';
        ctx.beginPath();
        ctx.roundRect(headX - 40, headY - 20, 80, 14, 4);
        ctx.fill();
        ctx.strokeStyle = '#FEF3C7';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = '#78350F';
        ctx.font = 'bold 8px "Fredoka", sans-serif';
        ctx.fillText('⚠️ RECONECTANDO...', headX, headY - 13);
      } else if (player.isKnockedOut) {
        ctx.fillStyle = '#EF4444';
        ctx.beginPath();
        ctx.roundRect(headX - 32, headY - 18, 64, 13, 4);
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 8px "Fredoka", sans-serif';
        ctx.fillText('💀 NOCAUTEADO!', headX, headY - 12);
      }

      let rightOffset = tagW / 2 + 2;
      if (comboMultiplier >= 2) {
        const comboBadgeText = `🔥 x${comboMultiplier}`;
        ctx.font = 'bold 9px "Fredoka", sans-serif';
        const cbWidth = ctx.measureText(comboBadgeText).width + 8;
        const cbX = headX + rightOffset + cbWidth / 2;
        const cbY = headY;
        rightOffset += cbWidth + 2;
        ctx.fillStyle = comboMultiplier >= 4 ? '#E11D48' : comboMultiplier >= 3 ? '#D97706' : '#CA8A04';
        ctx.beginPath();
        ctx.roundRect(cbX - cbWidth / 2, cbY - tagH / 2, cbWidth, tagH, 5);
        ctx.fill();
        ctx.strokeStyle = '#FEF08A';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(comboBadgeText, cbX, cbY);
      }

      if (attackHitStreak >= 2) {
        const streakBadgeText = `⚡ ${attackHitStreak} HITS!`;
        ctx.font = 'bold 9px "Fredoka", sans-serif';
        const sbWidth = ctx.measureText(streakBadgeText).width + 8;
        const sbX = headX - tagW / 2 - sbWidth / 2 - 2;
        const sbY = headY;
        ctx.fillStyle =
          attackHitStreak >= 8
            ? '#A855F7'
            : attackHitStreak >= 5
            ? '#E11D48'
            : '#EA580C';
        ctx.beginPath();
        ctx.roundRect(sbX - sbWidth / 2, sbY - tagH / 2, sbWidth, tagH, 5);
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(streakBadgeText, sbX, sbY);
      }
      ctx.restore();
    }

    if (player.carriedItem) {
      const carried = player.carriedItem;
      const carriedX = player.x + player.width / 2 - 12;
      const carriedY = player.y - 28 + Math.sin(time * 6) * 3;
      ctx.save();
      ctx.translate(carriedX, carriedY);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.beginPath();
      ctx.arc(12, 12, 16, 0, Math.PI * 2);
      ctx.fill();
      const info = TRASH_CATEGORY_INFO[carried.category];
      ctx.font = '20px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(info.iconSymbol, 12, 12);
      ctx.font = 'bold 10px "Fredoka", sans-serif';
      ctx.fillStyle = info.binColorHex;
      ctx.textAlign = 'center';
      ctx.fillText(carried.name, 12, -4);
      ctx.restore();
    }
  }

  public drawEnemies(enemies: Enemy[], time: number) {
    const ctx = this.ctx;
    for (const enemy of enemies) {
      if (enemy.state === 'defeated') {
        if (enemy.defeatTimer <= 0) continue;
        const shrink = Math.max(0, enemy.defeatTimer / 0.5);
        ctx.save();
        ctx.translate(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2);
        ctx.scale(shrink, shrink);
        ctx.rotate(time * 12);
        ctx.fillStyle = '#4ADE80';
        ctx.beginPath();
        ctx.arc(0, 0, enemy.width * 0.6, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
        continue;
      }

      ctx.save();
      ctx.translate(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2);
      ctx.scale(enemy.facing, 1);

      if (enemy.hurtTimer > 0 && Math.floor(time * 30) % 2 === 0) {
        ctx.globalAlpha = 0.6;
      }

      switch (enemy.type) {
        case 'pneu_saltitante':
          this.drawPneuSaltitante(enemy, time);
          break;
        case 'pneu_espinhoso':
          this.drawPneuEspinhoso(enemy, time);
          break;
        case 'pneu_chamas':
          this.drawPneuChamas(enemy, time);
          break;
        case 'pneu_trator_monstro':
          this.drawPneuTratorMonstro(enemy, time);
          break;
        case 'super_pneu':
          this.drawSuperPneuBoss(enemy, time);
          break;
      }

      if (enemy.hurtTimer > 0) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.beginPath();
        ctx.arc(0, 0, enemy.width * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      if (!enemy.isBoss) {
        const barW = 36;
        const barH = 5;
        const barX = enemy.x + (enemy.width - barW) / 2;
        const barY = enemy.y - 12;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(barX, barY, barW, barH);
        const hpRatio = Math.max(0, enemy.hp / enemy.maxHp);
        ctx.fillStyle = hpRatio > 0.5 ? '#EF4444' : '#F97316';
        ctx.fillRect(barX, barY, barW * hpRatio, barH);
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 1;
        ctx.strokeRect(barX, barY, barW, barH);
      }
    }
  }

  private drawPneuSaltitante(enemy: Enemy, time: number) {
    const ctx = this.ctx;
    const rot = (enemy.rotation || 0) + time * 6 * enemy.facing;
    const isJumping = Math.abs(enemy.vy) > 0.5;
    const squashY = enemy.isGrounded ? 0.88 : isJumping ? 1.15 : 1.0;
    const squashX = 1 / squashY;

    ctx.save();
    ctx.scale(squashX, squashY);
    ctx.rotate(rot);

    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    ctx.arc(0, 0, 18, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#334155';
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4;
      ctx.fillRect(Math.cos(a) * 15 - 2, Math.sin(a) * 15 - 2, 4, 4);
    }

    ctx.fillStyle = '#DC2626';
    ctx.beginPath();
    ctx.arc(0, 0, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.fillStyle = '#FEF08A';
    ctx.beginPath();
    ctx.arc(4, -4, 3.5, 0, Math.PI * 2);
    ctx.arc(10, -4, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#DC2626';
    ctx.beginPath();
    ctx.arc(5, -4, 1.5, 0, Math.PI * 2);
    ctx.arc(11, -4, 1.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 4);
    ctx.lineTo(4, 7);
    ctx.lineTo(8, 4);
    ctx.lineTo(12, 7);
    ctx.stroke();
  }

  private drawPneuEspinhoso(enemy: Enemy, time: number) {
    const ctx = this.ctx;
    const rot = time * 8 * enemy.facing;
    ctx.save();
    ctx.rotate(rot);

    ctx.fillStyle = '#E2E8F0';
    for (let i = 0; i < 10; i++) {
      const a = (i * Math.PI * 2) / 10;
      const x1 = Math.cos(a) * 16;
      const y1 = Math.sin(a) * 16;
      const x2 = Math.cos(a) * 23;
      const y2 = Math.sin(a) * 23;
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#E2E8F0';
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    ctx.fillStyle = '#1E293B';
    ctx.beginPath();
    ctx.arc(0, 0, 18, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#64748B';
    ctx.beginPath();
    ctx.arc(0, 0, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.fillStyle = '#EF4444';
    ctx.fillRect(2, -5, 12, 4);
  }

  private drawPneuChamas(enemy: Enemy, time: number) {
    const ctx = this.ctx;
    ctx.fillStyle = 'rgba(249, 115, 22, 0.28)';
    ctx.beginPath();
    ctx.arc(0, 0, 30, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(239, 68, 68, 0.45)';
    ctx.beginPath();
    ctx.arc(0, 0, 24, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    ctx.arc(0, 0, 20, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#F59E0B';
    for (let f = -12; f <= 12; f += 8) {
      const fh = 8 + Math.sin(time * 12 + f) * 5;
      ctx.beginPath();
      ctx.moveTo(f - 4, -14);
      ctx.lineTo(f, -14 - fh);
      ctx.lineTo(f + 4, -14);
      ctx.fill();
    }

    ctx.fillStyle = '#FEF08A';
    ctx.beginPath();
    ctx.arc(6, -2, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#DC2626';
    ctx.beginPath();
    ctx.arc(7, -2, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawPneuTratorMonstro(enemy: Enemy, time: number) {
    const ctx = this.ctx;
    const rot = time * 4 * enemy.facing;
    ctx.save();
    ctx.rotate(rot);

    ctx.fillStyle = '#F59E0B';
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI * 2) / 8;
      const tx = Math.cos(a) * 22;
      const ty = Math.sin(a) * 22;
      ctx.fillRect(tx - 3, ty - 3, 6, 6);
    }

    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    ctx.arc(0, 0, 24, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#475569';
    ctx.beginPath();
    ctx.arc(0, 0, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.fillStyle = '#DC2626';
    ctx.beginPath();
    ctx.arc(6, -2, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FEF08A';
    ctx.beginPath();
    ctx.arc(7, -2, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawSuperPneuBoss(boss: Enemy, time: number) {
    const ctx = this.ctx;
    const breathe = Math.sin(time * 5) * 3;
    const rot = time * 3 * boss.facing;

    ctx.fillStyle = 'rgba(249, 115, 22, 0.22)';
    ctx.beginPath();
    ctx.arc(0, breathe, 62, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(239, 68, 68, 0.4)';
    ctx.beginPath();
    ctx.arc(0, breathe, 50, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#020617';
    ctx.beginPath();
    ctx.arc(0, breathe, 46, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#B91C1C';
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.save();
    ctx.translate(0, breathe);
    ctx.rotate(rot);
    ctx.fillStyle = '#EF4444';
    for (let i = 0; i < 12; i++) {
      const a = (i * Math.PI * 2) / 12;
      const lx = Math.cos(a) * 42;
      const ly = Math.sin(a) * 42;
      ctx.fillRect(lx - 4, ly - 4, 8, 8);
    }
    ctx.restore();

    ctx.fillStyle = '#450A0A';
    ctx.beginPath();
    ctx.arc(0, breathe, 28, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#F59E0B';
    for (let cx = -24; cx <= 24; cx += 12) {
      const flameH = 14 + Math.sin(time * 16 + cx) * 8;
      ctx.beginPath();
      ctx.moveTo(cx - 5, -42 + breathe);
      ctx.lineTo(cx, -42 - flameH + breathe);
      ctx.lineTo(cx + 5, -42 + breathe);
      ctx.fill();
    }

    ctx.fillStyle = '#FACC15';
    ctx.beginPath();
    ctx.arc(-8, -8 + breathe, 6, 0, Math.PI * 2);
    ctx.arc(12, -8 + breathe, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#DC2626';
    ctx.beginPath();
    ctx.arc(-7, -8 + breathe, 3, 0, Math.PI * 2);
    ctx.arc(13, -8 + breathe, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#FEF2F2';
    for (let t = -16; t <= 16; t += 8) {
      ctx.beginPath();
      ctx.moveTo(t, 6 + breathe);
      ctx.lineTo(t + 4, 12 + breathe);
      ctx.lineTo(t + 8, 6 + breathe);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(t, 20 + breathe);
      ctx.lineTo(t + 4, 14 + breathe);
      ctx.lineTo(t + 8, 20 + breathe);
      ctx.fill();
    }
  }

  public drawProjectiles(projectiles: Projectile[], time: number) {
    const ctx = this.ctx;
    for (const p of projectiles) {
      if (p.isFriendly) {
        ctx.save();
        ctx.translate(p.x, p.y);
        if (p.projectileType === 'eco_blast_cross') {
          ctx.rotate(time * 16);
          ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius * 1.7, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#0284C7';
          ctx.beginPath();
          ctx.moveTo(-p.radius * 1.4, 0);
          ctx.lineTo(0, -p.radius * 0.7);
          ctx.lineTo(p.radius * 1.4, 0);
          ctx.lineTo(0, p.radius * 0.7);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#E0F2FE';
          ctx.beginPath();
          ctx.moveTo(0, -p.radius * 1.4);
          ctx.lineTo(p.radius * 0.7, 0);
          ctx.lineTo(0, p.radius * 1.4);
          ctx.lineTo(-p.radius * 0.7, 0);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath();
          ctx.arc(0, 0, 3, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.projectileType === 'eco_blast_finisher') {
          ctx.rotate(time * 8);
          ctx.fillStyle = 'rgba(250, 204, 21, 0.45)';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius * 1.9, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#EAB308';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius * 1.2, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#22C55E';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius * 0.75, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FEF08A';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius * 0.4, 0, Math.PI * 2);
          ctx.fill();
          for (let i = 0; i < 4; i++) {
            const angle = time * 18 + (i * Math.PI) / 2;
            const lx = Math.cos(angle) * (p.radius + 4);
            const ly = Math.sin(angle) * (p.radius + 4);
            ctx.fillStyle = '#FEF08A';
            ctx.beginPath();
            ctx.arc(lx, ly, 3, 0, Math.PI * 2);
            ctx.fill();
          }
        } else {
          ctx.fillStyle = 'rgba(34, 197, 94, 0.3)';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius * 1.8, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#22C55E';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath();
          ctx.arc(0, 0, p.radius * 0.6, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#4ADE80';
          for (let i = 0; i < 3; i++) {
            const angle = time * 14 + (i * Math.PI * 2) / 3;
            const lx = Math.cos(angle) * (p.radius + 3);
            const ly = Math.sin(angle) * (p.radius + 3);
            ctx.beginPath();
            ctx.arc(lx, ly, 3, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
      } else if (p.projectileType === 'rolling_tire') {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(time * 14);
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#EF4444';
        ctx.beginPath();
        ctx.arc(0, 0, p.radius * 0.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (p.projectileType === 'fire_blast') {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.fillStyle = 'rgba(249, 115, 22, 0.35)';
        ctx.beginPath();
        ctx.arc(0, 0, p.radius * 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#EF4444';
        ctx.beginPath();
        ctx.arc(0, 0, p.radius * 1.1, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#FEF08A';
        ctx.beginPath();
        ctx.arc(0, 0, p.radius * 0.55, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (p.projectileType === 'flying_car') {
        ctx.save();
        ctx.translate(p.x, p.y);
        const rot = p.rotation || time * 5;
        ctx.rotate(rot);
        ctx.fillStyle = '#DC2626';
        ctx.beginPath();
        ctx.roundRect(-22, -10, 44, 20, [4, 4, 2, 2]);
        ctx.fill();
        ctx.fillStyle = '#B91C1C';
        ctx.beginPath();
        ctx.roundRect(-12, -18, 24, 12, [4, 4, 0, 0]);
        ctx.fill();
        ctx.fillStyle = '#BAE6FD';
        ctx.fillRect(-8, -16, 16, 8);
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        ctx.arc(-14, 10, 6, 0, Math.PI * 2);
        ctx.arc(14, 10, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#F59E0B';
        ctx.beginPath();
        ctx.arc(-26, 0, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.fillStyle = p.color || '#EF4444';
        ctx.beginPath();
        ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }
  }

  public drawParticles(particles: Particle[]) {
    const ctx = this.ctx;
    for (const p of particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.fillStyle = p.color;
      if (p.shape === 'leaf') {
        ctx.translate(p.x, p.y);
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size * 0.5, p.vx * 0.2, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.shape === 'fire') {
        ctx.translate(p.x, p.y);
        ctx.beginPath();
        ctx.arc(0, 0, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  public drawFloatingTexts(texts: FloatingText[]) {
    if (texts.length === 0) return;
    const ctx = this.ctx;
    ctx.font = 'bold 15px "Fredoka", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const t of texts) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, t.alpha);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
      ctx.fillText(t.text, t.x + 1, t.y + 1);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
      ctx.restore();
    }
  }
}
