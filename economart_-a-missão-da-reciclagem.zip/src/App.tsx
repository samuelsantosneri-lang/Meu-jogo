/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/engine';
import { CanvasRenderer } from './game/canvasRenderer';
import { soundManager } from './game/audio';
import { TitleScreen } from './components/TitleScreen';
import { HowToPlayModal } from './components/HowToPlayModal';
import { CreditsModal } from './components/CreditsModal';
import { GameHUD } from './components/GameHUD';
import { TouchControls } from './components/TouchControls';
import { LevelTransitionModal } from './components/LevelTransitionModal';
import { GameOverModal } from './components/GameOverModal';
import { VictoryModal } from './components/VictoryModal';
import { PauseModal } from './components/PauseModal';
import { MultiplayerModal } from './components/MultiplayerModal';
import { networkManager, NetworkRoomState } from './game/network';
import { GameView } from './game/types';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const rendererRef = useRef<CanvasRenderer | null>(null);
  const requestRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);
  const lastSyncTimeRef = useRef<number>(0);

  // React state synchronized with engine
  const [view, setView] = useState<GameView>('TITLE');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [highScore, setHighScore] = useState<number>(0);
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);
  const [showCredits, setShowCredits] = useState<boolean>(false);
  const [showMultiplayerModal, setShowMultiplayerModal] = useState<boolean>(false);
  const [isTouchDevice, setIsTouchDevice] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'reconnecting' | 'disconnected'>('connected');
  const [, setTick] = useState<number>(0);

  // Initialize engine once
  if (!engineRef.current) {
    engineRef.current = new GameEngine();
  }
  const engine = engineRef.current;

  const [playerName, setPlayerName] = useState<string>(engine.playerName);
  const [selectedSkinId, setSelectedSkinId] = useState<string>(engine.playerSkinId);

  // Sync high score & state changes on mount
  useEffect(() => {
    setHighScore(engine.stats.highScore);
    const touchCheck = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    setIsTouchDevice(touchCheck);

    engine.setOnStateChange(() => {
      setView(engine.view);
      setHighScore(engine.stats.highScore);
      setTick((t) => t + 1);
    });
  }, [engine]);

  // Network Multi-user Event Listeners for real-time Co-op
  useEffect(() => {
    const handleRemoteSync = (data: any) => {
      if (engine.gameMode !== 'online_coop') return;
      if (!engine.player2) {
        engine.player2 = engine.createDefaultPlayer(2, 'Parceiro', 'eco_classic', data.x || 140);
      }
      const p2 = engine.player2;
      p2.x = data.x;
      p2.y = data.y;
      p2.vx = data.vx;
      p2.vy = data.vy;
      p2.facing = data.facing;
      p2.hp = data.hp;
      p2.isAttacking = data.isAttacking;
      p2.attackComboStep = data.comboStep || 1;
      p2.isKnockedOut = data.isKnockedOut;
      p2.isDisconnected = false;
    };

    const handleRemoteAttack = (data: any) => {
      if (engine.gameMode !== 'online_coop' || !engine.player2) return;
      engine.player2.facing = data.facing;
      engine.player2.isAttacking = true;
      engine.player2.attackAnimTimer = 0.2;
      soundManager.playSwordSlashCombo(data.comboStep || 1);
    };

    const handleRemoteRecycle = (data: any) => {
      if (engine.gameMode !== 'online_coop') return;
      soundManager.playRecycleSuccess();
      engine.addFloatingText(
        500,
        200,
        `♻️ ${data.playerName || 'Parceiro'} Reciclou Pneu! (x${data.comboMultiplier || 1})`,
        '#22C55E',
        1.3
      );
    };

    const handleTempDisconnect = (data: any) => {
      if (engine.gameMode !== 'online_coop') return;
      if (engine.player2) {
        engine.player2.isDisconnected = true;
      }
      soundManager.playRecycleError();
      engine.addFloatingText(
        500,
        150,
        `⚠️ ${data.playerName} desconectou inesperadamente! Aguardando reconexão...`,
        '#F59E0B',
        1.5
      );
    };

    const handlePlayerReconnected = (data: any) => {
      if (engine.gameMode !== 'online_coop') return;
      if (engine.player2) {
        engine.player2.isDisconnected = false;
      }
      soundManager.playLevelComplete();
      engine.addFloatingText(
        500,
        150,
        `✨ ${data.playerName} se reconectou à partida!`,
        '#22C55E',
        1.5
      );
    };

    const handlePlayerLeft = (data: any) => {
      if (engine.gameMode !== 'online_coop') return;
      if (engine.player2) {
        engine.player2 = null;
      }
      engine.addFloatingText(
        500,
        150,
        data.reason === 'timeout'
          ? `⏰ Tempo esgotado: ${data.playerName} não retornou.`
          : `👋 ${data.playerName} saiu da sala.`,
        '#EF4444',
        1.4
      );
    };

    const handleConnState = (state: string) => {
      if (state === 'reconnecting') setConnectionStatus('reconnecting');
      else if (state === 'connected') setConnectionStatus('connected');
      else setConnectionStatus('disconnected');
    };

    networkManager.on('remote_player_sync', handleRemoteSync);
    networkManager.on('remote_player_attack', handleRemoteAttack);
    networkManager.on('remote_recycle_event', handleRemoteRecycle);
    networkManager.on('player_disconnected_temporary', handleTempDisconnect);
    networkManager.on('player_reconnected', handlePlayerReconnected);
    networkManager.on('player_left', handlePlayerLeft);
    networkManager.on('connection_state_changed', handleConnState);

    return () => {
      networkManager.off('remote_player_sync', handleRemoteSync);
      networkManager.off('remote_player_attack', handleRemoteAttack);
      networkManager.off('remote_recycle_event', handleRemoteRecycle);
      networkManager.off('player_disconnected_temporary', handleTempDisconnect);
      networkManager.off('player_reconnected', handlePlayerReconnected);
      networkManager.off('player_left', handlePlayerLeft);
      networkManager.off('connection_state_changed', handleConnState);
    };
  }, [engine]);

  // Main Canvas Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (!rendererRef.current) {
      rendererRef.current = new CanvasRenderer(ctx, engine.canvasWidth, engine.canvasHeight);
    }
    const renderer = rendererRef.current;

    const gameLoop = (timestamp: number) => {
      if (!lastTimeRef.current) {
        lastTimeRef.current = timestamp;
      }
      const dt = Math.min((timestamp - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = timestamp;

      // Update engine
      if (engine.view === 'PLAYING') {
        engine.update(dt);

        // Network synchronization broadcast (15 times per second)
        if (engine.gameMode === 'online_coop') {
          if (timestamp - lastSyncTimeRef.current > 66) {
            lastSyncTimeRef.current = timestamp;
            networkManager.syncPlayer({
              x: engine.player.x,
              y: engine.player.y,
              vx: engine.player.vx,
              vy: engine.player.vy,
              facing: engine.player.facing,
              hp: engine.player.hp,
              carriedCategory: engine.player.carriedItem ? engine.player.carriedItem.category : null,
              isAttacking: engine.player.isAttacking,
              comboStep: engine.player.attackComboStep,
              isKnockedOut: engine.player.isKnockedOut,
            });
          }
        }
      }

      // Draw frame
      ctx.save();

      // Screen shake
      if (engine.screenShake > 0) {
        const shakeX = (Math.random() - 0.5) * engine.screenShake;
        const shakeY = (Math.random() - 0.5) * engine.screenShake;
        ctx.translate(shakeX, shakeY);
      }

      renderer.clear();
      const cleanlinessRatio = engine.getCleanlinessRatio();
      renderer.drawBackground(engine.currentLevelConfig.backgroundTheme, cleanlinessRatio, engine.time);
      renderer.drawPlatforms(engine.platforms, cleanlinessRatio);
      renderer.drawRecycleBins(
        engine.recycleBins,
        engine.player.carriedItem ? engine.player.carriedItem.category : null,
        engine.time
      );
      renderer.drawTrashItems(engine.trashItems, engine.time);

      // Draw Player 1
      renderer.drawPlayer(
        engine.player,
        engine.time,
        engine.stats.comboMultiplier,
        engine.stats.attackHitStreak,
        engine.gameMode !== 'single'
      );

      // Draw Player 2 in Co-op
      if (engine.player2) {
        renderer.drawPlayer(
          engine.player2,
          engine.time,
          1,
          0,
          true
        );
      }

      renderer.drawEnemies(engine.enemies, engine.time);
      renderer.drawProjectiles(engine.projectiles, engine.time);
      renderer.drawParticles(engine.particles);
      renderer.drawFloatingTexts(engine.floatingTexts);

      ctx.restore();

      requestRef.current = requestAnimationFrame(gameLoop);
    };

    requestRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [engine]);

  // Keyboard and Input Event Handlers
  const activeKeyboardKeysRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      activeKeyboardKeysRef.current.add(e.key.toLowerCase());
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') {
        engine.keys.left = true;
      }
      if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') {
        engine.keys.right = true;
      }
      if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') {
        engine.keys.jump = true;
      }

      // Sword attack: SPACE, Z or C
      if (e.key === ' ' || e.key === 'z' || e.key === 'Z' || e.key === 'c' || e.key === 'C') {
        engine.keys.attack = true;
        if (engine.gameMode === 'online_coop') {
          networkManager.sendAttack({
            x: engine.player.x,
            y: engine.player.y,
            facing: engine.player.facing,
            comboStep: engine.player.attackComboStep,
          });
        }
      }

      // Key X to deposit tire in trash!
      if (e.key === 'x' || e.key === 'X') {
        engine.triggerDepositWithX();
        if (engine.gameMode === 'online_coop' && engine.player.carriedItem) {
          networkManager.sendRecycle(
            engine.player.carriedItem.category,
            engine.stats.comboMultiplier
          );
        }
      }

      if (e.key === 'e' || e.key === 'E' || e.key === 'Enter') {
        engine.keys.interact = true;
      }

      if (e.key === 'Escape' && (engine.view === 'PLAYING' || engine.view === 'PAUSED')) {
        if (engine.view === 'PLAYING') {
          engine.view = 'PAUSED';
          soundManager.stopBGM();
        } else {
          engine.view = 'PLAYING';
          soundManager.startBGM();
        }
        setView(engine.view);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      activeKeyboardKeysRef.current.delete(e.key.toLowerCase());
      if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') {
        engine.keys.left = false;
      }
      if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') {
        engine.keys.right = false;
      }
      if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') {
        engine.keys.jump = false;
      }
      if (e.key === ' ' || e.key === 'z' || e.key === 'Z' || e.key === 'c' || e.key === 'C') {
        engine.keys.attack = false;
      }
      if (e.key === 'e' || e.key === 'E' || e.key === 'Enter') {
        engine.keys.interact = false;
      }
    };

    const handleGlobalRelease = () => {
      const keys = activeKeyboardKeysRef.current;
      if (!keys.has('a') && !keys.has('arrowleft')) {
        engine.keys.left = false;
      }
      if (!keys.has('d') && !keys.has('arrowright')) {
        engine.keys.right = false;
      }
      if (!keys.has('w') && !keys.has('arrowup')) {
        engine.keys.jump = false;
      }
      if (!keys.has(' ') && !keys.has('z') && !keys.has('c')) {
        engine.keys.attack = false;
      }
    };

    const handleBlur = () => {
      activeKeyboardKeysRef.current.clear();
      engine.keys.left = false;
      engine.keys.right = false;
      engine.keys.jump = false;
      engine.keys.attack = false;
      engine.keys.interact = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('pointerup', handleGlobalRelease);
    window.addEventListener('pointercancel', handleGlobalRelease);
    window.addEventListener('touchend', handleGlobalRelease);
    window.addEventListener('touchcancel', handleGlobalRelease);
    window.addEventListener('mouseup', handleGlobalRelease);
    window.addEventListener('blur', handleBlur);
    document.addEventListener('visibilitychange', handleBlur);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('pointerup', handleGlobalRelease);
      window.removeEventListener('pointercancel', handleGlobalRelease);
      window.removeEventListener('touchend', handleGlobalRelease);
      window.removeEventListener('touchcancel', handleGlobalRelease);
      window.removeEventListener('mouseup', handleGlobalRelease);
      window.removeEventListener('blur', handleBlur);
      document.removeEventListener('visibilitychange', handleBlur);
    };
  }, [engine]);

  // Touch control callbacks
  const handleTouchLeft = useCallback((active: boolean) => {
    engine.keys.left = active;
  }, [engine]);

  const handleTouchRight = useCallback((active: boolean) => {
    engine.keys.right = active;
  }, [engine]);

  const handleTouchJump = useCallback((active: boolean) => {
    engine.keys.jump = active;
  }, [engine]);

  const handleTouchAttack = useCallback((active: boolean) => {
    engine.keys.attack = active;
    if (active && engine.gameMode === 'online_coop') {
      networkManager.sendAttack({
        x: engine.player.x,
        y: engine.player.y,
        facing: engine.player.facing,
        comboStep: engine.player.attackComboStep,
      });
    }
  }, [engine]);

  const handleToggleMute = useCallback(() => {
    const nextMuted = soundManager.toggleMute();
    setIsMuted(nextMuted);
  }, []);

  const handleUpdateCustomization = useCallback(
    (name: string, skinId: string) => {
      engine.setPlayerCustomization(name, skinId);
      setPlayerName(name);
      setSelectedSkinId(skinId);
      if (networkManager.currentRoomId) {
        networkManager.updateProfile(name, skinId);
      }
    },
    [engine]
  );

  const handleStartGame = useCallback(() => {
    engine.setGameMode('single');
    engine.resetGame();
    setView('PLAYING');
  }, [engine]);

  const handleStartCoopGame = useCallback(
    (roomState: NetworkRoomState) => {
      setShowMultiplayerModal(false);
      const other = roomState.players.find((p) => p.id !== networkManager.playerId);
      const p2Name = other ? other.name : 'Eco-Amigo';
      const p2Skin = other ? other.skinId : 'eco_classic';

      engine.setGameMode('online_coop', p2Name, p2Skin);
      engine.resetGame();
      setView('PLAYING');
    },
    [engine]
  );

  const handlePause = useCallback(() => {
    engine.view = 'PAUSED';
    soundManager.stopBGM();
    setView('PAUSED');
  }, [engine]);

  const handleResume = useCallback(() => {
    engine.view = 'PLAYING';
    soundManager.startBGM();
    setView('PLAYING');
  }, [engine]);

  const handleRestartLevel = useCallback(() => {
    engine.retryCurrentLevel();
    setView('PLAYING');
  }, [engine]);

  const handleMainMenu = useCallback(() => {
    if (engine.gameMode === 'online_coop') {
      networkManager.leaveRoom();
    }
    soundManager.stopBGM();
    engine.view = 'TITLE';
    setView('TITLE');
  }, [engine]);

  const handleNextLevel = useCallback(() => {
    engine.nextLevel();
    if (engine.gameMode === 'online_coop' && networkManager.isHost) {
      networkManager.sendNextLevel(engine.currentLevelConfig.id);
    }
    setView(engine.view);
  }, [engine]);

  const handleCanvasClick = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const scaleX = engine.canvasWidth / rect.width;
      const scaleY = engine.canvasHeight / rect.height;
      const cx = (e.clientX - rect.left) * scaleX;
      const cy = (e.clientY - rect.top) * scaleY;
      engine.handleCanvasClick(cx, cy);
    },
    [engine]
  );

  const handleBinClick = useCallback(
    (bin: import('./game/types').RecycleBin) => {
      const carried = engine.player.carriedItem;
      engine.handleRecycleBinClick(bin);
      if (engine.gameMode === 'online_coop' && carried && carried.category === bin.category) {
        networkManager.sendRecycle(bin.category, engine.stats.comboMultiplier);
      }
    },
    [engine]
  );

  return (
    <div className="relative w-screen h-screen bg-slate-950 flex items-center justify-center overflow-hidden font-['Fredoka']">
      {/* 2D Canvas Container with fixed aspect ratio 1000:600 scaling */}
      <div className="relative w-full h-full max-w-[1200px] max-h-[720px] aspect-[1000/600] flex items-center justify-center bg-slate-900 shadow-2xl overflow-hidden rounded-none sm:rounded-2xl border-0 sm:border-2 border-slate-800">
        <canvas
          ref={canvasRef}
          width={engine.canvasWidth}
          height={engine.canvasHeight}
          onClick={handleCanvasClick}
          className={`w-full h-full object-contain block ${
            engine.player.carriedItem ? 'cursor-pointer' : 'cursor-default'
          }`}
        />

        {/* In-Game HUD */}
        {(view === 'PLAYING' || view === 'PAUSED') && (
          <GameHUD
            stats={engine.stats}
            player={engine.player}
            player2={engine.player2}
            activeEnemies={engine.enemies}
            recycleBins={engine.recycleBins}
            levelTitle={engine.currentLevelConfig.title}
            totalTrashInLevel={engine.totalTrashInLevel}
            levelRecycledCount={engine.levelRecycledCount}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onPause={handlePause}
            onBinClick={handleBinClick}
            isOnlineCoop={engine.gameMode === 'online_coop'}
            connectionStatus={connectionStatus}
          />
        )}

        {/* Touch Controls for mobile/tablets */}
        {(view === 'PLAYING' || view === 'PAUSED') && isTouchDevice && (
          <TouchControls
            onPressLeft={handleTouchLeft}
            onPressRight={handleTouchRight}
            onPressJump={handleTouchJump}
            onPressAttack={handleTouchAttack}
            onPressDepositX={() => engine.triggerDepositWithX()}
            hasCarriedItem={!!engine.player.carriedItem}
            attackCharges={engine.player.attackCharges}
            comboStep={engine.player.attackComboStep}
          />
        )}

        {/* Title Screen Overlay */}
        {view === 'TITLE' && (
          <div className="absolute inset-0 z-30">
            <TitleScreen
              playerName={playerName}
              selectedSkinId={selectedSkinId}
              onUpdateCustomization={handleUpdateCustomization}
              onStartGame={handleStartGame}
              onOpenMultiplayer={() => setShowMultiplayerModal(true)}
              onOpenHowToPlay={() => setShowHowToPlay(true)}
              onOpenCredits={() => setShowCredits(true)}
              highScore={highScore}
              isMuted={isMuted}
              onToggleMute={handleToggleMute}
            />
          </div>
        )}

        {/* Multiplayer Co-op Modal */}
        {showMultiplayerModal && (
          <MultiplayerModal
            playerName={playerName}
            selectedSkinId={selectedSkinId}
            onClose={() => setShowMultiplayerModal(false)}
            onStartCoopGame={handleStartCoopGame}
          />
        )}

        {/* How To Play Modal */}
        {showHowToPlay && (
          <HowToPlayModal onClose={() => setShowHowToPlay(false)} />
        )}

        {/* Credits Modal */}
        {showCredits && (
          <CreditsModal onClose={() => setShowCredits(false)} />
        )}

        {/* Pause Modal */}
        {view === 'PAUSED' && (
          <PauseModal
            onResume={handleResume}
            onRestart={handleRestartLevel}
            onMainMenu={handleMainMenu}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
          />
        )}

        {/* Level Transition Modal */}
        {view === 'LEVEL_CLEARED' && (
          <LevelTransitionModal
            levelConfig={engine.currentLevelConfig}
            score={engine.stats.score}
            trashRecycled={engine.stats.trashRecycled}
            maxCombo={engine.stats.maxCombo}
            maxAttackHitStreak={engine.stats.maxAttackHitStreak}
            playerName={engine.player.name}
            onNextLevel={handleNextLevel}
          />
        )}

        {/* Game Over Modal */}
        {view === 'GAME_OVER' && (
          <GameOverModal
            score={engine.stats.score}
            trashRecycled={engine.stats.trashRecycled}
            maxCombo={engine.stats.maxCombo}
            playerName={engine.player.name}
            onRetry={handleRestartLevel}
            onMainMenu={handleMainMenu}
          />
        )}

        {/* Victory Modal */}
        {view === 'VICTORY' && (
          <VictoryModal
            score={engine.stats.score}
            trashRecycled={engine.stats.trashRecycled}
            monstersDefeated={engine.stats.monstersDefeated}
            maxCombo={engine.stats.maxCombo}
            comboBonusScore={engine.stats.comboBonusScore}
            maxAttackHitStreak={engine.stats.maxAttackHitStreak}
            playerName={engine.player.name}
            onPlayAgain={handleStartGame}
          />
        )}
      </div>
    </div>
  );
}
