import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface RoomPlayer {
  id: string;
  sessionToken: string;
  name: string;
  skinId: string;
  isHost: boolean;
  isReady: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: number;
  hp: number;
  maxHp: number;
  carriedCategory: string | null;
  isAttacking: boolean;
  comboStep: number;
  isKnockedOut: boolean;
  isDisconnected: boolean;
  disconnectedAt: number | null;
  disconnectTimeout?: NodeJS.Timeout;
  ws: WebSocket | null;
}

interface Room {
  id: string;
  hostId: string;
  gameState: 'lobby' | 'playing';
  levelIndex: number;
  players: Map<string, RoomPlayer>;
  cleanupTimeout?: NodeJS.Timeout;
}

// Map of active rooms by room ID
const rooms = new Map<string, Room>();

// Grace period in milliseconds before an unexpectedly disconnected player is dropped
const DISCONNECT_GRACE_PERIOD_MS = 25000;

function safeSend(ws: WebSocket | null | undefined, data: Record<string, unknown>): boolean {
  if (!ws || ws.readyState !== WebSocket.OPEN) return false;
  try {
    ws.send(JSON.stringify(data));
    return true;
  } catch (err) {
    console.error('[WS] Failed to send message:', err);
    return false;
  }
}

function getPublicRoomState(room: Room) {
  const playerList: Array<{
    id: string;
    name: string;
    skinId: string;
    isHost: boolean;
    isReady: boolean;
    x: number;
    y: number;
    vx: number;
    vy: number;
    facing: number;
    hp: number;
    maxHp: number;
    carriedCategory: string | null;
    isAttacking: boolean;
    comboStep: number;
    isKnockedOut: boolean;
    isDisconnected: boolean;
  }> = [];

  for (const p of room.players.values()) {
    playerList.push({
      id: p.id,
      name: p.name,
      skinId: p.skinId,
      isHost: p.isHost,
      isReady: p.isReady,
      x: p.x,
      y: p.y,
      vx: p.vx,
      vy: p.vy,
      facing: p.facing,
      hp: p.hp,
      maxHp: p.maxHp,
      carriedCategory: p.carriedCategory,
      isAttacking: p.isAttacking,
      comboStep: p.comboStep,
      isKnockedOut: p.isKnockedOut,
      isDisconnected: p.isDisconnected,
    });
  }

  return {
    roomId: room.id,
    hostId: room.hostId,
    gameState: room.gameState,
    levelIndex: room.levelIndex,
    players: playerList,
  };
}

function broadcastToRoom(room: Room, message: Record<string, unknown>, excludeWs?: WebSocket | null) {
  for (const player of room.players.values()) {
    if (player.ws && player.ws !== excludeWs && player.ws.readyState === WebSocket.OPEN) {
      safeSend(player.ws, message);
    }
  }
}

function handlePlayerUnexpectedDisconnect(room: Room, playerId: string) {
  const player = room.players.get(playerId);
  if (!player) return;

  player.isDisconnected = true;
  player.disconnectedAt = Date.now();
  player.ws = null;

  console.log(`[Room ${room.id}] Player ${player.name} (${playerId}) disconnected unexpectedly. Starting grace period (${DISCONNECT_GRACE_PERIOD_MS / 1000}s).`);

  // Notify other players in the room about the unexpected disconnect
  broadcastToRoom(room, {
    type: 'player_disconnected_temporary',
    playerId,
    playerName: player.name,
    gracePeriodMs: DISCONNECT_GRACE_PERIOD_MS,
    roomState: getPublicRoomState(room),
  });

  // Clear any existing timeout for this player
  if (player.disconnectTimeout) {
    clearTimeout(player.disconnectTimeout);
  }

  // Set timeout to purge player if they do not reconnect within the grace period
  player.disconnectTimeout = setTimeout(() => {
    console.log(`[Room ${room.id}] Grace period expired for player ${player.name} (${playerId}). Removing permanently.`);
    finalizePlayerDeparture(room, playerId, 'timeout');
  }, DISCONNECT_GRACE_PERIOD_MS);
}

function finalizePlayerDeparture(room: Room, playerId: string, reason: 'timeout' | 'left' = 'left') {
  const player = room.players.get(playerId);
  if (!player) return;

  if (player.disconnectTimeout) {
    clearTimeout(player.disconnectTimeout);
    player.disconnectTimeout = undefined;
  }

  const leavingName = player.name;
  room.players.delete(playerId);

  // If room is empty, schedule room deletion
  if (room.players.size === 0) {
    console.log(`[Room ${room.id}] Room is empty. Deleting room.`);
    rooms.delete(room.id);
    return;
  }

  // If host left, elect new host
  if (room.hostId === playerId) {
    const nextPlayer = room.players.values().next().value as RoomPlayer | undefined;
    if (nextPlayer) {
      room.hostId = nextPlayer.id;
      nextPlayer.isHost = true;
      nextPlayer.isReady = true;
      console.log(`[Room ${room.id}] Host transferred to ${nextPlayer.name} (${nextPlayer.id})`);
    }
  }

  broadcastToRoom(room, {
    type: 'player_left',
    playerId,
    playerName: leavingName,
    reason,
    roomState: getPublicRoomState(room),
  });
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });

  app.use(express.json());

  // Health check API
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      activeRooms: rooms.size,
      uptime: process.uptime(),
      timestamp: Date.now(),
    });
  });

  // List open rooms waiting for players
  app.get('/api/rooms', (_req, res) => {
    const list: Array<{
      id: string;
      playerCount: number;
      gameState: string;
      hostName: string;
      hasAvailableSlot: boolean;
    }> = [];

    for (const room of rooms.values()) {
      const activePlayers = Array.from(room.players.values()).filter((p) => !p.isDisconnected);
      if (room.players.size > 0 && room.players.size <= 2) {
        const host = room.players.get(room.hostId);
        list.push({
          id: room.id,
          playerCount: activePlayers.length,
          gameState: room.gameState,
          hostName: host ? host.name : 'Jogador',
          hasAvailableSlot: room.players.size < 2 || activePlayers.length < 2,
        });
      }
    }
    res.json({ rooms: list });
  });

  // Heartbeat ping interval to detect silent TCP drops
  const heartbeatInterval = setInterval(() => {
    wss.clients.forEach((wsClient) => {
      const wsWithAlive = wsClient as WebSocket & { isAlive?: boolean };
      if (wsWithAlive.isAlive === false) {
        console.log('[WS Heartbeat] Terminating inactive socket connection.');
        return wsClient.terminate();
      }
      wsWithAlive.isAlive = false;
      try {
        wsClient.ping();
      } catch (err) {
        console.error('[WS Heartbeat] Ping error:', err);
        wsClient.terminate();
      }
    });
  }, 20000);

  wss.on('close', () => {
    clearInterval(heartbeatInterval);
  });

  // WebSocket connection lifecycle
  wss.on('connection', (ws: WebSocket) => {
    const wsWithAlive = ws as WebSocket & { isAlive?: boolean };
    wsWithAlive.isAlive = true;

    let currentRoomId: string | null = null;
    let currentSessionPlayerId: string | null = null;

    // Handle pong responses
    ws.on('pong', () => {
      wsWithAlive.isAlive = true;
    });

    // Handle unexpected socket errors gracefully
    ws.on('error', (err) => {
      console.error('[WS Socket Error]:', err.message);
    });

    ws.on('message', (data: Buffer | string) => {
      try {
        const msg = JSON.parse(data.toString());

        switch (msg.type) {
          case 'ping': {
            safeSend(ws, { type: 'pong', timestamp: Date.now() });
            break;
          }

          // RECONNECT ROOM (Treatment for unexpected disconnections!)
          case 'reconnect_room': {
            const reqRoomId = (msg.roomId || '').toString().trim().toUpperCase();
            const reqPlayerId = (msg.playerId || '').toString().trim();
            const reqSessionToken = (msg.sessionToken || '').toString().trim();

            const room = rooms.get(reqRoomId);
            if (!room) {
              safeSend(ws, {
                type: 'reconnect_failed',
                reason: 'room_not_found',
                message: 'A sala anterior não existe mais ou foi encerrada.',
              });
              return;
            }

            const existingPlayer = room.players.get(reqPlayerId);
            if (!existingPlayer || existingPlayer.sessionToken !== reqSessionToken) {
              safeSend(ws, {
                type: 'reconnect_failed',
                reason: 'invalid_session',
                message: 'Sessão de reconexão inválida ou expirada.',
              });
              return;
            }

            // Successfully recovering previous session!
            if (existingPlayer.disconnectTimeout) {
              clearTimeout(existingPlayer.disconnectTimeout);
              existingPlayer.disconnectTimeout = undefined;
            }

            // Close old socket if somehow still hanging
            if (existingPlayer.ws && existingPlayer.ws !== ws) {
              try {
                existingPlayer.ws.terminate();
              } catch {
                // Ignore
              }
            }

            existingPlayer.ws = ws;
            existingPlayer.isDisconnected = false;
            existingPlayer.disconnectedAt = null;

            currentRoomId = room.id;
            currentSessionPlayerId = existingPlayer.id;

            console.log(`[Room ${room.id}] Player ${existingPlayer.name} (${existingPlayer.id}) successfully reconnected!`);

            safeSend(ws, {
              type: 'reconnected_success',
              playerId: existingPlayer.id,
              sessionToken: existingPlayer.sessionToken,
              roomId: room.id,
              isHost: existingPlayer.isHost,
              roomState: getPublicRoomState(room),
            });

            broadcastToRoom(
              room,
              {
                type: 'player_reconnected',
                playerId: existingPlayer.id,
                playerName: existingPlayer.name,
                roomState: getPublicRoomState(room),
                message: `${existingPlayer.name} se reconectou ao jogo!`,
              },
              ws
            );
            break;
          }

          case 'join_room': {
            const rawRoomId = (msg.roomId || '').toString().trim().toUpperCase() || 'PNEU-1';
            const reqName = (msg.name || '').toString().trim().substring(0, 16) || 'Guardião';
            const reqSkin = (msg.skinId || '').toString().trim() || 'economart';

            const newPlayerId = `p_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
            const sessionToken = `tok_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;

            currentRoomId = rawRoomId;
            currentSessionPlayerId = newPlayerId;

            let room = rooms.get(rawRoomId);
            if (!room) {
              room = {
                id: rawRoomId,
                hostId: newPlayerId,
                gameState: 'lobby',
                levelIndex: 1,
                players: new Map(),
              };
              rooms.set(rawRoomId, room);
            }

            // If an unexpectedly disconnected slot exists with the same name, or check capacity
            const activePlayerCount = Array.from(room.players.values()).filter((p) => !p.isDisconnected).length;
            if (activePlayerCount >= 2) {
              safeSend(ws, {
                type: 'room_full',
                message: 'A sala já está cheia (máximo de 2 jogadores para co-op)!',
              });
              return;
            }

            const isHost = room.players.size === 0 || room.hostId === newPlayerId;
            const newPlayer: RoomPlayer = {
              id: newPlayerId,
              sessionToken,
              name: reqName,
              skinId: reqSkin,
              isHost,
              isReady: isHost,
              x: isHost ? 80 : 140,
              y: 430,
              vx: 0,
              vy: 0,
              facing: 1,
              hp: 5,
              maxHp: 5,
              carriedCategory: null,
              isAttacking: false,
              comboStep: 1,
              isKnockedOut: false,
              isDisconnected: false,
              disconnectedAt: null,
              ws,
            };

            room.players.set(newPlayerId, newPlayer);

            safeSend(ws, {
              type: 'joined_room',
              playerId: newPlayerId,
              sessionToken,
              roomId: rawRoomId,
              isHost,
              roomState: getPublicRoomState(room),
            });

            broadcastToRoom(room, {
              type: 'room_updated',
              roomState: getPublicRoomState(room),
              message: `${reqName} entrou na sala!`,
            });
            break;
          }

          case 'leave_room': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            finalizePlayerDeparture(room, currentSessionPlayerId, 'left');
            currentRoomId = null;
            currentSessionPlayerId = null;
            break;
          }

          case 'update_profile': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            const player = room.players.get(currentSessionPlayerId);
            if (!player) return;
            if (msg.name) player.name = msg.name.trim().substring(0, 16);
            if (msg.skinId) player.skinId = msg.skinId;
            broadcastToRoom(room, {
              type: 'room_updated',
              roomState: getPublicRoomState(room),
            });
            break;
          }

          case 'set_ready': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            const player = room.players.get(currentSessionPlayerId);
            if (!player) return;
            player.isReady = !!msg.ready;
            broadcastToRoom(room, {
              type: 'room_updated',
              roomState: getPublicRoomState(room),
            });
            break;
          }

          case 'chat_message': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            const player = room.players.get(currentSessionPlayerId);
            if (!player) return;
            const text = (msg.text || '').toString().trim().substring(0, 80);
            if (!text) return;
            broadcastToRoom(room, {
              type: 'chat_broadcast',
              senderId: currentSessionPlayerId,
              senderName: player.name,
              text,
            });
            break;
          }

          case 'start_game': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room || room.hostId !== currentSessionPlayerId) return;
            room.gameState = 'playing';
            room.levelIndex = typeof msg.levelIndex === 'number' ? msg.levelIndex : 1;
            broadcastToRoom(room, {
              type: 'game_started',
              levelIndex: room.levelIndex,
              roomState: getPublicRoomState(room),
            });
            break;
          }

          case 'player_sync': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            const player = room.players.get(currentSessionPlayerId);
            if (!player) return;

            if (typeof msg.x === 'number') player.x = msg.x;
            if (typeof msg.y === 'number') player.y = msg.y;
            if (typeof msg.vx === 'number') player.vx = msg.vx;
            if (typeof msg.vy === 'number') player.vy = msg.vy;
            if (typeof msg.facing === 'number') player.facing = msg.facing;
            if (typeof msg.hp === 'number') player.hp = msg.hp;
            if (typeof msg.carriedCategory !== 'undefined') player.carriedCategory = msg.carriedCategory;
            if (typeof msg.isAttacking === 'boolean') player.isAttacking = msg.isAttacking;
            if (typeof msg.comboStep === 'number') player.comboStep = msg.comboStep;
            if (typeof msg.isKnockedOut === 'boolean') player.isKnockedOut = msg.isKnockedOut;

            broadcastToRoom(
              room,
              {
                type: 'remote_player_sync',
                playerId: currentSessionPlayerId,
                x: player.x,
                y: player.y,
                vx: player.vx,
                vy: player.vy,
                facing: player.facing,
                hp: player.hp,
                carriedCategory: player.carriedCategory,
                isAttacking: player.isAttacking,
                comboStep: player.comboStep,
                isKnockedOut: player.isKnockedOut,
              },
              ws
            );
            break;
          }

          case 'player_attack': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            broadcastToRoom(
              room,
              {
                type: 'remote_player_attack',
                playerId: currentSessionPlayerId,
                comboStep: msg.comboStep || 1,
                x: msg.x,
                y: msg.y,
                facing: msg.facing || 1,
              },
              ws
            );
            break;
          }

          case 'recycle_event': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            const player = room.players.get(currentSessionPlayerId);
            broadcastToRoom(
              room,
              {
                type: 'remote_recycle_event',
                playerId: currentSessionPlayerId,
                playerName: player ? player.name : 'Parceiro',
                category: msg.category,
                comboMultiplier: msg.comboMultiplier || 1,
              },
              ws
            );
            break;
          }

          case 'revive_partner': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room) return;
            broadcastToRoom(room, {
              type: 'partner_revived',
              revivedBy: currentSessionPlayerId,
            });
            break;
          }

          case 'next_level': {
            if (!currentRoomId || !currentSessionPlayerId) return;
            const room = rooms.get(currentRoomId);
            if (!room || room.hostId !== currentSessionPlayerId) return;
            room.levelIndex = typeof msg.levelIndex === 'number' ? msg.levelIndex : room.levelIndex + 1;
            broadcastToRoom(room, {
              type: 'level_changed',
              levelIndex: room.levelIndex,
            });
            break;
          }
        }
      } catch (err) {
        console.error('[WS Message Parse Error]:', err);
      }
    });

    // Handle unexpected disconnection (closing socket, loss of signal)
    ws.on('close', (code, reason) => {
      console.log(`[WS Close] Client disconnected (Code: ${code}, Reason: ${reason.toString() || 'none'})`);
      if (currentRoomId && currentSessionPlayerId) {
        const room = rooms.get(currentRoomId);
        if (room) {
          handlePlayerUnexpectedDisconnect(room, currentSessionPlayerId);
        }
      }
    });
  });

  // Serve Vite or Static build
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const port = Number(process.env.PORT) || 3000;
  server.listen(port, '0.0.0.0', () => {
    console.log(`Economart Server running on http://localhost:${port}`);
  });
}

startServer();
